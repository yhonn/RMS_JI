﻿

Namespace CORE


    Public Class cls_user_approval
        Inherits cls_user

        Sub New(ByVal idS As Integer, Optional ByVal idu As Integer = 0, Optional ByVal idTP As Integer = 0)

            MyBase.New(idS, idu, idTP)

        End Sub



    End Class


End Namespace

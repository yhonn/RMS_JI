﻿Imports System
Imports System.Web
Imports System.Data.SqlClient
Imports System.Globalization


Namespace SIMEly


    Public Class cls_ProgramSIME

        Dim cCOre As New CORE.cls_util
        Dim tbl_Program As DataTable
        Dim tbl_Systems As DataTable

        Public Sub New()

            tbl_Program = New DataTable("tbl_Program")
            tbl_Systems = New DataTable("tbl_systems")

        End Sub


        Public Function get_Programs(Optional ByVal idProg As Integer = 0, Optional ByVal AllFields As Boolean = False) As DataTable

            Dim strFiels As String = IIf(AllFields, " * ", " id_programa, nombre_Programa ")

            Dim strSQL As String = String.Format(" select {0} from vw_t_programasALL where visible = 1 ", strFiels)

            If idProg > 0 Then
                strSQL &= String.Format(" and id_programa = {0} ", idProg)
            End If

            tbl_Program = cCOre.setObjeto("vw_t_programas", "id_programa", 0, strSQL).Copy
            get_Programs = tbl_Program

        End Function


        Public Function get_Programs(ByVal idUser As Integer) As DataTable


            Dim strSQL As String = String.Format("select a.* from vw_t_programasALL a " _
                                                   & " inner join vw_t_usuario_programa b on (a.id_programa = b.id_programa) " _
                                                  & " where b.id_usuario = {0} and a.visible = 1", idUser)

            tbl_Program = cCOre.setObjeto("vw_t_programasALL", "id_programa", 0, strSQL).Copy
            get_Programs = tbl_Program

        End Function


        Public Function getprogramField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cCOre.getDTval(tbl_Program, campoSearch, campo, valorSearch)

        End Function

        Public Function get_Sys(Optional ByVal idSys As Integer = 0, Optional ByVal AllFields As Boolean = False) As DataTable

            Dim strFiels As String = IIf(AllFields, " * ", " id_sys, sys_name")

            Dim strSQL As String = String.Format(" select {0} from t_sys ", strFiels)

            If idSys > 0 Then
                strSQL &= String.Format(" where id_sys = {0} ", idSys)
            End If

            tbl_Systems = cCOre.setObjeto("t_sys", "id_sys", 0, strSQL).Copy
            get_Sys = tbl_Systems

        End Function


        Public Function get_Sys(ByVal id_programa As Integer, ByVal idUser As Integer, Optional ByVal AllFields As Boolean = False) As DataTable

            'Dim strSQL As String = String.Format("select c.* from t_usuario_programa a 
            '                        inner join
            '                        (select distinct a.id_rol, c.id_sys from t_rol a
            '                         inner join t_access_mod b on (a.id_rol = b.id_rol)
            '                          inner join t_mod c on (b.id_mod = c.id_mod)
            '                        where b.acm_acc = 1) as tab1 on (a.id_rol = tab1.id_rol)
            '                       inner join t_sys c on (tab1.id_sys = c.id_sys)
            '                         where a.id_programa = {0}
            '                       and a.id_usuario = {1}", id_programa, idUser)

            Dim strSQL As String = String.Format("select distinct c.* from t_usuario_programa a " _
                                     & " inner join t_usuario_roles b on (a.id_usuario = b.id_usuario and a.id_programa = b.id_programa) " _
             & "  inner join " _
                                       & "  (select distinct a.id_rol, c.id_sys from t_rol a " _
                                              & "   inner join t_access_mod b on (a.id_rol = b.id_rol) " _
                                              & "   inner join t_mod c on (b.id_mod = c.id_mod) " _
                                             & "    where b.acm_acc = 1) as tab1 on (b.id_rol = tab1.id_rol)" _
                                             & "    inner join t_sys c on (tab1.id_sys = c.id_sys) " _
           & "  where a.id_programa = {0} " _
                                             & "    and a.id_usuario = {1} ", id_programa, idUser)

            tbl_Systems = cCOre.setObjeto("t_sys", "id_sys", 0, strSQL).Copy
            get_Sys = tbl_Systems

        End Function


        Public Function getSysField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cCOre.getDTval(tbl_Systems, campoSearch, campo, valorSearch)

        End Function







    End Class


End Namespace

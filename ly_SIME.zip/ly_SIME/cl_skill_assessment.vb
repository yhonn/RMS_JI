﻿Namespace CORE


    Public Class cl_skill_assessment

        Public cl_utl As New CORE.cls_util
        Dim Sql As String

        Public ReadOnly Property id_programa As Integer


        Public Sub New(ByVal idP As Integer)

            id_programa = idP

        End Sub

        Public Function get_resultBy_gender(ByVal strFilter As String) As DataTable


            Sql = String.Format("select id_sex_type, order_theme, theme_name, avg(ValuePerTheme) as ValuePerTheme
                                   from vw_ins_measurement_valuepertheme
                                 where  {0} 
                                 group by id_sex_type, order_theme, theme_name
                                 order by id_sex_type, order_theme ", strFilter)

            get_resultBy_gender = cl_utl.setObjeto("vw_ins_measurement_valuepertheme", "id_sex_type", 1, Sql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (get_resultBy_gender.Rows.Count = 1 And get_resultBy_gender.Rows.Item(0).Item("id_sex_type") = 0) Then
                get_resultBy_gender.Rows.Remove(get_resultBy_gender.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


        End Function


        Public Function get_resultBy_Class(ByVal strFilter As String) As DataTable


            Sql = String.Format("select id_class_level, class_level_name, id_measurement_theme, order_theme, theme_name, avg(ValuePerTheme) as ValuePerTheme
                                   from vw_ins_measurement_valuepertheme
                                 where  {0}
                                 group by id_class_level, class_level_name, id_measurement_theme, order_theme, theme_name
                                order by order_theme, id_class_level ", strFilter)

            get_resultBy_Class = cl_utl.setObjeto("vw_ins_measurement_valuepertheme", "id_class_level", 1, Sql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (get_resultBy_Class.Rows.Count = 1 And get_resultBy_Class.Rows.Item(0).Item("id_class_level") = 0) Then
                get_resultBy_Class.Rows.Remove(get_resultBy_Class.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

        End Function



    End Class


End Namespace

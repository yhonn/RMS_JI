﻿Imports System.Configuration.ConfigurationManager
Imports System.Data.SqlClient
Imports System.Globalization

Namespace CORE

    Public Class cls_util

        Dim cnn As New SqlConnection(ConnectionStrings("dbCI_SAPConnectionString").ConnectionString)
        Dim ci As New CultureInfo("en-US")
        Dim dbDATEformat As String
        Const dd As String = "dd"
        Const MM As String = "MM"
        Const yyyy As String = "yyyy"

        Public Sub New()

            dbDATEformat = set_DbDATEformat()

        End Sub


        Private Function set_dbDATEformat() As String

            Dim tbl_usrOP As New DataTable
            Dim sql As String = " dbcc useroptions "
            tbl_usrOP = setObjeto("useroption", "dateformat", 0, sql)
            set_dbDATEformat = "MM-dd-yyyy HH:mm:ss"
        End Function

        Private Function getStringF(ByVal dbDateFormat As String) As String

            'dd/MM/yyyy HH:mm:ss

            Dim setFormat As String = ""

            For Each chr As Char In dbDateFormat.Trim

                If chr = "y" Then
                    setFormat &= yyyy
                ElseIf chr = "m" Then
                    setFormat &= MM
                Else
                    setFormat &= dd
                End If

                setFormat &= "-"

            Next

            getStringF = setFormat.Substring(0, setFormat.Length - 1) & " HH:mm:ss"

        End Function


        Public Function getDTval(ByVal tbl As DataTable, ByVal Field As String, ByVal FieldGet As String, ByVal valFind As String, Optional ByVal FieldAux As String = "", Optional ByVal valFindAux As String = "")

            Dim ret As String = ""
            Dim foundIndex As Integer = 0

            If tbl.Rows.Count > 0 Then

                For Each dtRow As DataRow In tbl.Rows

                    If dtRow(Field) = CType(valFind, String) Then

                        If FieldAux.Length > 0 Then
                            If dtRow(FieldAux) = CType(valFindAux, String) Then
                                foundIndex = 1
                            Else
                                foundIndex = 0
                            End If
                        Else
                            foundIndex = 1
                        End If

                        If foundIndex = 1 Then
                            ret = dtRow(FieldGet)
                            Exit For
                        End If

                    End If

                Next

            End If

            Return ret

        End Function



        Public Function setDTval(ByVal tbl As DataTable, ByVal Field As String, ByVal FieldChange As String, ByVal valFind As String, ByVal Val As String) As DataTable

            Dim i As Integer = 0

            If tbl.Rows.Count > 0 Then

                For i = 0 To tbl.Rows.Count - 1

                    If tbl.Rows.Item(i).Item(Field) = CType(valFind, String) Then
                        Val = If(IsNothing(Val), "", Val)
                        tbl.Rows.Item(i).Item(FieldChange) = getDataVal(tbl.Rows.Item(i).Item(FieldChange).GetType, Val)
                        'tbl.Rows.Item(i).Item(FieldChange) = Val

                        Exit For
                    End If

                Next

            Else

                Return Nothing

            End If

            Return tbl

        End Function



        Private Function getDataVal(ByVal TpDat As System.Type, ByVal valores As Object) As Object

            Dim Encoding As System.Text.UnicodeEncoding = New System.Text.UnicodeEncoding



            If TpDat.FullName = "System.String" Then
                getDataVal = String.Format("{0}", CType(valores, String))
            ElseIf TpDat.FullName = "System.Int16" Then
                getDataVal = CType(valores, Integer)
            ElseIf TpDat.FullName = "System.Int32" Then
                getDataVal = CType(valores, Integer)
            ElseIf TpDat.FullName = "System.Int64" Then
                getDataVal = CType(valores, Integer)
            ElseIf TpDat.FullName = "System.Decimal" Then
                getDataVal = Convert.ToDecimal(valores, ci)
                'strReturn = String.Format(ci, "{0:N6}", valores)
                'valDec = Convert.ToDecimal(valores.ToString(ci), ci)
                'strReturn = valDec.ToString(ci)
            ElseIf TpDat.FullName = "System.Double" Then
                getDataVal = Convert.ToDouble(valores, ci)
                'strReturn = String.Format(ci, "{0:N6}", valores)
                'valDou = Convert.ToDouble(valores.ToString(ci), ci)
                'strReturn = valDou.ToString(ci)
            ElseIf TpDat.FullName = "System.DateTime" Then
                Dim fecha As DateTime = CType(valores, DateTime)
                getDataVal = fecha
                'String.Format("'{0:dd/MM/yyyy HH:mm:ss}'", fecha)
                '' DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            ElseIf TpDat.FullName = "System.Byte[]" Then
                Dim msgByte As Byte() = Encoding.GetBytes(valores)
                getDataVal = msgByte
            Else
                getDataVal = CType(valores, String)
            End If

        End Function


        Public Function setObjeto(ByVal nameOBJ As String, ByVal nameIDobj As String, ByVal idOBJ As Integer, Optional strQuery As String = "", Optional strCode As String = "") As DataTable

            Dim strSQl As String
            Dim dm As New SqlDataAdapter("", cnn)
            Dim ds As New DataSet
            Dim dTbl As New DataTable
            dTbl.Locale = ci 'Setting English Culture Info
            Dim tblRES As New DataTable

            If strQuery.Trim.Length = 0 Then

                If strCode.Trim.Length = 0 Then
                    strSQl = String.Format("select * from {0} where {1} = {2}", nameOBJ, nameIDobj, idOBJ)
                Else
                    strSQl = String.Format("select * from {0} where {1} = '{2}'", nameOBJ, nameIDobj, strCode.Trim)
                End If

            Else
                strSQl = strQuery
            End If


            Try

                ds.Tables.Add(nameOBJ)
                dm.SelectCommand.CommandText = strSQl
                dm.SelectCommand.CommandTimeout = 0

                dm.Fill(ds, nameOBJ)
                dTbl = ds.Tables.Item(nameOBJ)

                'tblRES = nwTable(nameOBJ, dTbl)
                If dTbl.Rows.Count = 0 Then
                    'tblRES = addRW(tblRES)
                    dTbl = addRW(dTbl)
                    'Else
                    'tblRES = addRW_val(tblRES, dTbl)
                End If

            Catch ex As Exception
                dTbl = New DataTable
                'tblRES = Nothing
            End Try


            'Select Case vTypeOBJ

            '    Case "Beneficiarios"

            '        strSQl = String.Format("select * from tme_Beneficiario where id_beneficiario = {0}", idOBJ)
            '        ds.Tables.Add("tme_Beneficiario")
            '        dm.SelectCommand.CommandText = strSQl
            '        dm.Fill(ds, "tme_Beneficiario")
            '        dTbl = ds.Tables.Item("tme_Beneficiario")
            '        'ds.Tables.Item("PRESS").Rows.Add(New Object() {0, "--SELECCIONE--"})

            '        If dTbl.Rows.Count = 0 Then
            '            addRW(dTbl)
            '        End If

            '    Case Else
            '        dTbl = Nothing

            'End Select

            Return dTbl
            'Return tblRES

        End Function


        Public Function setObjeto_v2(ByVal nameOBJ As String, ByVal nameIDobj As String, ByVal idOBJ As Integer, Optional strQuery As String = "", Optional strCode As String = "", Optional Upd_TimeOut As Integer = 0) As DataTable

            Dim strSQl As String
            Dim dm As New SqlDataAdapter("", cnn)
            Dim ds As New DataSet
            Dim dTbl As New DataTable
            dTbl.Locale = ci 'Setting English Culture Info
            Dim tblRES As New DataTable

            If strQuery.Trim.Length = 0 Then

                If strCode.Trim.Length = 0 Then
                    strSQl = String.Format("select * from {0} where {1} = {2}", nameOBJ, nameIDobj, idOBJ)
                Else
                    strSQl = String.Format("select * from {0} where {1} = '{2}'", nameOBJ, nameIDobj, strCode.Trim)
                End If

            Else
                strSQl = strQuery
            End If


            Try

                ds.Tables.Add(nameOBJ)
                dm.SelectCommand.CommandText = strSQl

                If Upd_TimeOut > 0 Then
                    dm.SelectCommand.CommandTimeout = Upd_TimeOut
                End If

                dm.Fill(ds, nameOBJ)
                dTbl = ds.Tables.Item(nameOBJ)

                'tblRES = nwTable(nameOBJ, dTbl)
                If dTbl.Rows.Count = 0 Then
                    'tblRES = addRW(tblRES)
                    dTbl = addRW(dTbl)
                    'Else
                    'tblRES = addRW_val(tblRES, dTbl)
                End If

            Catch ex As Exception
                dTbl = Nothing
                'tblRES = Nothing
            End Try


            'Select Case vTypeOBJ

            '    Case "Beneficiarios"

            '        strSQl = String.Format("select * from tme_Beneficiario where id_beneficiario = {0}", idOBJ)
            '        ds.Tables.Add("tme_Beneficiario")
            '        dm.SelectCommand.CommandText = strSQl
            '        dm.Fill(ds, "tme_Beneficiario")
            '        dTbl = ds.Tables.Item("tme_Beneficiario")
            '        'ds.Tables.Item("PRESS").Rows.Add(New Object() {0, "--SELECCIONE--"})

            '        If dTbl.Rows.Count = 0 Then
            '            addRW(dTbl)
            '        End If

            '    Case Else
            '        dTbl = Nothing

            'End Select

            Return dTbl
            'Return tblRES

        End Function


        Public Function nwTable(ByVal nObject As String, ByVal tblDAT As DataTable) As DataTable

            Dim tblRESULT As New DataTable(nObject)
            Dim vColumns As DataColumn

            For Each dtC As DataColumn In tblDAT.Columns

                vColumns = New DataColumn(dtC.ColumnName, dtC.DataType)
                'vColumns = System.Globalization.CultureInfo.CurrentCulture
                tblRESULT.Columns.Add(vColumns)

            Next

            nwTable = tblRESULT

        End Function

        Public Function SaveObjeto(ByVal nObjeto As String, ByVal Dtbl As DataTable, ByVal namefieldID As String, ByVal valFieldID As Integer) As Integer

            Dim sqlString As String
            Dim strValues As String
            Dim strFields As String


            strValues = getValuesSecuence(Dtbl, namefieldID, valFieldID)
            strFields = getFieldSecuence(Dtbl, namefieldID, valFieldID)

            If valFieldID = 0 Then
                sqlString = String.Format(" Insert into {0} ({1}) values ({2})  SELECT @@IDENTITY ", nObjeto, strFields, strValues)
            Else
                sqlString = String.Format(" Update {0} set {1} where {2} = {3}; SELECT {2} from {0} where {2} = {3}", nObjeto, strValues, namefieldID, valFieldID)
            End If


            Try

                cnn.Open()
                Dim dm As New SqlDataAdapter(sqlString, cnn)

                Dim ds As New DataSet("Beneficiario")
                dm.Fill(ds, "Beneficiario")
                SaveObjeto = ds.Tables("Beneficiario").Rows(0).Item(0)

            Catch ex As Exception

                SaveObjeto = -1

            End Try

            cnn.Close()

        End Function





        Private Function getValuesSecuence(ByVal dTBL As DataTable, ByVal nameIDfield As String, ByVal valIDfield As Integer) As String

            Dim strSecuence As String = ""
            Dim valDec As Decimal
            Dim valBool As Boolean
            Dim valDou As Double
            Dim Encoding As System.Text.UnicodeEncoding = New System.Text.UnicodeEncoding
            Dim valByte As Byte()
            Dim chrBLK As String = " "
            valByte = Encoding.GetBytes(chrBLK)
            Dim guiVal As Guid
            guiVal = System.Guid.Empty

            If valIDfield = 0 Then 'Para Insert

                For Each dtC As DataColumn In dTBL.Columns

                    If nameIDfield <> dtC.ColumnName Then
                        strSecuence &= getVal(dtC.DataType, dTBL.Rows.Item(0).Item(dtC.ColumnName)) & ", "
                    End If

                Next

            Else 'Para Update

                For Each dtC As DataColumn In dTBL.Columns

                    If IsDBNull(dTBL.Rows.Item(0).Item(dtC.ColumnName)) Then
                        If dtC.DataType.FullName = "System.String" Then
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = ""
                        ElseIf dtC.DataType.FullName = "System.Int16" Then
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = "0"
                        ElseIf dtC.DataType.FullName = "System.Int32" Then
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = "0"
                        ElseIf dtC.DataType.FullName = "System.Int64" Then
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = "0"
                        ElseIf dtC.DataType.FullName = "System.Decimal" Then
                            valDec = Convert.ToDecimal("0.0", ci)
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = valDec.ToString(ci)
                        ElseIf dtC.DataType.FullName = "System.Double" Then
                            valDou = Convert.ToDecimal("0.0", ci)
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = valDou.ToString(ci)
                        ElseIf dtC.DataType.FullName = "System.DateTime" Then
                            Dim fecha As DateTime = CType(DateAdd(DateInterval.Year, -14, Now), DateTime)
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = fecha 'String.Format("'{0:dd-MM-yyyy HH:mm:ss}'", fecha)
                        ElseIf dtC.DataType.FullName = "System.Byte[]" Then
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = valByte
                        ElseIf dtC.DataType.FullName = "System.Gui" Then
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = guiVal
                        ElseIf dtC.DataType.FullName = "System.Boolean" Then
                            valBool = Convert.ToBoolean(dtC.ColumnName)
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = valBool
                        Else
                            dTBL.Rows.Item(0).Item(dtC.ColumnName) = CType("", String)
                        End If
                    End If

                    If nameIDfield <> dtC.ColumnName Then
                        strSecuence &= dtC.ColumnName & "=" & getVal(dtC.DataType, dTBL.Rows.Item(0).Item(dtC.ColumnName)) & ", "
                    End If

                Next

            End If

            strSecuence = Strings.Left(strSecuence, strSecuence.Length - 2)

            getValuesSecuence = strSecuence

        End Function



        Private Function getFieldSecuence(ByVal dTBL As DataTable, ByVal nameIDfield As String, ByVal valIDfield As Integer) As String

            Dim strSecuence As String = ""

            For Each dtC As DataColumn In dTBL.Columns

                If nameIDfield <> dtC.ColumnName Then
                    strSecuence &= dtC.ColumnName & ", "
                End If

            Next

            strSecuence = Strings.Left(strSecuence, strSecuence.Length - 2)

            getFieldSecuence = strSecuence

        End Function

        Private Function getVal(ByVal TpDat As System.Type, ByVal valores As Object) As Object

            Dim strReturn As String = ""
            Dim valDec As Decimal
            Dim valDou As Double
            Dim valInteger As Integer

            If TpDat.FullName = "System.String" Then
                strReturn = String.Format("'{0}'", CType(valores.Replace("'", "''"), String))
            ElseIf TpDat.FullName = "System.Int16" Then
                strReturn = CType(valores, String)
            ElseIf TpDat.FullName = "System.Int32" Then
                strReturn = CType(valores, String)
            ElseIf TpDat.FullName = "System.Int64" Then
                strReturn = CType(valores, String)
            ElseIf TpDat.FullName = "System.Byte[]" Then
                strReturn = "0x" & BytesToString(valores)
            ElseIf TpDat.FullName = "System.Boolean" Then
                valInteger = Convert.ToInt16(valores)
                strReturn = CType(valInteger, Int16)
            ElseIf TpDat.FullName = "System.Guid" Then
                strReturn = String.Format("'{0}'", valores.ToString)
            ElseIf TpDat.FullName = "System.Decimal" Then
                'strReturn = CType(valores, String)
                'strReturn = String.Format(ci, "{0:N6}", valores)
                valDec = Convert.ToDecimal(valores, ci)
                strReturn = valDec.ToString(ci)
                '.Replace(",", ".")
            ElseIf TpDat.FullName = "System.Double" Then
                'strReturn = CType(valores, String)
                ' strReturn = String.Format(ci, "{0:N6}", valores)
                valDou = Convert.ToDouble(valores, ci)
                strReturn = valDou.ToString(ci)
                '.Replace(",", ".")
            ElseIf TpDat.FullName = "System.DateTime" Then
                Dim fecha As DateTime = CType(valores, DateTime)
                'strReturn = String.Format("'{0:dd-MM-yyyy HH:mm:ss}'", fecha)
                'strReturn = String.Format("'{0:yyyy-MM-dd HH:mm:ss}'", fecha)
                Dim formatDATE As String = "'{0:" & dbDATEformat & "}'"
                strReturn = String.Format(formatDATE, fecha)

            Else
                strReturn = CType(valores, String)
            End If

            getVal = strReturn

        End Function



        Private Function BytesToString(ByVal Input As Byte()) As String
            Dim Result As New System.Text.StringBuilder(Input.Length * 2)
            Dim Part As String
            For Each b As Byte In Input
                Part = Conversion.Hex(b)
                If Part.Length = 1 Then Part = "0" & Part
                Result.Append(Part)
            Next
            Return Result.ToString()
        End Function



        Private Function addRW(ByVal dTBL As DataTable) As DataTable

            Dim dtRow As DataRow = dTBL.NewRow
            Dim nombreCol As String = ""

            For Each dtC As DataColumn In dTBL.Columns
                dtRow.Item(dtC.ColumnName) = getEmptyVal(dtC.DataType)
            Next

            dTBL.Rows.Add(dtRow)

            Return dTBL

        End Function


        Private Function addRW_val(ByVal nwTBL As DataTable, ByVal dTBL As DataTable) As DataTable


            Dim dtRow As DataRow = nwTBL.NewRow
            Dim nombreCol As String = ""


            For Each dtC As DataColumn In nwTBL.Columns
                dtRow.Item(dtC.ColumnName) = dTBL.Rows.Item(0).Item(dtC.ColumnName)
            Next

            nwTBL.Rows.Add(dtRow)

            Return dTBL

        End Function


        Private Function getEmptyVal(ByVal TpDat As System.Type) As Object

            Dim strReturn As Object = Nothing
            Dim valINT As Integer = 0
            Dim valDec As Decimal = Math.Round(0.0, 6, MidpointRounding.AwayFromZero)
            Dim valDouble As Double = Math.Round(0.0, 6, MidpointRounding.AwayFromZero)
            Dim valDateTime As DateTime = DateAdd(DateInterval.Year, -100, CType(Date.Now, DateTime))
            Dim valBoolean As Boolean = False
            Dim Encoding As System.Text.UnicodeEncoding = New System.Text.UnicodeEncoding
            Dim valByte As Byte()
            Dim chrBLK As String = " "
            valByte = Encoding.GetBytes(chrBLK)
            Dim guiVal As Guid
            guiVal = System.Guid.Empty

            If TpDat.FullName = "System.String" Then
                'strReturn = String.Format("'{0}'", CType(valores, String))
                strReturn = " "
                getEmptyVal = strReturn
            ElseIf TpDat.FullName = "System.Int16" Then
                'strReturn = CType(valores, String)
                strReturn = 0
                getEmptyVal = valINT
            ElseIf TpDat.FullName = "System.Int32" Then
                'strReturn = CType(valores, String)
                getEmptyVal = valINT
            ElseIf TpDat.FullName = "System.Int64" Then
                'strReturn = CType(valores, String)
                getEmptyVal = valINT
            ElseIf TpDat.FullName = "System.Decimal" Then
                'strReturn = CType(valores, String)
                'strReturn = 0.0
                getEmptyVal = valDec
            ElseIf TpDat.FullName = "System.Double" Then
                'strReturn = CType(valores, String)
                'strReturn = 0.0
                getEmptyVal = valDouble
            ElseIf TpDat.FullName = "System.DateTime" Then
                'strReturn = String.Format("'{0}'", CType(valores, String))
                'strReturn = CType(Date.Now, DateTime)
                getEmptyVal = valDateTime
            ElseIf TpDat.FullName = "System.Boolean" Then
                getEmptyVal = valBoolean
            ElseIf TpDat.FullName = "System.Byte[]" Then
                getEmptyVal = valByte
            ElseIf TpDat.FullName = "System.Guid" Then
                getEmptyVal = guiVal
            Else
                'strReturn = CType(valores, String)
                strReturn = " "
                getEmptyVal = strReturn
            End If


        End Function

        Public Function ConvertToDataTable(Of t)(
                                               ByVal list As IList(Of t)
                                            ) As DataTable
            Dim table As New DataTable()
            If Not list.Any Then
                'don't know schema ....
                Return table
            End If
            Dim fields() = list.First.GetType.GetProperties
            For Each field In fields

                If IsNullableType(field.PropertyType) Then
                    Dim UnderlyingType As Type = Nullable.GetUnderlyingType(field.PropertyType)
                    table.Columns.Add(field.Name, UnderlyingType)
                Else
                    table.Columns.Add(field.Name, field.PropertyType)
                End If


            Next
            For Each item In list
                Dim row As DataRow = table.NewRow()
                For Each field In fields

                    Dim p = item.GetType.GetProperty(field.Name)

                    If (Not IsNothing(p.GetValue(item, Nothing))) Then
                        row(field.Name) = p.GetValue(item, Nothing)
                    Else
                        row(field.Name) = DBNull.Value
                    End If

                    'If (Not p.GetValue(item, Nothing) Is Nothing) AndAlso IsNullableType(p.GetType) Then
                    '    Dim UnderlyingType As Type = Nullable.GetUnderlyingType(p.GetType)
                    '    row(field.Name) = p.GetValue(Convert.ChangeType(item, UnderlyingType), Nothing)
                    'Else
                    '    row(field.Name) = p.GetValue(item, Nothing)
                    'End If

                Next
                table.Rows.Add(row)
            Next
            Return table
        End Function

        Public Shared Function IsNullableType(ByVal myType As Type) As Boolean
            Return (myType.IsGenericType) AndAlso (myType.GetGenericTypeDefinition() Is GetType(Nullable(Of )))
        End Function

    End Class


End Namespace

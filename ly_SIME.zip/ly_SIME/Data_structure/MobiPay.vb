﻿

#Region "***************************** CUSTOMER************************************"


Partial Public Class Ensibukko_Customer
    Public Property status_code As Long
    Public Property message As String
    Public Property paginator As Paginator
End Class

Partial Public Class paginator
    Public Property data As List(Of Customer)
    Public Property Navigation As Navigation
End Class

Partial Public Class Customer
    'Public Property id As Long
    Public Property sacco_id As Long
    Public Property branch_id As Long
    Public Property customer_id As Long '--New
    'Public Property customer_details_id As Long
    Public Property customer_type As String
    Public Property total_shares As Double
    Public Property first_name As String
    Public Property middle_name As String
    Public Property last_name As String
    Public Property full_name As String
    Public Property gender As Gender?
    Public Property employment_type As String
    Public Property phone_number As String
    Public Property telephone_number As String
    Public Property email As String
    Public Property date_of_birth As Date?
    Public Property next_of_kin_full_name As String
    Public Property next_of_kin_phone As String
    Public Property city As String
    Public Property district As String
    Public Property country As String
    Public Property joined_on As DateTime
End Class

Partial Public Class navigation
    Public Property total As Long
    Public Property current_page As Long
    Public Property last_pages As Long
    Public Property next_page_url As Uri
    Public Property prev_page_url As Object
End Class

'Public Enum CustomerType
'    App\Models\Customers\Individual
'    App\Models\Customers\Institution
'End Enum

'Public Enum EmploymentType
'    NA
'End Enum

Public Enum Gender
    Female
    Male
    Other
    Empty
End Enum


#End Region '***************************** CUSTOMER ************************************



#Region "***************************** FINNANCIAL- SAVING ************************************"


Partial Public Class Ensibukko_saving
    Public Property status_code As Long
    Public Property message As String
    Public Property paginator As paginator_saving
End Class


Partial Public Class paginator_saving
    Public Property Data As List(Of saving)
    Public Property Navigation As navigation
End Class


Partial Public Class saving
    Public Property id As Long
    Public Property sacco_id As Long
    Public Property branch_id As Long
    Public Property customer_id As Long
    Public Property dob As Date
    Public Property gender As Gender?
    Public Property name As String '--porpuses
    Public Property account_name As String
    Public Property type As String
    Public Property balance As Double
    Public Property currency As String
    Public Property is_dormant As Boolean
    Public Property opened_at As DateTime
End Class


#End Region '"***************************** SAVING ************************************"




#Region "***************************** FINNANCIAL- LOAN ************************************"

Partial Public Class Ensibukko_loan
    Public Property status_code As Long
    Public Property message As String
    Public Property paginator As paginator_loan
End Class

Partial Public Class paginator_loan
    Public Property Data As List(Of loan)
    Public Property Navigation As navigation
End Class


Partial Public Class loan

    Public Property loan_id As Long
    Public Property sacco_Id As Long
    Public Property branch_id As Long
    Public Property customer_id As Long
    Public Property dob As Date
    Public Property gender As Gender?
    Public Property purpose As String
    Public Property application_date As Nullable(Of Date)
    Public Property appraisal_date As Nullable(Of Date)
    Public Property approval_date As Nullable(Of Date)
    Public Property rejection_date As Nullable(Of Date)
    Public Property disbursed_at As String
    Public Property requested_amount As Double
    Public Property approved_amount As Double
    Public Property down_payment As Double
    Public Property currency As String
    Public Property clearing_date As Nullable(Of Date)
    Public Property write_off_date As Nullable(Of Date)
    Public Property status As String
    Public Property repayment_period_months As Long

End Class




#End Region '"***************************** LOAN ************************************"


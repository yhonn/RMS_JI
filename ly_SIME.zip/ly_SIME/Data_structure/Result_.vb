﻿

Partial Public Class API_RESPONSE_EXC
    Public Property Success As Boolean
    Public Property Message As String
    Public Property Results As Long
    Public Property minID As Long
    Public Property maxID As Long
End Class

﻿


Partial Public Class MobiPay_Farmer
    Public Property Success As Boolean
    Public Property Message As String
    Public Property Results As Long
    Public Property Farmers As List(Of Farmer)
End Class

Partial Public Class Farmer
    Public Property AGROBASE_FARMER_ID As Long?
    Public Property MOBIPAY_ACCOUNT As Long?
    Public Property FARMER_NAME As String
    Public Property FARMER_MOTHERS_NAME As String
    Public Property FARMER_PHONE As String
    Public Property FARMER_DOB As Date?
    Public Property FARMER_DATE_REGISTERED As DateTime?
    Public Property FARMER_AGE As Long?
    Public Property FARMER_GENDER As String
    Public Property FARMER_PHOTO As String
    Public Property FARMER_ID_TYPE As String
    Public Property FARMER_KIN As String
    Public Property FARMER_KIN_NUMBER As String
    Public Property FARRMER_COOPERATIVE As String
    Public Property FARRMER_COOPERATIVE_ID As Long?
    Public Property FARMER_EDUCATION As String
    Public Property FARMER_MARITAL_STATUS As String
    Public Property FARMER_DISTRICT As String
    Public Property FARMER_CONSTITUENCY As String
    Public Property FARMER_SUBCOUNTY As String
    Public Property FARMER_PARISH As String
    Public Property FARMER_VILLAGE As String
    Public Property Farms As List(Of Farm)
    Public Property Crops As Crops
    Public Property Family As Family
    Public Property Income As List(Of Income)
End Class

Partial Public Class Crops
    Public Property CROP_TYPE As String
    Public Property CROP_VARIETY As String
    Public Property SOWING_DATE As String
    Public Property HARVEST_DATE As String
    Public Property SEED_SOURCE As String
    Public Property SEED_COST As String
    Public Property SEED_QUANTITY As Double?
    Public Property PLANTING_AREA As Double?
    Public Property ESTIMATED_HARVEST As Double?
End Class

Partial Public Class Family
    Public Property MEMBERS As Long?
    Public Property ADULTS As Long?
    Public Property CHILDREN As Long?
    Public Property SCHOOL_GOING As Long?
    Public Property HOME_STAYING As Long?
    Public Property MALE As Long?
    Public Property FEMALE As Long?
    Public Property HEAD As String
End Class

Partial Public Class Income
    Public Property BANK As String
    Public Property INCOME_ACGRIC As String
    Public Property INCOME_NON_AGRIC As String
End Class

Partial Public Class Farm

    Public Property FARM_ID As Long?
    Public Property FARM_SURVEY_NO As Long?
    Public Property FARM_POINT_A As String
    Public Property FARM_POINT_B As String
    Public Property FARM_PONT_C As String
    Public Property FARM_POINT_D As String
    Public Property FARM_LAND_OWNERSHIP As String
    Public Property FARM_LAND_YEAR_ACQUIRED As Long?
    Public Property FARM_ADDRESS As String
    Public Property FARM_APPROACH_ROAD As String
    Public Property FARM_TOPOLOGY As String
    Public Property FARM_IRRIGATION_SOURCE As String
    Public Property FARM_TOTAL_AREA As Double?
    Public Property FARM_PICTURE As String
    Public Property FARMER_LAND_MARK As String
End Class

﻿Imports System.Configuration.ConfigurationManager
Imports System.Data.SqlClient
Imports ly_SIME.CORE.cls_util
Imports System.Globalization
Imports System.Threading

Namespace SIMEly

    Public Class cls_Beneficiario

        Dim cnn As New SqlConnection(ConnectionStrings("dbCI_SAPConnectionString").ConnectionString)
        Dim Tbl_beneficiario As DataTable
        Dim Tbl_benficiarioATTRIB As DataTable
        Dim Tbl_benficiarioSOLIC As DataTable
        Dim Tbl_request_cat As DataTable
        Dim utlCORE As New CORE.cls_util
        Public Property id_beneficiario As Integer
        Public Property id_beneficiarioSol As Integer
        Public Property id_beneficiarioATRIB As Integer
        Public Property id_requested As Integer
        Dim cultureINF As CultureInfo

        Public Sub New(Optional ByVal idBEn As Integer = 0, Optional ByVal bndINI_tbl As Boolean = True)

            'Cambiamos la cultura a en-US
            cultureINF = New CultureInfo("en-US")
            Thread.CurrentThread.CurrentCulture = cultureINF

            If bndINI_tbl Then

                Tbl_beneficiario = New DataTable
                Tbl_benficiarioATTRIB = New DataTable
                Tbl_benficiarioSOLIC = New DataTable

                id_beneficiario = idBEn
                init_Beneficiario(id_beneficiario)
                init_BeneficiarioSolicitud(id_beneficiarioSol, id_beneficiario)
                init_BeneficiarioATRIB(id_beneficiarioATRIB, id_beneficiario)

            End If
            


        End Sub


        Public Sub ini_all(ByVal idBen As Integer, Optional ByVal setID As Boolean = False)

            id_beneficiario = idBen
            init_Beneficiario(id_beneficiario)
            init_BeneficiarioSolicitud(id_beneficiarioSol, id_beneficiario)
            init_BeneficiarioATRIB(id_beneficiarioATRIB, id_beneficiario)

            If setID Then

                setBeneficiarioField("id_beneficiario", 0, "id_beneficiario", id_beneficiario)
                setBeneficiarioSOLField("id_beneficiarios_solicitud", 0, "id_beneficiarios_solicitud", id_beneficiarioSol)
                setBeneficiarioATRIBField("id_beneficiario_atributo", 0, "id_beneficiario_atributo", id_beneficiarioATRIB)
                id_beneficiario = 0
                id_beneficiarioSol = 0
                id_beneficiarioATRIB = 0

            End If

        End Sub

        Public Sub reset_beneficiario(ByVal tpComponent As Integer)

            Dim valDateTime As DateTime = CType(Date.Now, DateTime)
            'If tpComponent = 1 Then 'El mismo Componente

            setBeneficiarioField("id_estado_civil", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("id_genero", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_escolaridad", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_municipio", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("id_tipo_beneficiario", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_etnia", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("ID", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("NIT", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("nombre", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("apellido", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("telefono", "", "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("fecha_nacimiento", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("fecha_registro_ORG", valDateTime, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("fecha_registro_CC", valDateTime, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("actividad_principal_ORG", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("siglas_ORG", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("latitud", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("longitud", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("lat_grd", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("lat_min", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("lat_seg", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("long_grd", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("long_min", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("long_seg", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("altura", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("descripcion_ubicacion", "", "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("datecreated", 0, "id_beneficiario", id_beneficiario)
            'setBeneficiarioField("updDate", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_usuario_creo", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("tp_usuario_creo", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_usuario_upd", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("tp_usuario_upd", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("sincronizadoIND", "-1", "id_beneficiario", id_beneficiario) 'Ya existente
            setBeneficiarioField("sincronizadoIND_ME", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("sincronizadoIND_CAP", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("sincronizadoIND_CAPME", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("sincronizadoIND_CRD", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("sincronizadoIND_CRDME", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("LatProyeccionNS", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("LongProyeccionWE", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("codigo_SAPME", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("nombre_beneficiario_archivo", "", "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_tipoIdentificacion", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_tipo_ubicacioncodigo", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_tipo_precisionFicha", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("id_planificacion", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc01", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc02", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc03", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc04", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc05", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc06", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc07", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc08", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("secc09", 0, "id_beneficiario", id_beneficiario)
            setBeneficiarioField("completed", 0, "id_beneficiario", id_beneficiario)


            'setBeneficiarioSOLField("id_beneficiarios_solicitud", 0, "id_beneficiarios_solicitud", id_beneficiarioSol)
            ''id_beneficiarios_solicitud()
            ''id_ficha_proyecto()
            ''id_beneficiario
            ''id_estado_beneficiario()
            ''fecha_solicitud()

            'setBeneficiarioATRIBField("id_beneficiario_atributo", 0, "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("id_beneficiario", 0, "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo1", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo2", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo3", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo4", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo5", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo6", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo7", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo8", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo9", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo10", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo11", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo12", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo13", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo14", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo15", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo16", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo17", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo18", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo19", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo20", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo21", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo22", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo23", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo24", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo25", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo26", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo27", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo28", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo29", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo30", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo31", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo32", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo33", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo34", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo35", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo36", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo37", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo38", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo39", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo40", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo41", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo42", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo43", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo44", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo45", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo46", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo47", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo48", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo49", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("aniomes", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("cultivoapo", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("hectapoyar", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("tipoapoyo", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo50", "", "id_beneficiario_atributo", id_beneficiarioATRIB)
            setBeneficiarioATRIBField("campo51", "", "id_beneficiario_atributo", id_beneficiarioATRIB)


            'Else

            '    setBeneficiarioField("id_beneficiario", 0, "id_beneficiario", id_beneficiario)
            '    setBeneficiarioSOLField("id_beneficiarios_solicitud", 0, "id_beneficiarios_solicitud", id_beneficiarioSol)
            '    setBeneficiarioATRIBField("id_beneficiario_atributo", 0, "id_beneficiario_atributo", id_beneficiarioATRIB)
            'End If

        End Sub


        Public Function reset_beneficiario(ByVal tblBENEF As DataTable, Optional IDcomp As Integer = 0) As DataTable

            Dim valDateTime As DateTime = CType(Date.Now, DateTime)

            tblBENEF.Rows(0).Item("id_estado_civil") = 0
            tblBENEF.Rows(0).Item("id_escolaridad") = 0
            tblBENEF.Rows(0).Item("id_municipio") = 0
            tblBENEF.Rows(0).Item("id_etnia") = 0
            tblBENEF.Rows(0).Item("telefono") = ""
            tblBENEF.Rows(0).Item("fecha_registro_ORG") = valDateTime
            'tblBENEF.Rows(0).Item("fecha_registro_CC") = valDateTime
            tblBENEF.Rows(0).Item("actividad_principal_ORG") = ""
            tblBENEF.Rows(0).Item("siglas_ORG") = ""
            tblBENEF.Rows(0).Item("latitud") = 0
            tblBENEF.Rows(0).Item("longitud") = 0
            tblBENEF.Rows(0).Item("lat_grd") = 0
            tblBENEF.Rows(0).Item("lat_min") = 0
            tblBENEF.Rows(0).Item("lat_seg") = 0
            tblBENEF.Rows(0).Item("long_grd") = 0
            tblBENEF.Rows(0).Item("long_min") = 0
            tblBENEF.Rows(0).Item("long_seg") = 0
            tblBENEF.Rows(0).Item("altura") = 0
            tblBENEF.Rows(0).Item("descripcion_ubicacion") = ""

            'tblBENEF.Rows(0).Item("id_usuario_creo") = 0
            'tblBENEF.Rows(0).Item("tp_usuario_creo") = 0
            'tblBENEF.Rows(0).Item("id_usuario_upd") = 0
            'tblBENEF.Rows(0).Item("tp_usuario_upd") = 0
            tblBENEF.Rows(0).Item("LatProyeccionNS") = ""
            tblBENEF.Rows(0).Item("LongProyeccionWE") = ""
            tblBENEF.Rows(0).Item("codigo_SAPME") = ""
            tblBENEF.Rows(0).Item("nombre_beneficiario_archivo") = ""
            tblBENEF.Rows(0).Item("id_tipoIdentificacion") = 0

            tblBENEF.Rows(0).Item("id_tipo_precisionFicha") = 1

            Select Case IDcomp
                Case 1
                    tblBENEF.Rows(0).Item("id_tipo_ubicacioncodigo") = 4
                Case 4
                    tblBENEF.Rows(0).Item("id_tipo_ubicacioncodigo") = 1
                Case 5
                    tblBENEF.Rows(0).Item("id_tipo_ubicacioncodigo") = 1
                Case 2
                    tblBENEF.Rows(0).Item("id_tipo_ubicacioncodigo") = 5
                Case Else
                    tblBENEF.Rows(0).Item("id_tipo_ubicacioncodigo") = 0
            End Select

            tblBENEF.Rows(0).Item("secc01") = 0
            tblBENEF.Rows(0).Item("secc02") = 0
            tblBENEF.Rows(0).Item("secc03") = 0
            tblBENEF.Rows(0).Item("secc04") = 0
            tblBENEF.Rows(0).Item("secc05") = 0
            tblBENEF.Rows(0).Item("secc06") = 0
            tblBENEF.Rows(0).Item("secc07") = 0
            tblBENEF.Rows(0).Item("secc08") = 0
            tblBENEF.Rows(0).Item("secc09") = 0
            tblBENEF.Rows(0).Item("completed") = 0
            tblBENEF.Rows(0).Item("fill_state") = 1


            Return tblBENEF

        End Function



        Public Function reset_beneficiarioATTR(ByVal tblBENEF_ATTR As DataTable, Optional IDcomp As Integer = 0) As DataTable


            'tblBENEF_ATTR.Rows(0).Item("id_beneficiario_atributo") = ""
            tblBENEF_ATTR.Rows(0).Item("id_beneficiario") = 0
            tblBENEF_ATTR.Rows(0).Item("campo1") = ""
            tblBENEF_ATTR.Rows(0).Item("campo2") = ""
            tblBENEF_ATTR.Rows(0).Item("campo3") = ""
            tblBENEF_ATTR.Rows(0).Item("campo4") = ""
            tblBENEF_ATTR.Rows(0).Item("campo5") = ""
            tblBENEF_ATTR.Rows(0).Item("campo6") = ""

            If IDcomp = 1 Then
                tblBENEF_ATTR.Rows(0).Item("campo7") = "FINCA"
            Else
                tblBENEF_ATTR.Rows(0).Item("campo7") = "CASA"
            End If

            tblBENEF_ATTR.Rows(0).Item("campo8") = ""
            tblBENEF_ATTR.Rows(0).Item("campo9") = ""
            tblBENEF_ATTR.Rows(0).Item("campo10") = ""
            tblBENEF_ATTR.Rows(0).Item("campo11") = ""
            tblBENEF_ATTR.Rows(0).Item("campo12") = ""
            tblBENEF_ATTR.Rows(0).Item("campo13") = ""
            tblBENEF_ATTR.Rows(0).Item("campo14") = ""
            tblBENEF_ATTR.Rows(0).Item("campo15") = ""
            tblBENEF_ATTR.Rows(0).Item("campo16") = ""
            tblBENEF_ATTR.Rows(0).Item("campo17") = ""
            tblBENEF_ATTR.Rows(0).Item("campo18") = ""


            If IDcomp = 1 Then
                tblBENEF_ATTR.Rows(0).Item("campo19") = "SI"
            Else
                tblBENEF_ATTR.Rows(0).Item("campo19") = "NO"
            End If

            tblBENEF_ATTR.Rows(0).Item("campo20") = ""
            tblBENEF_ATTR.Rows(0).Item("campo21") = ""
            tblBENEF_ATTR.Rows(0).Item("campo22") = ""
            tblBENEF_ATTR.Rows(0).Item("campo23") = ""
            tblBENEF_ATTR.Rows(0).Item("campo24") = ""
            tblBENEF_ATTR.Rows(0).Item("campo25") = ""
            tblBENEF_ATTR.Rows(0).Item("campo26") = ""
            tblBENEF_ATTR.Rows(0).Item("campo27") = ""
            tblBENEF_ATTR.Rows(0).Item("campo28") = ""
            tblBENEF_ATTR.Rows(0).Item("campo29") = ""
            tblBENEF_ATTR.Rows(0).Item("campo30") = ""
            tblBENEF_ATTR.Rows(0).Item("campo31") = ""
            tblBENEF_ATTR.Rows(0).Item("campo32") = ""
            tblBENEF_ATTR.Rows(0).Item("campo33") = ""
            tblBENEF_ATTR.Rows(0).Item("campo34") = ""
            tblBENEF_ATTR.Rows(0).Item("campo35") = ""
            tblBENEF_ATTR.Rows(0).Item("campo36") = ""
            tblBENEF_ATTR.Rows(0).Item("campo37") = ""
            tblBENEF_ATTR.Rows(0).Item("campo38") = ""
            tblBENEF_ATTR.Rows(0).Item("campo39") = ""
            tblBENEF_ATTR.Rows(0).Item("campo40") = ""
            tblBENEF_ATTR.Rows(0).Item("campo41") = ""
            tblBENEF_ATTR.Rows(0).Item("campo42") = ""
            tblBENEF_ATTR.Rows(0).Item("campo43") = ""
            tblBENEF_ATTR.Rows(0).Item("campo44") = ""
            tblBENEF_ATTR.Rows(0).Item("campo45") = ""
            tblBENEF_ATTR.Rows(0).Item("campo46") = ""
            tblBENEF_ATTR.Rows(0).Item("campo47") = ""
            tblBENEF_ATTR.Rows(0).Item("campo48") = ""
            tblBENEF_ATTR.Rows(0).Item("campo49") = ""
            tblBENEF_ATTR.Rows(0).Item("aniomes") = ""
            tblBENEF_ATTR.Rows(0).Item("cultivoapo") = ""
            tblBENEF_ATTR.Rows(0).Item("hectapoyar") = ""
            tblBENEF_ATTR.Rows(0).Item("tipoapoyo") = ""
            tblBENEF_ATTR.Rows(0).Item("campo50") = ""
            tblBENEF_ATTR.Rows(0).Item("campo51") = ""

            Return tblBENEF_ATTR

        End Function

        'Private Sub setBeneficiario()

        '    Tbl_beneficiario.TableName = "tme_beneficiario"
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_beneficiario", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_estado_civil", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_genero", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_escolaridad", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_municipio", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_tipo_beneficiario", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_etnia", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("ID", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("NIT", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("nombre", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("apellido", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("telefono", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("fecha_nacimiento", GetType(Date)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("fecha_registro_ORG", GetType(Date)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("fecha_registro_CC", GetType(Date)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("actividad_principal_ORG", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("siglas_ORG", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("latitud", GetType(Decimal)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("longitud", GetType(Decimal)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("lat_grd", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("lat_min", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("lat_seg", GetType(Decimal)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("long_grd", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("long_min", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("long_seg", GetType(Decimal)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("altura", GetType(Decimal)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("descripcion_ubicacion", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("datecreated", GetType(DateTime)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_usuario_creo", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("sincronizadoIND", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("sincronizadoIND_ME", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("sincronizadoIND_CAP", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("sincronizadoIND_CAPME", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("sincronizadoIND_CRD", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("sincronizadoIND_CRDME", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("LatProyeccionNS", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("LongProyeccionWE", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("codigo_SAPME", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("nombre_beneficiario_archivo", GetType(String)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_tipoIdentificacion", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_tipo_ubicacioncodigo", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_tipo_precisionFicha", GetType(Integer)))
        '    Tbl_beneficiario.Columns.Add(New DataColumn("id_planificacion", GetType(Integer)))


        'End Sub


        Public Sub setBeneficiarioField(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            Tbl_beneficiario = utlCORE.setDTval(Tbl_beneficiario, campoSearch, campo, valorSearch, valor)

        End Sub

        Public Sub setBeneficiarioSOLField(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            Tbl_benficiarioSOLIC = utlCORE.setDTval(Tbl_benficiarioSOLIC, campoSearch, campo, valorSearch, valor)

        End Sub

        Public Sub setBeneficiarioATRIBField(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            Tbl_benficiarioATTRIB = utlCORE.setDTval(Tbl_benficiarioATTRIB, campoSearch, campo, valorSearch, valor)

        End Sub

        Public Sub setRequestField(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            Tbl_request_cat = utlCORE.setDTval(Tbl_request_cat, campoSearch, campo, valorSearch, valor)

        End Sub

        Public Function getBeneficiarioField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(Tbl_beneficiario, campoSearch, campo, valorSearch)

        End Function

        Public Function getCatField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(Tbl_request_cat, campoSearch, campo, valorSearch)

        End Function

        Public Function getBeneficiarioSolField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(Tbl_benficiarioSOLIC, campoSearch, campo, valorSearch)

        End Function

        Public Function getBeneficiarioATRIBField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(Tbl_benficiarioATTRIB, campoSearch, campo, valorSearch)

        End Function

        Public Sub init_Beneficiario(Optional ByVal idBen As Integer = 0)

            If idBen <> id_beneficiario Then
                id_beneficiario = idBen
            End If

            Tbl_beneficiario = utlCORE.setObjeto("tme_Beneficiario", "id_beneficiario", id_beneficiario).Copy

        End Sub


        Public Sub init_BeneficiarioSolicitud(Optional ByVal idBenSol As Integer = 0, Optional idBen As Integer = 0)

            If idBen > 0 Then
                Tbl_benficiarioSOLIC = utlCORE.setObjeto("tme_BeneficiarioSolicitud", "id_beneficiario", idBen)
                id_beneficiarioSol = CType(getBeneficiarioSolField("id_beneficiarios_solicitud", "id_beneficiario", idBen), Integer)
            ElseIf idBenSol <> id_beneficiarioSol Then
                id_beneficiarioSol = idBenSol
                Tbl_benficiarioSOLIC = utlCORE.setObjeto("tme_BeneficiarioSolicitud", "id_beneficiarios_solicitud", id_beneficiarioSol)
            Else
                Tbl_benficiarioSOLIC = utlCORE.setObjeto("tme_BeneficiarioSolicitud", "id_beneficiarios_solicitud", id_beneficiarioSol)
            End If

        End Sub



        Public Sub init_BeneficiarioATRIB(Optional ByVal idBenAtrib As Integer = 0, Optional ByVal idBen As Integer = 0)


            If idBen > 0 Then
                Tbl_benficiarioATTRIB = utlCORE.setObjeto("tme_BeneficiarioAtributos", "id_beneficiario", idBen)
                id_beneficiarioATRIB = CType(getBeneficiarioATRIBField("id_beneficiario_atributo", "id_beneficiario", idBen), Integer)
            ElseIf idBenAtrib <> id_beneficiarioATRIB Then
                id_beneficiarioATRIB = idBenAtrib
                Tbl_benficiarioATTRIB = utlCORE.setObjeto("tme_BeneficiarioAtributos", "id_beneficiario_atributo", id_beneficiarioATRIB)
            Else
                Tbl_benficiarioATTRIB = utlCORE.setObjeto("tme_BeneficiarioAtributos", "id_beneficiario_atributo", id_beneficiarioATRIB)
            End If


        End Sub



        Public Sub init_cat_Request(Optional ByVal idReq As Integer = 0)

            If idReq <> id_requested Then
                id_requested = idReq
            End If

            Tbl_request_cat = utlCORE.setObjeto("tme_request_cat", "id_request_cat", id_requested).Copy

        End Sub



        Public Function save_Beneficiario() As Integer

            Dim RES As Integer

            RES = utlCORE.SaveObjeto("tme_Beneficiario", Tbl_beneficiario, "id_beneficiario", id_beneficiario)

            If RES <> -1 Then
                save_Beneficiario = RES
                id_beneficiario = RES
                setBeneficiarioField("id_beneficiario", id_beneficiario, "id_beneficiario", 0)
            Else
                save_Beneficiario = RES
            End If

        End Function



        Public Function save_Request() As Integer

            Dim RES As Integer

            RES = utlCORE.SaveObjeto("tme_request_cat", Tbl_request_cat, "id_request_cat", id_requested)

            If RES <> -1 Then
                save_Request = RES
                id_requested = RES
                setRequestField("id_request_cat", id_requested, "id_request_cat", 0)
            Else
                save_Request = RES
            End If

        End Function

        Public Function save_BeneficiarioSOLIC() As Integer

            Dim RES As Integer

            RES = utlCORE.SaveObjeto("tme_BeneficiarioSolicitud", Tbl_benficiarioSOLIC, "id_beneficiarios_solicitud", id_beneficiarioSol)

            If RES <> -1 Then
                save_BeneficiarioSOLIC = RES
                id_beneficiarioSol = RES
                setBeneficiarioSOLField("id_beneficiarios_solicitud", id_beneficiarioSol, "id_beneficiarios_solicitud", 0)

            Else
                save_BeneficiarioSOLIC = RES
            End If

        End Function



        Public Function save_BeneficiarioATRIB() As Integer
            Dim RES As Integer
            RES = utlCORE.SaveObjeto("tme_BeneficiarioAtributos", Tbl_benficiarioATTRIB, "id_beneficiario_atributo", id_beneficiarioATRIB)

            If RES <> -1 Then
                save_BeneficiarioATRIB = RES
                id_beneficiarioATRIB = RES
                setBeneficiarioATRIBField("id_beneficiario_atributo", id_beneficiarioATRIB, "id_beneficiario_atributo", 0)
            Else
                save_BeneficiarioATRIB = RES
            End If

        End Function


        Public Function SaveRequest_CORR_status(ByVal id_requested As Integer, ByVal id_confirm As Integer) As Integer

            Dim tbl_benficiariosRequest As DataTable
            Dim tbl_Benef_ATRIB_tmp As DataTable


            Dim strSQL As String = String.Format(" Select a.id_beneficiario, b.id_beneficiario_atributo, c.rq_confirm  " & _
                                                  "  from  tme_beneficiario a " & _
                                                  "   inner join tme_BeneficiarioAtributos b on (a.id_beneficiario = b.id_beneficiario) " & _
                                                  "    inner join tme_request_cat c on ( convert(int,SUBSTRING(b.campo3,6, LEN(b.campo3) -7) ) = c.id_request_cat ) " & _
                                                  "    where  (CHARINDEX('<<RQ:', b.campo3) > 0) " & _
                                                  "     and c.id_type_request = 1 " & _
                                                  "      and c.id_request_cat = {0} " & _
                                                  "       and c.id_confirm = {1} ", id_requested, id_confirm)

            tbl_benficiariosRequest = utlCORE.setObjeto("tme_request_cat", "id_request_cat", id_requested, strSQL).Copy

            Dim RES As Integer
            SaveRequest_CORR_status = -1

            For Each dt As DataRow In tbl_benficiariosRequest.Rows

                tbl_Benef_ATRIB_tmp = utlCORE.setObjeto("tme_BeneficiarioAtributos", "id_beneficiario_atributo", dt.Item("id_beneficiario_atributo")).Copy
                tbl_Benef_ATRIB_tmp = utlCORE.setDTval(tbl_Benef_ATRIB_tmp, "id_beneficiario_atributo", "campo3", dt.Item("id_beneficiario_atributo"), dt.Item("rq_confirm"))

                RES = utlCORE.SaveObjeto("tme_BeneficiarioAtributos", tbl_Benef_ATRIB_tmp, "id_beneficiario_atributo", dt.Item("id_beneficiario_atributo"))

                If RES <> -1 Then
                    SaveRequest_CORR_status = RES
                Else
                    SaveRequest_CORR_status = RES
                    Exit For
                End If

            Next

            Return SaveRequest_CORR_status

        End Function




        Public Function SaveRequest_VER_status(ByVal id_requested As Integer, ByVal id_confirm As Integer) As Integer

            Dim tbl_benficiariosRequest As DataTable
            Dim tbl_Benef_ATRIB_tmp As DataTable

            Dim strSQL = String.Format(" Select a.id_beneficiario, b.id_beneficiario_atributo, c.rq_confirm " & _
                                   "   from  tme_beneficiario a " & _
                                   "    inner join tme_BeneficiarioAtributos b on (a.id_beneficiario = b.id_beneficiario) " & _
                                   "     inner join tme_request_cat c on ( convert(int,SUBSTRING(b.campo4,6, LEN(b.campo4) -7) ) = c.id_request_cat ) " & _
                                   "      where  (CHARINDEX('<<RQ:', b.campo4) > 0) " & _
                                   "       and c.id_type_request = 2 " & _
                                   "         and c.id_confirm = {1} " & _
                                   "          and c.id_request_cat = {0} ", id_requested, id_confirm)

            tbl_benficiariosRequest = utlCORE.setObjeto("tme_request_cat", "id_request_cat", id_requested, strSQL).Copy

            Dim RES As Integer
            SaveRequest_VER_status = -1

            For Each dt As DataRow In tbl_benficiariosRequest.Rows

                tbl_Benef_ATRIB_tmp = utlCORE.setObjeto("tme_BeneficiarioAtributos", "id_beneficiario_atributo", dt.Item("id_beneficiario_atributo")).Copy
                tbl_Benef_ATRIB_tmp = utlCORE.setDTval(tbl_Benef_ATRIB_tmp, "id_beneficiario_atributo", "campo4", dt.Item("id_beneficiario_atributo"), dt.Item("rq_confirm"))

                RES = utlCORE.SaveObjeto("tme_BeneficiarioAtributos", tbl_Benef_ATRIB_tmp, "id_beneficiario_atributo", dt.Item("id_beneficiario_atributo"))

                If RES <> -1 Then
                    SaveRequest_VER_status = RES
                Else
                    SaveRequest_VER_status = RES
                    Exit For
                End If

            Next

            Return SaveRequest_VER_status

        End Function


        Public Function get_Instrumento(ByVal idInstrumento As Integer) As DataSet

            'Da información de cualquier instrumento del sistema SIME, recibiendo como parametro el id del instrumento
            Dim Sql = "SELECT id_instrumento, nombre_instrumento, nombre_tabla_asoc FROM tme_instrumento WHERE id_instrumento=" & idInstrumento
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("proyecto")
            dm.Fill(ds, "proyecto")
            get_Instrumento = ds

        End Function


        Public Function chk_Beneficiario(ByVal IDdoc As String, ByVal IDficha As Integer) As DataTable

            'Verifica la existencia del beneficiario ya sea en un proyecto del mismo componente 
            ' o en un proyecto de otro componente

            Dim tblRESULT As New DataTable

            tblRESULT.TableName = "RES"
            tblRESULT.Columns.Add(New DataColumn("id_result", GetType(Integer)))
            tblRESULT.Columns.Add(New DataColumn("id_beneficiario", GetType(Integer)))
            tblRESULT.Columns.Add(New DataColumn("id_ficha_proyecto", GetType(Integer)))
            tblRESULT.Columns.Add(New DataColumn("nombre_estado_beneficiario", GetType(String)))

            Dim valor As Integer = 0
            Dim id_benef As Integer = 0
            Dim id_ficha As Integer = 0
            Dim estado_ben As String = ""

            Dim sql As String
            sql = String.Format(" SELECT id_componente FROM tme_Ficha_Proyecto WHERE id_ficha_proyecto={0} ", IDficha)
            Dim dmComp As New SqlDataAdapter(sql, cnn)
            Dim dsComp As New DataSet("componente")
            dmComp.Fill(dsComp, "componente")

            'sql = String.Format(" SELECT id_beneficiario, id_ficha_proyecto, id_estado_beneficiario, ID,  " & _
            '                     "  nombre_estado_beneficiario FROM vw_tme_beneficiario WHERE ID='{0}'  " & _
            '                     "   AND ( (id_ficha_proyecto={1}) OR (id_componente={2})) ORDER BY id_beneficiario DESC ", IDdoc, IDficha, dsComp.Tables("componente").Rows(0).Item("id_componente"))

            sql = String.Format(" SELECT id_beneficiario, id_ficha_proyecto, id_estado_beneficiario, ID,  " & _
                                "  nombre_estado_beneficiario FROM vw_tme_beneficiario WHERE ID='{0}'  " & _
                                "   AND (id_ficha_proyecto={1}) ORDER BY id_beneficiario DESC ", IDdoc, IDficha)


            Dim dm As New SqlDataAdapter(sql, cnn)
            Dim ds As New DataSet("beneficiario")
            dm.Fill(ds, "beneficiario")

            If ds.Tables("beneficiario").Rows.Count > 0 Then

                valor = 1 'Beneficiario ya registrado
                id_benef = ds.Tables("beneficiario").Rows(0).Item("id_beneficiario")
                id_ficha = ds.Tables("beneficiario").Rows(0).Item("id_ficha_proyecto")
                estado_ben = ds.Tables("beneficiario").Rows(0).Item("nombre_estado_beneficiario")

            Else

                sql = String.Format(" SELECT id_beneficiario, id_ficha_proyecto, id_estado_beneficiario, ID,  " & _
                                     "  nombre_estado_beneficiario FROM vw_tme_beneficiario WHERE ID='{0}'  " & _
                                     "   AND ( id_componente={1}) ORDER BY id_beneficiario DESC ", IDdoc, dsComp.Tables("componente").Rows(0).Item("id_componente"))

                ds.Tables.Add("Beneficiario2")
                dm.SelectCommand.CommandText = sql
                dm.Fill(ds, "Beneficiario2")

                If ds.Tables("Beneficiario2").Rows.Count > 0 Then

                    valor = 2 'Beneficiario ya registrado en el mismo componente
                    id_benef = ds.Tables("beneficiario2").Rows(0).Item("id_beneficiario")
                    id_ficha = ds.Tables("beneficiario2").Rows(0).Item("id_ficha_proyecto")
                    estado_ben = ds.Tables("beneficiario2").Rows(0).Item("nombre_estado_beneficiario")

                Else


                    sql = String.Format("SELECT id_beneficiario, id_ficha_proyecto, nombre_estado_beneficiario FROM vw_tme_beneficiario WHERE ID='{0}'  ORDER BY id_beneficiario DESC ", IDdoc)
                    ds.Tables.Add("benef2")
                    dm.SelectCommand.CommandText = sql
                    dm.Fill(ds, "benef2")

                    If ds.Tables("benef2").Rows.Count > 0 Then

                        valor = 3 'Beneficiario ya registrado en un proyecto de otro componente
                        id_benef = ds.Tables("benef2").Rows(0).Item("id_beneficiario")
                        id_ficha = ds.Tables("benef2").Rows(0).Item("id_ficha_proyecto")
                        estado_ben = ds.Tables("benef2").Rows(0).Item("nombre_estado_beneficiario")

                    Else

                        valor = 0 'Beneficiario no registrado
                        id_benef = 0
                        id_ficha = 0
                        estado_ben = ""

                    End If


                End If


            End If

            tblRESULT.Rows.Add(New Object() {valor, id_benef, id_ficha, estado_ben})

            chk_Beneficiario = tblRESULT

        End Function




        Function find_cat_Request(ByVal idType As Integer, ByVal txtName As String, ByVal IDMuni As Integer) As Integer

            Dim idStatus As Integer = 1 ' Pendientes de aprobar

            Dim sql As String
            sql = String.Format(" select id_request_cat from tme_request_cat a " & _
                                "  where id_type_request = {0} " & _
                                "    and id_confirm = {1} " & _
                                "     and id_aux = {3} " & _
                                "     and upper(ltrim(rtrim(rq_text))) = '{2}' ", idType, idStatus, txtName, IDMuni)

            Dim dmComp As New SqlDataAdapter(sql, cnn)
            Dim dsComp As New DataSet("requests")
            dmComp.Fill(dsComp, "requests")


            If dsComp.Tables("requests").Rows.Count > 0 Then
                find_cat_Request = dsComp.Tables("requests").Rows(0).Item("id_request_cat")
            Else
                find_cat_Request = 0
            End If


        End Function




        Public Function chk_BeneficiarioOTHER(ByVal IDdoc As String, ByVal IDficha As Integer) As DataTable

            'Verifica la existencia del beneficiario ya sea en un proyecto del mismo componente 
            ' o en un proyecto de otro componente

            Dim tblRESULT As New DataTable

            tblRESULT.TableName = "RES"
            tblRESULT.Columns.Add(New DataColumn("id_result", GetType(Integer)))
            tblRESULT.Columns.Add(New DataColumn("id_beneficiario", GetType(Integer)))
            tblRESULT.Columns.Add(New DataColumn("id_ficha_proyecto", GetType(Integer)))
            tblRESULT.Columns.Add(New DataColumn("nombre_estado_beneficiario", GetType(String)))

            Dim valor As Integer = 0
            Dim id_benef As Integer = 0
            Dim id_ficha As Integer = 0
            Dim estado_ben As String = ""

            Dim sql As String
            sql = String.Format(" SELECT id_componente FROM tme_Ficha_Proyecto WHERE id_ficha_proyecto={0} ", IDficha)
            Dim dmComp As New SqlDataAdapter(sql, cnn)
            Dim dsComp As New DataSet("componente")
            dmComp.Fill(dsComp, "componente")


            Dim dm As New SqlDataAdapter(sql, cnn)
            Dim ds As New DataSet("beneficiario")


            sql = String.Format(" SELECT id_beneficiario, id_ficha_proyecto, id_estado_beneficiario, ID,  " & _
                                 "  nombre_estado_beneficiario FROM vw_tme_beneficiario WHERE ID='{0}'  " & _
                                 "   AND ( id_componente={1}) AND id_beneficiario <> {2} ORDER BY id_beneficiario DESC ", IDdoc, dsComp.Tables("componente").Rows(0).Item("id_componente"), id_beneficiario)

            ds.Tables.Add("Beneficiario2")
            dm.SelectCommand.CommandText = sql
            dm.Fill(ds, "Beneficiario2")

            If ds.Tables("Beneficiario2").Rows.Count > 0 Then

                valor = 2 'Beneficiario ya registrado en el mismo componente
                id_benef = ds.Tables("beneficiario2").Rows(0).Item("id_beneficiario")
                id_ficha = ds.Tables("beneficiario2").Rows(0).Item("id_ficha_proyecto")
                estado_ben = ds.Tables("beneficiario2").Rows(0).Item("nombre_estado_beneficiario")

            Else


                sql = String.Format("SELECT id_beneficiario, id_ficha_proyecto, nombre_estado_beneficiario FROM vw_tme_beneficiario WHERE ID='{0}'   AND id_beneficiario <> {1} ORDER BY id_beneficiario DESC ", IDdoc, id_beneficiario)
                ds.Tables.Add("benef2")
                dm.SelectCommand.CommandText = sql
                dm.Fill(ds, "benef2")

                If ds.Tables("benef2").Rows.Count > 0 Then

                    valor = 3 'Beneficiario ya registrado en un proyecto de otro componente
                    id_benef = ds.Tables("benef2").Rows(0).Item("id_beneficiario")
                    id_ficha = ds.Tables("benef2").Rows(0).Item("id_ficha_proyecto")
                    estado_ben = ds.Tables("benef2").Rows(0).Item("nombre_estado_beneficiario")

                Else

                    valor = 0 'Beneficiario no registrado
                    id_benef = 0
                    id_ficha = 0
                    estado_ben = ""

                End If


            End If



            tblRESULT.Rows.Add(New Object() {valor, id_benef, id_ficha, estado_ben})

            chk_BeneficiarioOTHER = tblRESULT

        End Function

        Public Function get_DatosFicha_Proyecto(ByVal idFicha As Integer) As DataSet

            'devuelve la información de cualquier ficha de proyecto del sistema SIME, recibiendo como parametro el id de la ficha
            Dim Sql = "SELECT * FROM  tme_Ficha_Proyecto WHERE id_ficha_proyecto=" & idFicha

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("ficha_proyecto")
            dm.Fill(ds, "ficha_proyecto")
            get_DatosFicha_Proyecto = ds

        End Function



        Public Function get_EstadoCAT(ByVal idEstado As Integer) As String

            'devuelve el estado actual en que se encuentra la autorizacion de los beneficiarios.
            Dim Sql = "select rqs_name from tme_request_status WHERE id_request_status=" & idEstado

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Estado_catalogo")
            dm.Fill(ds, "Estado_catalogo")
            get_EstadoCAT = ds.Tables(0).Rows(0).Item("rqs_name")

        End Function


        Public Function get_Planificacion(ByVal id_proy As Integer) As Integer

            'Devuelve la planificación en que se esta ejecutando el proyecto
            Dim Sql = String.Format("select id_planificacion from t_planificacion where activo = 'SI' and id_proyecto = {0}", id_proy)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Planificacion")
            dm.Fill(ds, "Planificacion")
            get_Planificacion = ds.Tables.Item("Planificacion").Rows(0).Item("id_planificacion")


        End Function




        Public Function get_Generalidades_Instrumento(ByVal idInstrumento As Integer) As DataTable

            'devuelve la información de todas las generalidades registradas para un instrumento en el sistema SIME, recibiendo como parametro el id del instrumento
            Dim Sql = String.Format("SELECT id_instrumento, id_generalidad, nombre_generalidad FROM tme_Generalidades WHERE (id_instrumento IN (SELECT id_instrumento FROM tme_Instrumento WHERE (id_instrumento = {0})))", idInstrumento)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Generalidades")
            dm.Fill(ds, "Generalidades")
            get_Generalidades_Instrumento = ds.Tables.Item("Generalidades")

        End Function



        Public Function get_Pregunta_Generalidades(ByVal idGeneralidad As Integer) As DataSet

            'devuelve la información de todas las pregunstas establecidas para una generalidad en el sistema SIME, recibiendo como parametro el id de la generalidad
            Dim Sql = String.Format("SELECT * FROM tme_CatalogoPreguntas WHERE visible='SI' AND id_generalidad={0} ORDER BY correlativo", idGeneralidad)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CatalogoPreguntas")
            dm.Fill(ds, "CatalogoPreguntas")
            get_Pregunta_Generalidades = ds

        End Function


        Public Function get_Preguntas(ByVal idPregunta As Integer) As DataSet

            'devuelve la información de una pregunta en especifico independiente de la generalidad en el sistema SIME, recibiendo como parametro el id de la pregunta
            Dim Sql = String.Format("SELECT * FROM tme_CatalogoPreguntas WHERE visible='SI' AND id_pregunta={0} ", idPregunta)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Preguntas")
            dm.Fill(ds, "Preguntas")
            get_Preguntas = ds

        End Function


        Public Function get_Pregunta_GeneralidadesN(ByVal idGeneralidad As Integer) As Integer

            'Devuelve el total de todas las pregunstas establecidas para una generalidad en el sistema SIME, recibiendo como parametro el id de la generalidad
            Dim Sql = String.Format("SELECT count(*) as N FROM tme_CatalogoPreguntas WHERE visible='SI' AND id_generalidad= {0} ", idGeneralidad)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Preguntas")
            dm.Fill(ds, "Preguntas")
            get_Pregunta_GeneralidadesN = ds.Tables.Item("Preguntas").Rows(0).Item("N")

        End Function



        Public Function get_Respuestas_Preguntas(ByVal idPregunta As Integer, Optional ByVal idOrden As Integer = 0) As DataTable

            'devuelve la información de todas las Respuestas según la preguntas registradas en el sistema SIME, recibiendo como parametro el id de la pregunta
            Dim Sql = String.Format("SELECT * FROM vw_tme_CatalogoRespuestas WHERE id_pregunta={0}", idPregunta)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim nTable As String = "CatRespuestas" & idOrden.ToString
            Dim ds As New DataSet(nTable)
            dm.Fill(ds, nTable)
            get_Respuestas_Preguntas = ds.Tables(nTable)

        End Function




        Public Function get_Beneficiario_Datos(ByVal strCampo As String, ByVal idBeneficiario As Integer) As DataSet

            'devuelve la última información registrada de los beneficiarios en los instrumentos registrado ene l sistema SIME, recibiendo como  resultado el campo de donde tomar el valor, el ID del beneficiario que corresponde al beneficiario a volver a registrar.
            Dim Sql = String.Format("SELECT {0} FROM tme_BeneficiarioAtributos WHERE id_beneficiario={1}", strCampo, idBeneficiario)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim nTable As String = "ItemSelect"
            Dim ds As New DataSet(nTable)
            dm.Fill(ds, nTable)
            get_Beneficiario_Datos = ds

        End Function


        Public Function get_Beneficiario_DatosVW(ByVal idBeneficiario As Integer) As DataTable

            Dim dsBeneficiario As New DataSet()
            'Devuelve la información de un beneficiarío a partir de la vista vw_tme_beneficiario
            Dim Sql = String.Format(" SELECT * FROM vw_tme_beneficiario WHERE id_beneficiario={0} ", idBeneficiario)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            dsBeneficiario.Tables.Add("tblBeneficiario")

            dm.Fill(dsBeneficiario, "tblBeneficiario")
            get_Beneficiario_DatosVW = dsBeneficiario.Tables("tblBeneficiario")

        End Function



        Public Function get_Beneficiario_Atributos(ByVal idBeneficiario As Integer) As DataTable

            Dim dsBeneficiario As New DataSet()
            'Devuelve la información de un beneficiarío a partir de la vista vw_tme_beneficiario
            Dim Sql = String.Format(" select * from tme_BeneficiarioAtributos WHERE id_beneficiario={0} ", idBeneficiario)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            dsBeneficiario.Tables.Add("tblBeneficiarioATT")

            dm.Fill(dsBeneficiario, "tblBeneficiarioATT")
            get_Beneficiario_Atributos = dsBeneficiario.Tables("tblBeneficiarioATT")

        End Function


        Public Function get_Sectores_Ficha(ByVal idFicha As Integer) As DataTable

            'devuelve la información de todas las generalidades registradas para un instrumento en el sistema SIME, recibiendo como parametro el id del instrumento
            Dim Sql = String.Format("Select id_sector_me, nombre_sector_me from VW_GR_SECTORES_FICHAS_PROD  where id_ficha_proyecto ={0}", idFicha)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Sectores")
            dm.Fill(ds, "Sectores")
            get_Sectores_Ficha = ds.Tables.Item("Sectores")

        End Function


        Public Function get_Sectores_FichaV(ByVal idFicha As Integer, ByVal strText As String) As Integer

            Dim Sql = String.Format("Select id_sector_me, nombre_sector_me from VW_GR_SECTORES_FICHAS_PROD  where id_ficha_proyecto ={0} and nombre_sector_me like '{1}' ", idFicha, Trim(strText))

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")

            If ds.Tables.Item("CC").Rows.Count > 0 Then

                get_Sectores_FichaV = ds.Tables.Item("CC").Rows(0).Item("id_sector_me")

            Else

                get_Sectores_FichaV = 0

            End If


        End Function

        Public Function get_Tipos_Doc(Optional ByVal idDoc As Integer = 0) As DataTable

            Dim bolcondicion As Integer

            bolcondicion = If(idDoc = 0, 1, 0)

            'devuelve la información de todos los tipos de identificación que pueden presentar los beneficiarios en el sistema SIME, recibiendo como parametro el id del tipo de documento
            Dim Sql = String.Format("SELECT id_tipoIdentificacion, nombre_tipoId FROM tme_BeneficiarioTipoIdentificacion WHERE ( id_tipoIdentificacion = {0} or 1={1} ) and id_tipoIdentificacion <> 1 ", idDoc, bolcondicion)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Documentos")
            dm.Fill(ds, "Documentos")

            'If ds.Tables.Item("Documentos").Rows.Count > 1 Then
            '    ds.Tables.Item("Documentos").Rows.Add(New Object() {0, "--SELECCIONE--"})
            'End If

            get_Tipos_Doc = ds.Tables.Item("Documentos")

        End Function




        Public Function get_Depto_Ficha(ByVal idFicha As Integer) As DataTable


            'devuelve el departamento de donde pertenece una ficha de proyecto en el sistema SIME, recibiendo como parametro el id de la ficha
            Dim Sql = String.Format("SELECT DISTINCT tme_Departamento.id_departamento,  " & _
                                    " tme_Departamento.nombre_depto, " & _
                                    "  tme_FichaMunicipios.id_ficha_proyecto " & _
                                    "     FROM tme_Departamento " & _
                                    "      INNER JOIN tme_Municipios ON tme_Departamento.id_departamento = tme_Municipios.id_departamento " & _
                                    "        INNER JOIN tme_FichaMunicipios ON tme_Municipios.id_municipio = tme_FichaMunicipios.id_municipio " & _
                                    "         WHERE (tme_FichaMunicipios.id_ficha_proyecto = {0})", idFicha)


            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Deptos")
            dm.Fill(ds, "Deptos")

            If ds.Tables.Item("Deptos").Rows.Count > 1 Then
                ds.Tables.Item("Deptos").Rows.Add(New Object() {0, "--SELECCIONE--"})
            End If

            get_Depto_Ficha = ds.Tables.Item("Deptos")

        End Function




        Public Function get_Grupo_FamiliarTMP(ByVal idTemp As String) As DataTable


            'Devuelve todos los miembros del grupo Familiar agregados temporalmente
            Dim Sql = String.Format("   SELECT a.id_grupoFamiliarTemp,  " & _
                                    "  a.id_temp, " & _
                                    "  a.identificacion, " & _
                                    "  a.nombres, " & _
                                    "  a.apellidos, " & _
                                    "  a.id_genero, " & _
                                    "  a.fecha_nacimiento, " & _
                                    "  b.nombre_genero, " & _
                                    "  DATEDIFF(YYYY,A.fecha_nacimiento,GETDATE()) as edad, " & _
                                    "  CONVERT (varchar(10), a.fecha_nacimiento, 103) AS F_Nacimiento, " & _
                                    "  a.id_grupoFamiliar, " & _
                                    "  a.id_beneficiario, " & _
                                    "  a.Edit " & _
                                    "  FROM tme_BeneficiarioGrupoFamiliarTemp a " & _
                                    "   INNER JOIN tme_Genero b ON a.id_genero = b.id_genero " & _
                                    "    WHERE a.id_temp = '{0}'", idTemp)


            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("GRupoFAM")
            dm.Fill(ds, "GRupoFAM")


            get_Grupo_FamiliarTMP = ds.Tables.Item("GRupoFAM")

        End Function


        Public Function save_GrupoFam(ByVal idTMP As String) As Boolean

            '********************************GRUPO FAMILIAR************************************
            Dim Sql = String.Format("SELECT * FROM tme_BeneficiarioGrupoFamiliarTemp WHERE id_temp='{0}' ", idTMP)
            cnn.Open()
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("GRupoFAM")
            dm.Fill(ds, "GRupoFAM")

            Try

                If ds.Tables.Item("GRupoFAM").Rows.Count > 0 Then

                    Sql = String.Format("INSERT INTO tme_BeneficiarioGrupoFamiliar " & _
                                        " SELECT a.identificacion, a.tipo_identificacion, a.nombres, a.apellidos, a.id_genero, a.fecha_nacimiento, {0} AS id_beneficiario, Edit " & _
                                        "    FROM tme_BeneficiarioGrupoFamiliarTemp  a " & _
                                        "       WHERE a.id_temp = '{1}' AND a.id_Beneficiario <> {0} ", id_beneficiario, idTMP)


                    'SELECT a.identificacion, a.tipo_identificacion, a.nombres, a.apellidos, a.id_genero, a.fecha_nacimiento, 20807 AS id_beneficiario     
                    ' FROM tme_BeneficiarioGrupoFamiliarTemp  a      
                    '   WHERE a.id_temp = '8791032014122034PM' 
                    '    and a.id_Beneficiario <> 20807

                    'update(tme_BeneficiarioGrupoFamiliar)
                    'set tipo_identificacion = b.tipo_identificacion,
                    '    nombres = b.nombres,
                    '    apellidos = b.apellidos,
                    '    id_genero = b.id_genero,
                    '    fecha_nacimiento = b.fecha_nacimiento
                    '	from tme_BeneficiarioGrupoFamiliarTemp a
                    '	 left join tme_BeneficiarioGrupoFamiliar b on (a.identificacion = b.identificacion and a.tipo_identificacion = b.tipo_identificacion)
                    '	  where a.id_temp = '94102012014034240'
                    '	   and b.id_grupoFamiliar is not null

                    dm.SelectCommand.CommandText = Sql
                    dm.SelectCommand.ExecuteNonQuery()

                End If

                save_GrupoFam = True

            Catch ex As Exception
                save_GrupoFam = False
            End Try

            cnn.Close()


        End Function


        Public Function del_GrupoFam(ByVal idTMP As String, ByVal id_GrupoFamiliar As Integer, ByVal id_Bene As Integer) As Boolean

            Try

                '********************************GRUPO FAMILIAR************************************
                Dim Sql = String.Format("DELETE FROM tme_BeneficiarioGrupoFamiliarTemp WHERE id_grupoFamiliar ='{0}' and id_temp = '{1}' ", id_GrupoFamiliar, idTMP)
                cnn.Open()
                Dim dm As New SqlDataAdapter(Sql, cnn)
                dm.SelectCommand.ExecuteNonQuery()

                If id_Bene = id_beneficiario Then
                    Sql = String.Format("DELETE FROM tme_BeneficiarioGrupoFamiliar WHERE id_grupoFamiliar ='{0}' ", id_GrupoFamiliar)
                    dm.SelectCommand.CommandText = Sql
                    dm.SelectCommand.ExecuteNonQuery()
                End If

                del_GrupoFam = True

            Catch ex As Exception
                del_GrupoFam = False

            End Try

            cnn.Close()


        End Function



        Public Function save_Cat(ByVal idType As Integer, ByVal idProy As Integer, ByVal strNombre As String, ByVal idAux As Integer) As Boolean


            '********************************GRUPO FAMILIAR************************************
            Dim Sql
            cnn.Open()
            Dim dm As New SqlDataAdapter(Sql, cnn)

            Select Case idType

                Case 1
                    Sql = String.Format(" insert into tme_centro_corregimiento (id_municipio, cc_nombre) values ({0},'{1}')", idAux, strNombre)

                Case 2
                    Sql = String.Format(" insert into tme_veredas (id_municipio, ver_nombre) values ({0},'{1}')", idAux, strNombre)

            End Select

            Try

                dm.SelectCommand.CommandText = Sql
                dm.SelectCommand.ExecuteNonQuery()

                save_Cat = True

            Catch ex As Exception

                save_Cat = False

            End Try

            cnn.Close()

        End Function


        Public Function get_Muni_Ficha(ByVal idDepto As Integer, ByVal idFicha As Integer) As DataTable


            'devuelve los municipios de donde pertenece una ficha de proyecto en el sistema SIME, recibiendo como parametro el id de la ficha y del depto seleccionado
            Dim Sql = String.Format("SELECT DISTINCT tme_Municipios.id_municipio,  " & _
                                    " tme_Municipios.nombre_municipio, " & _
                                    "  tme_FichaMunicipios.id_ficha_proyecto " & _
                                    "   FROM tme_Municipios " & _
                                    "     INNER JOIN tme_FichaMunicipios ON tme_Municipios.id_municipio = tme_FichaMunicipios.id_municipio " & _
                                    "       WHERE (tme_Municipios.id_departamento = {0}) AND (tme_FichaMunicipios.id_ficha_proyecto = {1}) ", idDepto, idFicha)



            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Muni")
            dm.Fill(ds, "Muni")

            ' If ds.Tables.Item("Muni").Rows.Count = 0 Then
            ds.Tables.Item("Muni").Rows.Add(New Object() {0, "--SELECCIONE UN MUNICIPIO--"})
            'End If


            get_Muni_Ficha = ds.Tables.Item("Muni")

        End Function


        Public Function get_Escolaridad() As DataTable

            'devuelve los tipos de escolaridad configurado en el sistema sistema SIME, no recibe ningún parámetro
            Dim Sql = String.Format(" SELECT id_escolaridad, nombre_escolaridad FROM tme_Escolaridad	")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Escolaridad")
            dm.Fill(ds, "Escolaridad")

            'ds.Tables.Item("Escolaridad").Rows.Add(New Object() {0, "--SELECCIONE--"})

            get_Escolaridad = ds.Tables.Item("Escolaridad")

        End Function


        Public Function get_Estado_Civil() As DataTable

            'devuelve los tipos de estados civiles configurado en el sistema sistema SIME, no recibe ningún parámetro
            Dim Sql = String.Format(" SELECT id_estado_civil, nombre_estado_civil FROM tme_EstadoCivil	")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Estado_Civ")
            dm.Fill(ds, "Estado_Civ")

            'ds.Tables.Item("Estado_Civ").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_Estado_Civil = ds.Tables.Item("Estado_Civ")

        End Function


        Public Function get_Grupo_Etnico() As DataTable

            'devuelve los tipos de grupos configurado en el sistema sistema SIME, no recibe ningún parámetro
            Dim Sql = String.Format(" SELECT id_etnia, nombre_etnia FROM tme_etnia	")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("GripoET")
            dm.Fill(ds, "GripoET")

            ds.Tables.Item("GripoET").Rows.Add(New Object() {0, "--SELECCIONE--"})

            get_Grupo_Etnico = ds.Tables.Item("GripoET")

        End Function



        Public Function get_Ubicacion_GEO() As DataTable

            'devuelve los tipos ubicaciones geograficas configuradas en el sistema sistema SIME, no recibe ningún parámetro
            Dim Sql = String.Format(" SELECT id_tipo_ubicacioncodigo, nombre_tipo_ubicacioncodigo FROM tme_FichaUbicacionProyectoTipoCodigo	where id_tipo_ubicacioncodigo <> 10")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("UGEO")
            dm.Fill(ds, "UGEO")
            'ds.Tables.Item("UGEO").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_Ubicacion_GEO = ds.Tables.Item("UGEO")

        End Function



        Public Function get_ActividadAgro() As DataTable

            'devuelve la diferentes actividades agricolas en el sistema
            Dim Sql = String.Format("select id_act, act_nombre from tme_act_agricolas   ")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Aagricola")
            dm.Fill(ds, "Aagricola")
            'ds.Tables.Item("UGEO").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_ActividadAgro = ds.Tables.Item("Aagricola")

        End Function



        Public Function get_Beneficios() As DataTable

            'devuelve la diferentes actividades agricolas en el sistema
            Dim Sql = String.Format("select id_ben, ben_nombre from tme_beneficios_rec")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Beneficios")
            dm.Fill(ds, "Beneficios")
            'ds.Tables.Item("UGEO").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_Beneficios = ds.Tables.Item("Beneficios")

        End Function



        Public Function get_BeneficiosV(ByVal strText As String) As Integer


            Dim Sql = String.Format("select id_ben, ben_nombre from tme_beneficios_rec where ben_nombre like '{0}' ", Trim(strText))

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")

            If ds.Tables.Item("CC").Rows.Count > 0 Then

                get_BeneficiosV = ds.Tables.Item("CC").Rows(0).Item("id_ben")

            Else

                get_BeneficiosV = 0

            End If


        End Function


        Public Function get_ProdAGRO() As DataTable

            'devuelve la diferentes actividades agricolas en el sistema
            Dim Sql = String.Format("select id_prod, prod_nombre from tme_prod_agro")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Prod")
            dm.Fill(ds, "Prod")
            'ds.Tables.Item("UGEO").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_ProdAGRO = ds.Tables.Item("Prod")

        End Function

        Public Function get_ProdAGROV(ByVal strText As String) As Integer

            Dim Sql = String.Format("select id_prod, prod_nombre from tme_prod_agro where prod_nombre like '{0}' ", Trim(strText))

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")

            If ds.Tables.Item("CC").Rows.Count > 0 Then

                get_ProdAGROV = ds.Tables.Item("CC").Rows(0).Item("id_prod")

            Else

                get_ProdAGROV = 0

            End If


        End Function

        Public Function get_EntidadBanc() As DataTable

            'devuelve la diferentes actividades agricolas en el sistema
            Dim Sql = String.Format("select id_banc, banc_nombre from tme_ent_banc")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Banc")
            dm.Fill(ds, "Banc")
            'ds.Tables.Item("UGEO").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_EntidadBanc = ds.Tables.Item("Banc")

        End Function


        Public Function get_EntidadBancV(ByVal strText As String) As Integer

            Dim Sql = String.Format("select id_banc, banc_nombre from tme_ent_banc where banc_nombre like '{0}' ", Trim(strText))

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")

            If ds.Tables.Item("CC").Rows.Count > 0 Then

                get_EntidadBancV = ds.Tables.Item("CC").Rows(0).Item("id_banc")

            Else

                get_EntidadBancV = 0

            End If


        End Function


        Public Function get_ProcCert() As DataTable

            'devuelve la diferentes actividades agricolas en el sistema
            Dim Sql = String.Format("select id_proc, proc_nombre from tme_proc_cert ")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("Proc")
            dm.Fill(ds, "Proc")
            'ds.Tables.Item("UGEO").Rows.Add(New Object() {0, "--SELECCIONE--"})
            get_ProcCert = ds.Tables.Item("Proc")

        End Function



        Public Function get_ProcCertV(ByVal strText As String) As Integer

            Dim Sql = String.Format("select id_proc, proc_nombre from tme_proc_cert where proc_nombre like '{0}' ", Trim(strText))

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")

            If ds.Tables.Item("CC").Rows.Count > 0 Then

                get_ProcCertV = ds.Tables.Item("CC").Rows(0).Item("id_proc")

            Else

                get_ProcCertV = 0

            End If


        End Function


        Public Function get_Tipo_Press() As DataTable

            'devuelve los tipos presicion de mediciones geograficas configuradas en el sistema sistema SIME, no recibe ningún parámetro
            Dim Sql = String.Format(" SELECT id_tipo_precisionFicha, nombre_tipo_precision FROM tme_FichaUbicacionProyectoTipoPrecision	")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("PRESS")
            dm.Fill(ds, "PRESS")
            'ds.Tables.Item("PRESS").Rows.Add(New Object() {0, "--SELECCIONE--"})

            get_Tipo_Press = ds.Tables.Item("PRESS")

        End Function



        Public Function get_Corregimientos_Centros(ByVal idMuni As Integer, Optional ByVal strText As String = "") As DataTable

            'devuelve la información de todas los Centro y corregimientos registradas para un proyecto en el sistema SIME, recibiendo como parametro el id del proyecto
            Dim strCondition As String = ""
            If strText.Length > 1 Then
                strCondition &= String.Format("  AND cc_nombre like '%{0}%' ", Trim(strText))
            End If

            Dim Sql = String.Format("select id_cc, cc_nombre from tme_centro_corregimiento where id_municipio = {0} {1}", idMuni, strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")
            ds.Tables.Item("CC").Rows.Add(New Object() {0, "--SELECCIONE--"})

            get_Corregimientos_Centros = ds.Tables.Item("CC")

        End Function



        Public Function get_Corregimientos_CentrosV(ByVal idMuni As Integer, Optional ByVal strText As String = "") As Integer

            'devuelve la información de todas los Centro y corregimientos registradas para un proyecto en el sistema SIME, recibiendo como parametro el id del proyecto
            Dim strCondition As String = ""
            If strText.Length > 1 Then
                strCondition &= String.Format("  AND cc_nombre like '{0}' ", Trim(strText))
            End If

            Dim Sql = String.Format("select id_cc, cc_nombre from tme_centro_corregimiento where id_municipio = {0} {1}", idMuni, strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("CC")
            dm.Fill(ds, "CC")
            'ds.Tables.Item("CC").Rows.Add(New Object() {0, "--SELECCIONE--"})

            If ds.Tables.Item("CC").Rows.Count > 0 Then

                If strText.Trim.Length = 0 Then
                    get_Corregimientos_CentrosV = 0
                Else
                    get_Corregimientos_CentrosV = ds.Tables.Item("CC").Rows(0).Item("id_cc")
                End If

            Else

                get_Corregimientos_CentrosV = 0

            End If


        End Function



        Public Function get_veredas(ByVal idmuni As Integer, Optional ByVal strText As String = "") As DataTable

            'devuelve la información de todas los Centro y corregimientos registradas para un proyecto en el sistema SIME, recibiendo como parametro el id del proyecto
            Dim strCondition As String = ""
            If strText.Length > 1 Then
                strCondition &= String.Format("  AND ver_nombre like '%{0}%' ", Trim(strText))
            End If

            Dim Sql = String.Format("select id_ver, ver_nombre from tme_veredas where id_municipio = {0} {1}", idmuni, strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("VER")
            dm.Fill(ds, "VER")
            ds.Tables.Item("VER").Rows.Add(New Object() {0, "--SELECCIONE--"})

            get_veredas = ds.Tables.Item("VER")

        End Function





        Public Function get_veredasV(ByVal idmuni As Integer, ByVal strText As String) As Integer

            'devuelve la información de todas los Centro y corregimientos registradas para un proyecto en el sistema SIME, recibiendo como parametro el id del proyecto
            Dim strCondition As String = ""
            If strText.Length > 1 Then
                strCondition &= String.Format("  AND ver_nombre like '{0}' ", Trim(strText))
            End If

            Dim Sql = String.Format("select id_ver, ver_nombre from tme_veredas where id_municipio = {0} {1}", idmuni, strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("VER")
            dm.Fill(ds, "VER")
            'ds.Tables.Item("VER").Rows.Add(New Object() {0, "--SELECCIONE--"})

            If ds.Tables.Item("VER").Rows.Count > 0 Then

                If strText.Trim.Length = 0 Then
                    get_veredasV = 0
                Else
                    get_veredasV = ds.Tables.Item("VER").Rows(0).Item("id_ver")
                End If

            Else

                get_veredasV = 0

            End If



        End Function



        Public Function validarGFamiliar(ByVal ID As String, ByVal tipoID As Integer, Optional ByVal idProy As Integer = 0) As DataTable

            Dim valor As Integer = 0
            Dim idBenef As Integer = 0
            Dim idFicha As Integer = 0
            Dim strCondition As String = ""


            Dim sql As String
            Dim resultTBL As New DataTable("RES")

            '2 CC
            '3 TI
            '4 RC

            resultTBL.Columns.Add(New DataColumn("id_res", GetType(Integer)))
            resultTBL.Columns.Add(New DataColumn("id_beneficiario", GetType(Integer)))
            resultTBL.Columns.Add(New DataColumn("id_ficha_proyecto", GetType(Integer)))

            If idProy > 0 Then
                strCondition = String.Format(" and id_ficha_proyecto <> {0} ", idProy)
            Else
                strCondition = ""
            End If

            ' id_ficha_proyecto={1} OR id_componente={2}
            sql = String.Format(" SELECT id_beneficiario, id_ficha_proyecto FROM vw_tme_beneficiario WHERE id_estado_beneficiario=1 AND ID='{0}' {1} ", ID, strCondition)
            Dim dm As New SqlDataAdapter(sql, cnn)
            Dim ds As New DataSet("beneficiario")
            dm.Fill(ds, "beneficiario")

            If ds.Tables("beneficiario").Rows.Count > 0 Then
                valor = 1 'Beneficiario ya registrado
                idBenef = ds.Tables("beneficiario").Rows.Item(0).Item("id_beneficiario")
                idFicha = ds.Tables("beneficiario").Rows.Item(0).Item("id_ficha_proyecto")
            Else


                sql = String.Format("select b.id_ficha_proyecto, a.id_beneficiario " & _
                                    " from tme_BeneficiarioGrupoFamiliar a " & _
                                    "   inner join vw_tme_beneficiario  b on (a.id_beneficiario = b.id_beneficiario) " & _
                                    "       where a.tipo_identificacion = {0} and a.identificacion = '{1}' ", tipoID, ID)

                ds.Tables.Add("benef2")
                dm.SelectCommand.CommandText = sql
                dm.Fill(ds, "benef2")

                If ds.Tables("benef2").Rows.Count > 0 Then
                    valor = 2
                    idBenef = ds.Tables("benef2").Rows.Item(0).Item("id_beneficiario")
                    idFicha = ds.Tables("benef2").Rows.Item(0).Item("id_ficha_proyecto")

                Else
                    valor = 0 ' Beneficiario no registrado                    
                    idBenef = 0
                    idFicha = 0
                End If

            End If

            resultTBL.Rows.Add(New Object() {valor, idBenef, idFicha})

            validarGFamiliar = resultTBL

        End Function


    End Class


End Namespace


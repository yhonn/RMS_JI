﻿

Imports ly_SIME.CORE.cls_util
Imports System.Net.Mail
Imports System.Net
Imports System.Web.UI.Page



Namespace UTILS

    Public Class cls_email
        Inherits System.Web.UI.Page

        Dim utlCORE As New CORE.cls_util
        Dim Tbl_Config As DataTable
        Dim Port As String
        Dim Account As String
        Dim Pass As String
        Dim Smtp As String
        Dim SSLtp As String
        Dim MensajeSend As MailMessage
        Dim id_programa As Integer
        Dim tbl_email As DataTable
        Dim id_Send As Integer
        Dim tbl_emailTEST As DataTable

        Dim htmlView As AlternateView
        Dim strEmail_mess As String

        Public Property SilentMode As Boolean
        Public Property Auth As Boolean
        Public Property SendForm As MailAddress
        Public Property SendTo As MailAddress

        Public Sub New(ByVal id_prog As Integer)

            id_programa = id_prog

            '**************************** hacer los cambios respectivos para que esto sea dependiendo del tipo de email SIME, approval, contact, finanace by examples**********

            Tbl_Config = utlCORE.setObjeto("t_programa_settings", "id_programa", id_programa).Copy
            Port = getConfigField("port_smtp_approval_emailing", "id_programa", id_programa).ToString.Trim
            Account = getConfigField("email_approval_sender", "id_programa", id_programa).ToString.Trim
            Pass = getConfigField("password_approval_sender", "id_programa", id_programa).ToString.Trim
            Smtp = getConfigField("smtp_approval_emailing", "id_programa", id_programa).ToString.Trim
            SSLtp = getConfigField("encryp_protocol_approval_emailing", "id_programa", id_programa).ToString.Trim
            SilentMode = CType(getConfigField("silent_mode_not_emailing_TO_list", "id_programa", id_programa).ToString.Trim, Boolean)
            Auth = CType(getConfigField("auth_emailing_smtp_server", "id_programa", id_programa).ToString.Trim, Boolean)


            MensajeSend = New MailMessage()
            tbl_email = New DataTable

            '***********************Por defecto de dejará aquí*******************************
            AddFrom(getConfigField("email_approval_sender", "id_programa", id_programa).ToString)
            '***********************Por defecto de dejará aquí*******************************

        End Sub

        Public Function getConfigField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(Tbl_Config, campoSearch, campo, valorSearch)

        End Function

        Public Sub AddFrom(ByVal SendFrom As String)
            SendForm = New MailAddress(SendFrom)
            MensajeSend.From = SendForm
        End Sub

        Public Sub AddTo(ByVal tbl_To As DataTable)
            For i = 0 To tbl_To.Rows.Count - 1
                MensajeSend.To.Add(tbl_To.Rows.Item(i).Item("email"))
            Next
        End Sub

        Public Sub AddTo(ByVal strEmail As String)

            MensajeSend.To.Add(strEmail)

        End Sub

        Public Sub AddBcc(ByVal tbl_Bcc As DataTable)
            For i = 0 To tbl_Bcc.Rows.Count - 1
                MensajeSend.Bcc.Add(tbl_Bcc.Rows.Item(i).Item("email"))
            Next
        End Sub

        Public Sub AddBcc(ByVal strEmail As String)
            MensajeSend.Bcc.Add(strEmail)
        End Sub

        Public Sub AddCC(ByVal tbl_cc As DataTable)
            For i = 0 To tbl_cc.Rows.Count - 1
                MensajeSend.CC.Add(tbl_cc.Rows.Item(i).Item("email"))
            Next
        End Sub

        Public Sub AddCC(ByVal strEmail As String)
            MensajeSend.CC.Add(strEmail)
        End Sub

        Public Sub AddSubject(ByVal strSubject As String)
            MensajeSend.Subject = strSubject
        End Sub

        Public Sub SetPriority(ByVal vPrior As Integer)
            MensajeSend.Priority = vPrior
        End Sub

        Public Sub setAlternativeVIEW(ByVal strMensaje As String)
            Dim nullable As System.Text.Encoding
            strEmail_mess = strMensaje
            htmlView = AlternateView.CreateAlternateViewFromString(strMensaje, nullable, "text/html")
        End Sub

        Public Sub Add_LinkResources(ByVal resourceID As String, ByVal resourcePath As String, ByVal resourceType As String)

            Dim LnkResource As LinkedResource = New LinkedResource(resourcePath, resourceType)
            LnkResource.ContentId = resourceID
            LnkResource.TransferEncoding = System.Net.Mime.TransferEncoding.Base64
            htmlView.LinkedResources.Add(LnkResource)

        End Sub

        Public Function SendEmail(ByVal idNoti As Integer, Optional idSource As Integer = 0, Optional EMAILROLE As String = "", Optional EMAILACTION As String = "") As Boolean


            '******************************************************************************************
            MensajeSend.AlternateViews.Clear()
            MensajeSend.AlternateViews.Add(htmlView)
            MensajeSend.IsBodyHtml = True
            'MensajeSend.Body = Mensaje
            'MensajeSend.Priority = MailPriority.High

            'SetPriority(MailPriority.High)

            Dim CorreoSend As New SmtpClient(Smtp, Port)
            CorreoSend.UseDefaultCredentials = False
            Dim basicAuth As New NetworkCredential(Account, Pass)

            If Auth Then
                CorreoSend.Credentials = basicAuth
            Else
                CorreoSend.UseDefaultCredentials = False
            End If

            If SSLtp = "TLS" Then
                CorreoSend.EnableSsl = True
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
            ElseIf SSLtp = "SSL" Then
                CorreoSend.EnableSsl = True
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3
            Else
                CorreoSend.EnableSsl = False
            End If
            'ServicePointManager.SecurityProtocol = CType(3072, SecurityProtocolType)

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls Or SecurityProtocolType.Tls11 Or SecurityProtocolType.Tls12
            Try

                '****************************************************************************************
                '***************************Para cargar Correo************************
                CorreoSend.Send(MensajeSend)
                SaveEmail(True, idNoti, strEmail_mess, , idSource, EMAILROLE, EMAILACTION)
                '***************************************************************************************
                SendEmail = True

            Catch ex As Exception
                'lblResult2.Text &= String.Format("{0}{0}{0}{0}  !!Error Generado Correos!! {0}{1}", Chr(13), ex.Message)
                'MsgBox("ERROR: " & ex.ToString, MsgBoxStyle.Critical, "Error")
                SaveEmail(False, idNoti, strEmail_mess, ex.Message, idSource, EMAILROLE, EMAILACTION)
                SendEmail = False

            End Try


        End Function


        Public Function SaveEmail(ByVal SendResult As Boolean, ByVal idNoti As Integer, ByVal strMensaje As String, Optional errMEss As String = "--none--", Optional idSource As Integer = 0, Optional EMAILROLE As String = "", Optional EMAILACTION As String = "") As Boolean

            init_email(0)
            setEmailField("id_notification", idNoti, "idSend", id_Send)
            setEmailField("ID_SOURCE", idSource, "idSend", id_Send)
            setEmailField("EMAILROLE", EMAILROLE, "idSend", id_Send)
            setEmailField("EMAILACTION", EMAILACTION, "idSend", id_Send)

            setEmailField("sn_to", MensajeSend.To.ToString, "idSend", id_Send)
            setEmailField("sn_cc", MensajeSend.CC.ToString, "idSend", id_Send)
            setEmailField("sn_bcc", MensajeSend.Bcc.ToString, "idSend", id_Send)
            setEmailField("sn_from", MensajeSend.From.ToString, "idSend", id_Send)
            setEmailField("sn_bodyMessage", strMensaje, "idSend", id_Send)
            setEmailField("sn_sended", CType(SendResult, System.Data.SqlTypes.SqlBoolean), "idSend", id_Send)
            setEmailField("sn_datesending", Date.UtcNow, "idSend", id_Send)
            setEmailField("sn_err_message", errMEss, "idSend", id_Send)

            If save_Email() <> -1 Then
                SaveEmail = True
            Else
                SaveEmail = False
            End If

        End Function

        Public Sub init_email(ByVal idS As String)

            tbl_email = utlCORE.setObjeto("t_sended", "idSend", idS).Copy
            id_Send = idS

        End Sub

        Public Sub init_emailTEST(ByVal idS As String)

            Dim Encoding As System.Text.UnicodeEncoding = New System.Text.UnicodeEncoding
            Dim strData As String = " "

            tbl_emailTEST = utlCORE.setObjeto("t_sended", "idSend", idS).Copy

            strData = Encoding.GetChars(tbl_emailTEST.Rows.Item(0).Item("sn_bodyMEssage"))

            strData.Trim()

        End Sub


        Public Sub setEmailField(ByVal campo As String, ByVal valor As String, ByVal campoSearch As String, ByVal valorSearch As String)

            tbl_email = utlCORE.setDTval(tbl_email, campoSearch, campo, valorSearch, valor)

        End Sub



        Public Function getEmailField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(tbl_email, campoSearch, campo, valorSearch)

        End Function

        Public Function save_Email() As Integer

            Dim RES As Integer
            RES = utlCORE.SaveObjeto("t_sended", tbl_email, "idSend", id_Send)

            If RES <> -1 Then
                save_Email = RES
                setEmailField("idSend", RES, "idSend", id_Send)
                id_Send = RES
            Else
                save_Email = RES
            End If

        End Function


    End Class


End Namespace

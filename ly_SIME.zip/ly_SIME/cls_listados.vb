﻿Imports System.Linq.Expressions
Imports System.Configuration
Imports Telerik.Web.UI

Namespace CORE


    Public Class cls_listados

        Public Function get_t_usuarios() As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_usuarios.Select(Function(p) _
                                                       New With {Key .nombre_usuario = p.nombre_usuario + " " + p.apellidos_usuario + " (" + p.t_job_title.job + ") ",
                                                                 Key .id_usuario = p.id_usuario}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_usuarios(ByVal idP As Integer) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.vw_t_usuario_programa.Where(Function(p) p.id_programa = idP).Select(Function(p) _
                                                       New With {Key .nombre_usuario = p.nombre_usuario + " (" + p.job + ") ",
                                                                 Key .id_usuario = p.id_usuario}).ToList()
                Return listado
            End Using

        End Function

        Public Function get_t_tipo_nivel_usuario(Optional id As Integer = 0, Optional codigo As String = "") As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_tipo_nivel_usuario.Where(Function(p) (p.id_programa = id Or id = 0) And codigo.Contains(p.codigo_nivel_usuario)) _
                              .Select(Function(p) _
                                          New With {Key .codigo_nivel_usuario = p.codigo_nivel_usuario + " (" + p.descripcion_nivel_usuario + ") ",
                                                    Key .id_tipo_nivel_usuario = p.id_tipo_nivel_usuario}).OrderByDescending(Function(p) p.codigo_nivel_usuario).ToList()

                Return listado
            End Using
        End Function

        Public Function get_t_tipo_usuario() As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_tipo_usuario.Select(Function(p) _
                                                           New With {Key .nombre_tipo_usuario = p.nombre_tipo_usuario,
                                                                     Key .id_tipo_usuario = p.id_tipo_usuario}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_estado_usuario() As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_estado_usuario.Select(Function(p) _
                                                             New With {Key .nombre_estado_usuario = p.nombre_estado_usuario,
                                                                       Key .id_estado_usuario = p.id_estado_usuario}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_rol(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                'Mayor a uno para que no salga el rol Super Admin
                Dim listado = db.t_rol.Where(Function(p) (p.id_programa = id Or id = 0) And p.id_rol > 1) _
                              .Select(Function(p) _
                                                  New With {Key .rol_name = p.rol_name,
                                                            Key .id_rol = p.id_rol}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_pais() As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_pais.Select(Function(p) _
                                                  New With {Key .nombre_pais = p.nombre_pais,
                                                            Key .id_pais = p.id_pais}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_pais(ByVal texto As String) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_pais.Where(Function(p) p.nombre_pais.Contains(texto)).Select(Function(p) _
                                                  New With {Key .nombre_pais = p.nombre_pais,
                                                            Key .id_pais = p.id_pais}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_cliente() As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_cliente.Select(Function(p) _
                                                  New With {Key .nombre_cliente = p.nombre_cliente,
                                                            Key .id_cliente = p.id_cliente}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_ejecutores(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_ejecutores.Where(Function(p) p.id_programa = id Or id = 0) _
                              .OrderBy(Function(p) p.nombre_ejecutor) _
                              .Select(Function(p) _
                                          New With {Key .nombre_ejecutor = p.nombre_ejecutor,
                                                    Key .id_ejecutor = p.id_ejecutor}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_menu(Optional todos As Boolean = False) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_menu.Where(Function(p) Not p.parent_item_menu.HasValue Or todos) _
                              .Select(Function(p) _
                                          New With {Key .nombre_item_menu = p.nombre_item_menu,
                                                    Key .id_menu = p.id_menu}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_regiones2(ByVal idPrograma As Integer, ByVal idCountry As Integer) As Object

            Using db As New dbRMS_JIEntities


                Dim zoneList As List(Of Integer) = (From div In db.tme_subregion_nivel_avance
                                                    Join dist In db.t_districts On div.id_relacion Equals dist.id_district
                                                    Join subR In db.t_subregiones On div.id_subregion Equals subR.id_subregion
                                                    Join Region In db.t_regiones On Region.id_region Equals subR.id_region
                                                    Where (dist.id_programa = idPrograma And dist.id_pais = idCountry)
                                                    Select Region.id_region).Distinct().ToList()

                'zones = dbEntities.t_regiones.Where(Function(p) p.id_pais = countryID).OrderBy(Function(p) p.nombre_region) _
                '                        .Select(Function(p) _
                '                                New With {Key .id_region = p.id_region,
                ' Key .nombre_region = p.nombre_region}).ToList()

                Dim listado = db.t_regiones.Where(Function(p) zoneList.Contains(p.id_region)).OrderBy(Function(p) p.nombre_region) _
                                             .Select(Function(p) _
                                                                New With {Key .id_region = p.id_region,
                                                                          Key .nombre_region = p.nombre_region}).ToList()


                'Dim listado = db.t_regiones.Where(Function(p) p.id_pais = idCountry) _
                '              .Select(Function(p) _
                '                                  New With {Key .nombre_region = p.nombre_region,
                '                                            Key .id_region = p.id_region}).ToList()

                Return listado
            End Using
        End Function

        Public Function get_t_regiones(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_regiones.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                                  New With {Key .nombre_region = p.nombre_region,
                                                            Key .id_region = p.id_region}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_subregiones(Optional id As Integer = 0, Optional strSUB As Integer() = Nothing) As Object

            Using db As New dbRMS_JIEntities

                If Not (strSUB Is Nothing) Then
                    If strSUB.Count() > 0 Then
                        Dim listado = db.t_subregiones.Where(Function(p) (p.id_region = id Or id = 0) And strSUB.Contains(p.id_subregion)) _
                                  .Select(Function(p) _
                                                      New With {Key .nombre_subregion = p.nombre_subregion,
                                                                Key .id_subregion = p.id_subregion}).ToList()
                        Return listado
                    Else
                        Return Nothing
                    End If
                Else
                    Dim listado = db.t_subregiones.Where(Function(p) (p.id_region = id Or id = 0)) _
                                  .Select(Function(p) _
                                                      New With {Key .nombre_subregion = p.nombre_subregion,
                                                                Key .id_subregion = p.id_subregion}).ToList()
                    Return listado
                End If

            End Using
        End Function


        Public Function get_t_subregiones2(ByVal id As Integer, ByVal idCountry As Integer, ByVal idPrograma As Integer) As Object

            Using db As New dbRMS_JIEntities

                Dim divisionList As List(Of Integer) = (From div In db.tme_subregion_nivel_avance
                                                        Join dist In db.t_districts On div.id_relacion Equals dist.id_district
                                                        Join subR In db.t_subregiones On div.id_subregion Equals subR.id_subregion
                                                        Where (dist.id_programa = idPrograma And dist.id_pais = idCountry And subR.id_region = id)
                                                        Select subR.id_subregion).Distinct().ToList()

                'division = db.t_subregiones.Where(Function(p) p.id_region = zoneID And divisionList.Contains(p.id_subregion)).OrderBy(Function(p) p.nombre_subregion) _
                '                         .Select(Function(p) _
                '                                 New With {Key .id_subregion = p.id_subregion,
                '                                            Key .nombre_subregion = p.nombre_subregion}).ToList()

                Dim listado = db.t_subregiones.Where(Function(p) divisionList.Contains(p.id_subregion)).OrderBy(Function(p) p.nombre_subregion) _
                                  .Select(Function(p) _
                                                      New With {Key .nombre_subregion = p.nombre_subregion,
                                                                Key .id_subregion = p.id_subregion}).ToList()

                'Dim listado = db.t_subregiones.Where(Function(p) (p.id_region = id Or id = 0)) _
                '                  .Select(Function(p) _
                '                                      New With {Key .nombre_subregion = p.nombre_subregion,
                '                                                Key .id_subregion = p.id_subregion}).ToList()

                Return listado


            End Using


        End Function
        Public Function get_t_subregiones3(ByVal id As Integer, ByVal idCountry As Integer, ByVal idPrograma As Integer) As Object

            Using db As New dbRMS_JIEntities

                Dim divisionList As List(Of Integer) = (From div In db.tme_subregion_nivel_avance
                                                        Join dist In db.t_departamentos On div.id_relacion Equals dist.id_departamento
                                                        Join subR In db.t_subregiones On div.id_subregion Equals subR.id_subregion
                                                        Where (dist.id_programa = idPrograma And dist.id_pais = idCountry And subR.id_region = id)
                                                        Select subR.id_subregion).Distinct().ToList()

                'division = db.t_subregiones.Where(Function(p) p.id_region = zoneID And divisionList.Contains(p.id_subregion)).OrderBy(Function(p) p.nombre_subregion) _
                '                         .Select(Function(p) _
                '                                 New With {Key .id_subregion = p.id_subregion,
                '                                            Key .nombre_subregion = p.nombre_subregion}).ToList()

                Dim listado = db.t_subregiones.Where(Function(p) divisionList.Contains(p.id_subregion)).OrderBy(Function(p) p.nombre_subregion) _
                                  .Select(Function(p) _
                                                      New With {Key .nombre_subregion = p.nombre_subregion,
                                                                Key .id_subregion = p.id_subregion}).ToList()

                'Dim listado = db.t_subregiones.Where(Function(p) (p.id_region = id Or id = 0)) _
                '                  .Select(Function(p) _
                '                                      New With {Key .nombre_subregion = p.nombre_subregion,
                '                                                Key .id_subregion = p.id_subregion}).ToList()

                Return listado


            End Using


        End Function

        Public Function get_t_tipo_marco_logico(Optional id As Integer = 2) As Object

            'Using db As New dbRMS_JIEntities
            '    Dim listado = db.tme_tipo_marcologico.Select(Function(p) _
            '                                      New With {Key .nombre_tipo_marcologico = p.nombre_tipo_marcologico_en,
            '                                                Key .id_tipo_marcologico = p.id_tipo_marcologico}).ToList()
            '    Return listado
            'End Using

            Using db As New dbRMS_JIEntities

                'If id = 1 Then
                '    id = 10
                'ElseIf id = 2 Then
                '    id = 4
                'End If

                'Where(Function(p) p.id_tipo_marcologico <= id)

                Dim listado = db.tme_tipo_marcologico.Select(Function(p) _
                                                  New With {Key .nombre_tipo_marcologico = p.nombre_tipo_marcologico_en,
                                                            Key .id_tipo_marcologico = p.id_tipo_marcologico}).ToList()
                Return listado
            End Using

        End Function




        Public Function get_vw_estructura_marcologico_list(ByVal id_programa As Integer) As DataTable

            Dim cl_utl As New CORE.cls_util

            Dim strSQL As String = String.Format("SELECT *,'&lt;font size=1px&gt;&lt;b&gt;&lt;a target=_blank href=frm_DetalleMLIndicador.aspx?IdEML='+ CAST(id_estructura_marcologico as VARCHAR) + '&gt; ver&gt;&gt; &lt;/a&gt;&lt;/b&gt;&lt;/font&gt;' as link FROM vw_estructura_marcologico WHERE (id_programa= {0} and id_marco_logico_2 = {1}) Order by Orden ", id_programa, 1)

            Dim Tbl_Result = cl_utl.setObjeto("vw_estructura_marcologico", "id_estructura_marcologico", 0, strSQL).Copy

            get_vw_estructura_marcologico_list = Tbl_Result

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (Tbl_Result.Rows.Count = 1 And Tbl_Result.Rows.Item(0).Item("id_estructura_marcologico") = 0) Then
                Tbl_Result.Rows.Remove(Tbl_Result.Rows.Item(0))
            End If


        End Function

        Public Function get_t_programas(Optional id As Integer = 0, Optional visible As Boolean = True) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_programas.Where(Function(p) ((p.id_programa = id Or id = 0) And (p.visible = visible Or visible = False))) _
                              .Select(Function(p) _
                                          New With {Key .nombre_programa = p.nombre_programa,
                                                    Key .id_programa = p.id_programa}).ToList()
                Return listado
            End Using
        End Function
        Public Function get_t_programa_marcologico(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_programa_marco_logico.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_marcologico = p.nombre_marcologico,
                                                    Key .id_marco_logico = p.id_marco_logico}).ToList()
                Return listado
            End Using
        End Function


        Public Function get_tme_estructura_marcologico(Optional id As Integer = 0, Optional idTipo As Integer = 0, Optional idPadre As Integer = 0, Optional idml As Integer = 2) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_estructura_marcologico.Where(Function(p) (p.tme_programa_marco_logico.id_programa = id Or p.tme_programa_marco_logico.id_programa = 0) _
                                                                      And (p.id_tipo_marcologico = idTipo Or idTipo = 0) _
                                                                      And (p.id_estructura_marcologico_padre = idPadre Or idPadre = 0) _
                                                                      And (p.id_marco_logico_2 = idml Or idml = 0)) _
                                                                  .Select(Function(p) _
                                                                              New With {Key .descripcion_logica = p.descripcion_logica,
                                                                                        Key .id_estructura_marcologico = p.id_estructura_marcologico}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_marcologico_padre(Optional id As Integer = 0, Optional idPrograma As Integer = 0, Optional id_tipo As Integer = 2) As Object

            'Select Case id
            '    Case 2
            '    Case 3
            '        id = id - 1
            '    Case 4
            '        id = id - 1
            '    Case 5
            '        id = id - 1
            '    Case 6
            '        id = id - 1
            '    Case 7
            '        id = id - 1
            '    Case 8
            '        id = 0
            '    Case Else
            '        id = 2
            'End Select


            Using db As New dbRMS_JIEntities
                Dim id_padre_ml = db.tme_tipo_marcologico.Find(id).id_padre
                Dim listado = db.tme_estructura_marcologico.Where(Function(p) (p.id_marco_logico_2 = id_tipo And p.tme_programa_marco_logico.id_programa = idPrograma Or id = 0) And (p.tme_tipo_marcologico.id_tipo_marcologico = id_padre_ml)) _
                                                        .Select(Function(p) _
                                                                    New With {Key .descripcion_logica = p.descripcion_logica,
                                                                    Key .id_estructura_marcologico = p.id_estructura_marcologico}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_tipo_indicador(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_tipo_indicador.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_tipo_indicador = p.nombre_tipo_indicador,
                                                    Key .id_tipo_indicador = p.id_tipo_indicador}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_tipo_indicador_numerico(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_tipo_indicador_numerico.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_indicador_numerico = p.nombre_indicador_numerico,
                                                    Key .id_tipo_indicador_numerico = p.id_tipo_indicador_numerico}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_tipo_indicador_contrato(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_tipo_indicador_contrato.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_indicador_contrato = p.nombre_indicador_contrato,
                                                    Key .id_tipo_indicador_contrato = p.id_tipo_indicador_contrato}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_tipo_umedida(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_tipo_umedida.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_tipo_umedida = p.nombre_tipo_umedida,
                                                    Key .id_tipo_umedida = p.id_tipo_umedida}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_tipo_metodo_operacion(Optional id As Integer = 0) As Object

            Dim bndID As Integer = If(id > 0, 0, 1)

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_tipo_metodo_operacion.Where(Function(p) p.id_programa = id Or 1 = bndID) _
                              .Select(Function(p) _
                                          New With {Key .nombre_metodo_operacion = p.nombre_metodo_operacion,
                                                    Key .id_tipo_metodo_operacion = p.id_tipo_metodo_operacion}).ToList()
                Return listado
            End Using

        End Function

        Public Function get_tme_lev_frecuencia_indicador(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_lev_frecuencia_indicador.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_lev_frecuencia_indicador = p.nombre_lev_frecuencia_indicador,
                                                    Key .id_lev_frecuencia_indicador = p.id_lev_frecuencia_indicador}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_rep_frecuencia_indicador(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_rep_frecuencia_indicador.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_rep_frecuencia_indicador = p.nombre_rep_frecuencia_indicador,
                                                    Key .id_rep_frecuencia_indicador = p.id_rep_frecuencia_indicador}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_admincatalogos(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_AdminCatalogos.Where(Function(p) p.id_programa = id Or id = 0) _
                              .OrderBy(Function(p) p.TipoCatalogo) _
                              .Select(Function(p) _
                                          New With {Key .TipoCatalogo = p.TipoCatalogo,
                                                    Key .id_CatalogoMaster = p.id_CatalogoMaster}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_instrumentos(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_instrumentos.Where(Function(p) p.id_programa = id Or id = 0) _
                              .OrderBy(Function(p) p.nombre_instrumento) _
                              .Select(Function(p) _
                                          New With {Key .nombre_instrumento = p.nombre_instrumento,
                                                    Key .id_instrumento = p.id_instrumento}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_indicador(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.vw_indicador_marcologico.Where(Function(p) p.id_programa = id Or id = 0) _
                              .OrderBy(Function(p) p.orden_matriz_LB) _
                              .Select(Function(p) _
                                          New With {Key .nombre_indicador_LB = p.nombre_indicador_LB,
                                                    Key .id_indicador = p.id_indicador,
                                                    Key .codigo_indicador = p.codigo_indicador,
                                                    Key .nombre_completo_indicador = "(" + p.codigo_indicador + ") - " + p.nombre_indicador_LB}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_anios(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_trimestre.GroupBy(Function(p) p.anio) _
                              .Select(Function(p) p.FirstOrDefault()).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_componente_programa(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_componente_programa.Where(Function(p) p.id_programa = id Or id = 0) _
                              .OrderBy(Function(p) p.nombre_componente) _
                              .Select(Function(p) _
                                          New With {Key .nombre_componente = p.nombre_componente,
                                                    Key .id_componente = p.id_componente}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_periodo(Optional id As Integer = 0, Optional active As Boolean = False) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.vw_t_periodos.Where(Function(p) (p.id_subregion = id Or id = 0) And (p.activo = True Or active = True)) _
                              .Select(Function(p) _
                                          New With {Key .nombre_periodo = "FY" & p.anioNotation.Value.ToString() & "-" & p.codigo_anio_fiscal,
                                                    Key .id_periodo = p.id_periodo}).Distinct().ToList()
                Return listado
            End Using
        End Function



        Public Function get_tme_list_indicador(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.vw_indicadores.Where(Function(p) p.id_programa = id Or id = 0) _
                              .OrderBy(Function(p) p.orden_matriz_LB) _
                              .Select(Function(p) _
                                          New With {Key .nombre_indicador_LB = p.nombre_indicador_LB,
                                                    Key .id_indicador = p.id_indicador,
                                                    Key .codigo_indicador = p.codigo_indicador,
                                                    Key .nombre_completo_indicador = "(" + p.codigo_indicador + ") - " + p.nombre_indicador_LB}).ToList()
                Return listado
            End Using
        End Function


        Public Function get_tme_FichaEstado() As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_FichaEstado.Select(Function(p) _
                                                  New With {Key .nombre_estado_ficha = p.nombre_estado_ficha,
                                                            Key .id_ficha_estado = p.id_ficha_estado}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_TA_ACTIVITY_STATUS(ByVal id As Integer) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.TA_ACTIVITY_STATUS.Where(Function(p) p.ID_PROGRAMA = id).Select(Function(p) _
                                                  New With {Key .STATUS = p.STATUS,
                                                            Key .ID_ACTIVITY_STATUS = p.ID_ACTIVITY_STATUS}).ToList()
                Return listado
            End Using

        End Function



        Public Function get_TA_APPLY_STATUS(ByVal id As Integer) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.TA_APPLY_STATUS.Where(Function(p) p.ID_PROGRAMA = id).Select(Function(p) _
                                                  New With {Key .APPLY_STATUS = p.APPLY_STATUS,
                                                            Key .ID_APPLY_STATUS = p.ID_APPLY_STATUS}).ToList()
                Return listado
            End Using

        End Function

        Public Function get_TA_APPLICATION_STATUS(ByVal id As Integer) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.TA_APPLICATION_STATUS.Where(Function(p) p.ID_PROGRAMA = id).Select(Function(p) _
                                                  New With {Key .APLICATION_STATUS = p.APLICATION_STATUS,
                                                            Key .ID_APP_STATUS = p.ID_APP_STATUS}).ToList()
                Return listado
            End Using

        End Function

        Public Function get_t_programa_planificacion(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_programa_planificacion.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .anio_ejecucion = p.anio_ejecucion,
                                                    Key .id_anio = p.anio_ejecucion}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_trimestre(ByVal anio As Integer) As Object

            Using db As New dbRMS_JIEntities

                Dim listado = db.t_trimestre.Where(Function(p) p.anio = anio) _
                              .Select(Function(p) _
                                          New With {Key .Value = p.id_trimestre,
                                                    Key .Text = p.codigo_anio_fiscal}).OrderBy(Function(p) p.Text).ToList()
                Return listado

            End Using

        End Function

        Public Function get_t_idiomas(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                'Dim listado = db.t_idiomas.Where(Function(p) p.id_programa = id Or id = 0) _
                '              .Select(Function(p) _
                '                          New With {Key .anio_ejecucion = p.anio_ejecucion, _
                '                                    Key .id_anio = p.anio_ejecucion}).ToList()
                Dim listado = db.t_idiomas.Select(Function(p) _
                                          New With {Key .descripcion_idioma = p.descripcion_idioma,
                                                    Key .id_idioma = p.id_idioma}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_job_title(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_job_title.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .job = p.job,
                                                    Key .id_job_title = p.id_job_title}).ToList()
                Return listado
            End Using
        End Function


        Public Function get_ta_docs_soporte(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.ta_docs_soporte.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .nombre_documento = p.nombre_documento,
                                                    Key .id_doc_soporte = p.id_doc_soporte}).OrderBy(Function(p) p.nombre_documento).ToList()
                Return listado
            End Using


        End Function

        Public Function get_TA_VOTING_TYPE(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.TA_VOTING_TYPE.Where(Function(p) p.ID_PROGRAMA = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .ID_VOTING_TYPE = p.ID_VOTING_TYPE,
                                                    Key .VOTING_TYPE = p.VOTING_TYPE}).ToList()
                Return listado
            End Using


        End Function



        Public Function get_t_budget(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_budget.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .id_budget = p.id_budget,
                                                    Key .bud_name = p.bud_name}).ToList()
                Return listado
            End Using


        End Function


        Public Function get_t_programa_currency(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_programa_currency.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .id_programa_currency = p.id_programa_currency,
                                                    Key .currency_prefix = p.currency_prefix}).ToList()
                Return listado
            End Using


        End Function


        Public Function get_TA_SOLICITATION_TYPE(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities

                Dim listado = db.TA_SOLICITATION_TYPE.Where(Function(p) p.ID_PROGRAMA = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .SOLICITATION_TYPE = p.SOLICITATION_TYPE & " (" & p.SOLICITATION_ACRONY & ")",
                                                    Key .SOLICITATION_ACRONY = p.SOLICITATION_ACRONY,
                                                    Key .ID_SOLICITATION_TYPE = p.ID_SOLICITATION_TYPE}).ToList()
                Return listado

            End Using

        End Function

        Public Function get_TA_SOLICITATION_STATUS(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.TA_SOLICITATION_STATUS.Where(Function(p) p.ID_PROGRAMA = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .SOLICITATION_STATUS = p.SOLICITATION_STATUS,
                                                    Key .ID_SOLICITATION_STATUS = p.ID_SOLICITATION_STATUS}).ToList()
                Return listado
            End Using

        End Function

        Public Function get_vw_t_programa_idiomas(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.vw_t_programa_idiomas.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .descripcion_idioma = p.descripcion_idioma,
                                                    Key .id_idioma = p.id_idioma}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_programa_settings(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_programa_settings.Where(Function(p) p.id_programa = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .url_user_images = p.url_user_images,
                                                    Key .id_programa_setting = p.id_programa_setting}).ToList()
                Return listado
            End Using
        End Function


        'Public Function get_tme_counties(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_counties.Where(Function(p) p.id_district = id Or id = 0).OrderBy(Function(p) p.nombre_county) _
        '                      .Select(Function(p) _
        '                                  New With {Key .nombre_county = p.nombre_county, _
        '                                            Key .id_county = p.id_county}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_subcounties(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_subcounties.Where(Function(p) p.id_county = id Or id = 0).OrderBy(Function(p) p.nombre_subcounty) _
        '                      .Select(Function(p) _
        '                                  New With {Key .nombre_subcounty = p.nombre_subcounty, _
        '                                            Key .id_subcounty = p.id_subcounty}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_parishes(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_parishes.Where(Function(p) p.id_subcounty = id Or id = 0).OrderBy(Function(p) p.nombre_parish) _
        '                      .Select(Function(p) _
        '                                  New With {Key .nombre_parish = p.nombre_parish, _
        '                                            Key .id_parish = p.id_parish}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_villages(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_villages.Where(Function(p) p.id_parish = id Or id = 0).OrderBy(Function(p) p.nombre_village) _
        '                      .Select(Function(p) _
        '                                  New With {Key .nombre_village = p.nombre_village, _
        '                                            Key .id_village = p.id_village}).ToList()
        '        Return listado
        '    End Using
        'End Function


        'Public Function get_tme_beneficiary_type() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_beneficiary_type.Select(Function(p) _
        '                                                         New With {Key .beneficiary_type = p.beneficiary_type, _
        '                                                                   Key .id_beneficiary_type = p.id_beneficiary_type}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_sex_type() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_sex_type.Select(Function(p) _
        '                                                         New With {Key .sex_type = p.sex_type, _
        '                                                                   Key .id_sex_type = p.id_sex_type}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_marital_status() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_marital_status.Select(Function(p) _
        '                                                         New With {Key .marital_status = p.marital_status, _
        '                                                                   Key .id_marital_status = p.id_marital_status}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_schooling_status() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_schooling_status.Select(Function(p) _
        '                                                         New With {Key .schooling_status = p.schooling_status, _
        '                                                                   Key .id_schooling_status = p.id_schooling_status}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_planning_method() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_planning_method.Select(Function(p) _
        '                                                         New With {Key .planning_method = p.planning_method, _
        '                                                                   Key .id_planning_method = p.id_planning_method}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_education_level(ByVal id As Integer) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_education_level.Where(Function(p) p.id_schooling_status = id) _
        '                      .Select(Function(p) _
        '                                  New With {Key .education_level = p.education_level, _
        '                                            Key .id_education_level = p.id_education_level}).ToList()
        '        Return listado
        '    End Using
        'End Function


        Public Function get_t_programas_usuario(ByVal id_usuario As Integer) As Object

            Using db As New dbRMS_JIEntities
                Dim actuales = db.vw_t_usuario_programas.Where(Function(p) p.id_usuario = id_usuario) _
                               .Select(Function(p) p.id_programa).ToList()
                Dim listado = db.t_programas.Where(Function(p) actuales.Contains(p.id_programa) And p.visible = True) _
                              .Select(Function(p) _
                                          New With {Key .nombre_programa = p.nombre_programa,
                                                    Key .id_programa = p.id_programa}).ToList()
                Return listado
            End Using
        End Function

        Public Function createFichaHistorico(ByVal id_fase As Integer, ByVal id_usuario As Integer) As tme_ficha_historico_estado
            Dim historico As New tme_ficha_historico_estado
            historico.fecha = Date.UtcNow
            historico.id_usuario = id_usuario
            historico.id_ficha_estado = id_fase
            Return historico
        End Function

        'Public Function get_tme_partner_type() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_partner_type.Select(Function(p) _
        '                                                     New With {Key .partner_type_name = p.partner_type_name, _
        '                                                               Key .id_partner_type = p.id_partner_type}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_partnership_focus() As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_partnership_focus.Select(Function(p) _
        '                                                          New With {Key .partnership_focus_name = p.partnership_focus_name, _
        '                                                                    Key .id_partnership_focus = p.id_partnership_focus}).ToList()
        '        Return listado
        '    End Using
        'End Function
        Public Function get_t_sys() As Object
            Using db As New dbRMS_JIEntities
                Dim listado = db.t_sys.Select(Function(p) _
                                                  New With {Key .sys_name = p.sys_name,
                                                            Key .id_sys = p.id_sys}).ToList()
                Return listado
            End Using
        End Function
        'Public Function get_t_type_training(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.t_type_training.Select(Function(p) _
        '                                          New With {Key .type_training = p.type_training, _
        '                                                    Key .id_type_training = p.id_type_training}).ToList()
        '        Return listado
        '    End Using
        'End Function
        'Public Function get_t_category_training(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.t_category_training.Select(Function(p) _
        '                                          New With {Key .category_training = p.category_training, _
        '                                                    Key .id_category_training = p.id_category_training}).ToList()
        '        Return listado
        '    End Using
        'End Function
        'Public Function get_t_specific_skill(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.t_specific_skill.Select(Function(p) _
        '                                          New With {Key .skill = p.skill, _
        '                                                    Key .id_specific_skill_training = p.id_specific_skill_training}).ToList()
        '        Return listado
        '    End Using
        'End Function
        'Public Function get_tme_organization(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_organization.Select(Function(p) _
        '                                          New With {Key .name = p.name, _
        '                                                    Key .id_organization = p.id_organization}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_tme_value_chain(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.tme_value_chain.Select(Function(p) _
        '                                          New With {Key .value_chain = p.value_chain, _
        '                                                    Key .id_value_chain = p.id_value_chain}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_mdts(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.ins_market_driven_technical_skills.Select(Function(p) _
        '                                          New With {Key .nombre = p.nombre, _
        '                                                    Key .id_mdts = p.id_mdts}).ToList()
        '        Return listado
        '    End Using
        'End Function
        'Public Function get_t_type_report_sale(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.t_type_report_sale.Select(Function(p) _
        '                                          New With {Key .type_report = p.type_report, _
        '                                                    Key .id_type_report_sale = p.id_type_report_sale}).ToList()
        '        Return listado
        '    End Using
        'End Function



        Function ValidateBeneficiary(Optional first_name As String = "", Optional sure_name As String = "", Optional m_first_name As String = "",
                                     Optional m_sure_name As String = "",
                                     Optional id_village As Integer = 0, Optional birth_year As Integer = 0, Optional id_beneficiary As Integer = 0) As Boolean
            Dim existe = False
            Dim query = "select count(*) from ins_beneficiary WHERE surname = @surname AND first_name = @first_name AND mother_firstname = @mother_firstname AND " _
                    & " mother_surname = @mother_surname AND  (id_village = @id_village OR id_village = 0) AND  birth_year = @birth_year"
            If id_beneficiary > 0 Then
                query &= " AND id_beneficiary <> @id_beneficiary"
            End If

            Using cnn As New System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings("dbCI_SAPConnectionString").ConnectionString)
                cnn.Open()
                Try
                    Using cmd As System.Data.SqlClient.SqlCommand = New System.Data.SqlClient.SqlCommand(query, cnn)

                        cmd.CommandType = CommandType.Text
                        cmd.Parameters.AddWithValue("@surname", sure_name)
                        cmd.Parameters.AddWithValue("@first_name", first_name)
                        cmd.Parameters.AddWithValue("@mother_firstname", m_first_name)
                        cmd.Parameters.AddWithValue("@mother_surname", m_sure_name)
                        cmd.Parameters.AddWithValue("@id_village", id_village)
                        cmd.Parameters.AddWithValue("@birth_year", birth_year)
                        cmd.Parameters.AddWithValue("@id_beneficiary", id_beneficiary)

                        Using drDatos As System.Data.SqlClient.SqlDataReader = cmd.ExecuteReader
                            If drDatos.HasRows Then
                                While (drDatos.Read())
                                    If drDatos(0) > 0 Then
                                        existe = True
                                    End If
                                End While
                            End If
                        End Using
                    End Using
                Catch ex As Exception
                End Try
                cnn.Close()
            End Using

            Return existe
        End Function


        Function CrearCodigoRFA(ByVal id_programa As Integer, Optional id_SOLICITATION_TYPE As Integer = 0, Optional idFicha_Padre As Integer = 0) As String

            Dim txtCodigo As String = ""
            Dim fecha As DateTime = Date.Now
            Dim anio As Integer
            Dim CorrrelativoStr As String = ""

            Using db As New dbRMS_JIEntities

                Dim oPrograma = db.t_programas.Find(id_programa)
                'Dim oSubregion = db.t_subregiones.Find(id_subregion)
                'Dim oMecanismo = db.tme_mecanismo_contratacion.Find(id_mecanismo)
                'Dim oSubMecanismo = db.tme_sub_mecanismo.Find(id_submecanismo)
                Dim oSOLTYPE = db.TA_SOLICITATION_TYPE.Find(id_SOLICITATION_TYPE)
                Dim oActivity = db.TA_ACTIVITY.Find(idFicha_Padre)

                anio = If(fecha.Month >= 10, fecha.Year + 1, fecha.Year)

                ' Dim total = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Select(Function(p) p.id_ficha_proyecto).ToList()
                Dim listado

                '' If oSubMecanismo.perfijo_sub_mecanismo = "NN" Then 'NO sub mechanism

                'LIF-RFA-2019-001-RFA-2020-001
                'P&B-GRA-BP-2019-001
                'P&B-GRA-EAAP-2019-001
                'P&B-ACT-2019-001
                'P&B-PO-2019-001

                listado = db.TA_ACTIVITY_SOLICITATION.Where(Function(p) Year(p.fecha_crea) = anio And p.ID_SOLICITATION_TYPE = id_SOLICITATION_TYPE).Count()

                txtCodigo = String.Format("{0}-{1}-{2}-{3}", oPrograma.prefijo_actividades, oSOLTYPE.SOLICITATION_ACRONY, anio.ToString, String.Format("{0:000}", listado + 1))




            End Using

            Return (txtCodigo)

        End Function



        Function CrearCodigoSOLICITATION(ByVal ID_ACTIVITY_SOLICITATION As Integer, ByVal SOLICITATION_CODE As String) As String

            Dim txtCodigo As String = ""
            Dim fecha As DateTime = Date.Now
            Dim anio As Integer
            Dim CorrrelativoStr As String = ""

            Using db As New dbRMS_JIEntities

                ' Dim oPrograma = db.t_programas.Find(id_programa)
                'Dim oSubregion = db.t_subregiones.Find(id_subregion)
                'Dim oMecanismo = db.tme_mecanismo_contratacion.Find(id_mecanismo)
                'Dim oSubMecanismo = db.tme_sub_mecanismo.Find(id_submecanismo)
                'Dim oSOLTYPE = db.TA_ACTIVITY_SOLICITATION.Find(id_SOLICITATION_TYPE)
                'Dim oActivity = db.TA_ACTIVITY.Find(idFicha_Padre)

                'anio = If(fecha.Month >= 10, fecha.Year + 1, fecha.Year)

                ' Dim total = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Select(Function(p) p.id_ficha_proyecto).ToList()
                Dim listado

                '' If oSubMecanismo.perfijo_sub_mecanismo = "NN" Then 'NO sub mechanism

                'LIF-RFA-2019-001-RFA-2020-001
                'P&B-GRA-BP-2019-001
                'P&B-GRA-EAAP-2019-001
                'P&B-ACT-2019-001
                'P&B-PO-2019-001

                listado = db.TA_SOLICITATION_APP.Where(Function(p) p.ID_ACTIVITY_SOLICITATION = ID_ACTIVITY_SOLICITATION).Count()

                txtCodigo = String.Format("{0}-APP{1}", SOLICITATION_CODE.Trim, String.Format("{0:000}", listado + 1))




            End Using

            Return (txtCodigo)

        End Function


        Function CrearCodigoFicha(ByVal id_programa As Integer, ByVal id_subregion As Integer, ByVal id_mecanismo As Integer, Optional id_submecanismo As Integer = 0, Optional idFicha_Padre As Integer = 0) As String

            Dim txtCodigo As String = ""
            Dim fecha As DateTime = Date.Now
            Dim anio As Integer
            Dim CorrrelativoStr As String = ""

            Using db As New dbRMS_JIEntities

                Dim oPrograma = db.t_programas.Find(id_programa)
                Dim oSubregion = db.t_subregiones.Find(id_subregion)
                Dim oMecanismo = db.tme_mecanismo_contratacion.Find(id_mecanismo)
                Dim oSubMecanismo = db.tme_sub_mecanismo.Find(id_submecanismo)
                Dim oActivity = db.tme_Ficha_Proyecto.Find(idFicha_Padre)



                anio = If(fecha.Month >= 10, fecha.Year + 1, fecha.Year)

                ' Dim total = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Select(Function(p) p.id_ficha_proyecto).ToList()
                Dim listado

                If oSubMecanismo.perfijo_sub_mecanismo = "NN" Then 'NO sub mechanism

                    'P&B-GRA-BP-2019-001
                    'P&B-GRA-EAAP-2019-001
                    'P&B-ACT-2019-001
                    'P&B-PO-2019-001

                    If id_subregion = -1 Then

                        'listado = db.tme_Ficha_Proyecto.Where(Function(p) p.tme_sub_mecanismo.id_mecanismo_contratacion = id_mecanismo And Year(p.datecreated) = anio).Count()
                        listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.tme_sub_mecanismo.id_mecanismo_contratacion = id_mecanismo And Year(p.datecreated) = anio).Count()
                        txtCodigo = String.Format("{0}-{1}-{2}-{3}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, anio.ToString, String.Format("{0:000}", listado + 1))

                    Else

                        'listado = db.tme_Ficha_Proyecto.Where(Function(p) p.tme_sub_mecanismo.id_mecanismo_contratacion = id_mecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Count()
                        listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.tme_sub_mecanismo.id_mecanismo_contratacion = id_mecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Count()
                        txtCodigo = String.Format("{0}-{1}-{2}-{3}-{4}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, oSubregion.prefijo_subregion, anio.ToString, String.Format("{0:000}", listado + 1))

                    End If

                Else

                    'yes with sub mechanism
                    'P&B-SUB-IQS-2019-001
                    'P&B-SUB-IQS-2019-001-STO-001
                    'P&B-SUB-FFP-2019-001
                    'P&B-SUB-IQS-BP-2019-001
                    'P&B-SUB-IQS-BP-2019-001-STO-001
                    'P&B-SUB-FFP-EAAP-2019-001

                    If id_subregion = -1 Then

                        If idFicha_Padre = -1 Then

                            'listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And Year(p.datecreated) = anio).Count()
                            listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And Year(p.datecreated) = anio).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}-{3}-{4}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, oSubMecanismo.perfijo_sub_mecanismo, anio.ToString, String.Format("{0:000}", listado + 1))

                        Else

                            'listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_ficha_padre = idFicha_Padre).Count()
                            listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.id_ficha_padre = idFicha_Padre).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}", oActivity.codigo_SAPME, oSubMecanismo.perfijo_sub_mecanismo, String.Format("{0:000}", listado + 1))

                        End If

                    Else

                        If idFicha_Padre = -1 Then
                            'listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And Year(p.datecreated) = anio And p.id_subregion = id_subregion).Count()
                            listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And Year(p.datecreated) = anio And p.id_subregion = id_subregion).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}-{3}-{4}-{5}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, oSubMecanismo.perfijo_sub_mecanismo, oSubregion.prefijo_subregion, anio.ToString, String.Format("{0:000}", listado + 1))

                        Else

                            'listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_ficha_padre = idFicha_Padre).Count()
                            listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.id_ficha_padre = idFicha_Padre).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}", oActivity.codigo_SAPME, oSubMecanismo.perfijo_sub_mecanismo, String.Format("{0:000}", listado + 1))

                        End If

                    End If

                End If

            End Using

            Return (txtCodigo)

        End Function



        Function Add_CodigoFicha(ByVal id_award_app As Integer) As String

            Dim txtCodigo As String = ""


            Using db As New dbRMS_JIEntities


                Dim listado = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.ID_AWARDED_APP = id_award_app).Count()
                Dim oTA_AWARDED_ACTIVITY = db.TA_AWARDED_ACTIVITY.Where(Function(p) p.ID_AWARDED_APP = id_award_app).FirstOrDefault()

                txtCodigo = String.Format("{0}-AC{1}", oTA_AWARDED_ACTIVITY.codigo_SAPME, String.Format("{0:000}", listado))

            End Using

            Return (txtCodigo)

        End Function


        Function CrearCodigoFichaACT(ByVal id_programa As Integer, ByVal id_subregion As Integer, ByVal id_mecanismo As Integer, Optional id_submecanismo As Integer = 0, Optional idFicha_Padre As Integer = 0) As String

            Dim txtCodigo As String = ""
            Dim fecha As DateTime = Date.Now
            Dim anio As Integer
            Dim CorrrelativoStr As String = ""

            Using db As New dbRMS_JIEntities

                Dim oPrograma = db.t_programas.Find(id_programa)
                Dim oSubregion = db.t_subregiones.Find(id_subregion)
                Dim oMecanismo = db.tme_mecanismo_contratacion.Find(id_mecanismo)
                Dim oSubMecanismo = db.tme_sub_mecanismo.Find(id_submecanismo)
                Dim oActivity = db.TA_ACTIVITY.Find(idFicha_Padre)
                '.tme_Ficha_Proyecto.Find(idFicha_Padre)

                anio = If(fecha.Month >= 10, fecha.Year + 1, fecha.Year)

                ' Dim total = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Select(Function(p) p.id_ficha_proyecto).ToList()
                Dim listado


                If oSubMecanismo.perfijo_sub_mecanismo = "NN" Then 'NO sub mechanism

                    'P&B-GRA-BP-2019-001
                    'P&B-GRA-EAAP-2019-001
                    'P&B-ACT-2019-001
                    'P&B-PO-2019-001

                    If id_subregion = -1 Then
                        'listado = db.tme_ficha_subregion.Where(Function(p) p.id_subregion = id_subregion And total.Contains(p.id_ficha_proyecto)).Count()
                        listado = db.tme_Ficha_Proyecto.Where(Function(p) p.tme_sub_mecanismo.id_mecanismo_contratacion = id_mecanismo And Year(p.datecreated) = anio).Count()
                        txtCodigo = String.Format("{0}-{1}-{2}-{3}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, anio.ToString, String.Format("{0:000}", listado + 1))

                    Else

                        listado = db.tme_Ficha_Proyecto.Where(Function(p) p.tme_sub_mecanismo.id_mecanismo_contratacion = id_mecanismo And p.id_subregion = id_subregion And Year(p.datecreated) = anio).Count()
                        txtCodigo = String.Format("{0}-{1}-{2}-{3}-{4}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, oSubregion.prefijo_subregion, anio.ToString, String.Format("{0:000}", listado + 1))

                    End If

                Else

                    'yes with sub mechanism
                    'P&B-SUB-IQS-2019-001
                    'P&B-SUB-IQS-2019-001-STO-001
                    'P&B-SUB-FFP-2019-001
                    'P&B-SUB-IQS-BP-2019-001
                    'P&B-SUB-IQS-BP-2019-001-STO-001
                    'P&B-SUB-FFP-EAAP-2019-001

                    If id_subregion = -1 Then

                        If idFicha_Padre = -1 Then
                            listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And Year(p.datecreated) = anio).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}-{3}-{4}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, oSubMecanismo.perfijo_sub_mecanismo, anio.ToString, String.Format("{0:000}", listado + 1))
                        Else
                            listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_ficha_padre = idFicha_Padre).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}", oActivity.codigo_SAPME, oSubMecanismo.perfijo_sub_mecanismo, String.Format("{0:000}", listado + 1))
                        End If

                    Else

                        If idFicha_Padre = -1 Then
                            listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_sub_mecanismo = id_submecanismo And Year(p.datecreated) = anio And p.id_subregion = id_subregion).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}-{3}-{4}-{5}", oPrograma.prefijo_actividades, oMecanismo.prefijo_mecanismo, oSubMecanismo.perfijo_sub_mecanismo, oSubregion.prefijo_subregion, anio.ToString, String.Format("{0:000}", listado + 1))
                        Else
                            listado = db.tme_Ficha_Proyecto.Where(Function(p) p.id_ficha_padre = idFicha_Padre).Count()
                            txtCodigo = String.Format("{0}-{1}-{2}", oActivity.codigo_SAPME, oSubMecanismo.perfijo_sub_mecanismo, String.Format("{0:000}", listado + 1))
                        End If

                    End If

                End If

            End Using

            Return (txtCodigo)

        End Function

        Function CodigoRandom() As String
            Try
                Dim rnd As New Random()
                Dim fecha As DateTime = Date.Now
                Dim textfecha = fecha.ToShortDateString().Replace("/", "").Replace(" ", "").Replace("a", "").Replace(".", "").Replace("m", "").Replace(":", "").Replace(";", "").Replace("p", "")
                Return (rnd.Next(1, 999).ToString & textfecha.ToString)
            Catch ex As Exception
                Return ("-1")
            End Try
        End Function

        Function getNewName(ByVal file As UploadedFile, ByVal idUser As String) As String
            Dim rand As New Random()
            Dim Aleatorio As Double = rand.Next(1, 99999)
            Dim extension As String = System.IO.Path.GetExtension(file.GetExtension())
            Dim newName As String = "doc_" & idUser & Date.UtcNow.ToShortDateString().Replace("/", "-") & Aleatorio & file.GetNameWithoutExtension().Replace("á", "a").Replace("é", "e").Replace("í", "i").Replace("ó", "o").Replace("ú", "u").Replace(" ", "_").Replace("%", "-").Replace(".", "_").Replace(",", "-").Replace("&", "-") & extension

            Return newName
        End Function

        Public Function get_t_aporte_origen(Optional id As Integer = 0, Optional visible As Boolean = True) As Object


            Dim bndP As Integer = If(id = 0, 1, 0)

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_AportesOrigen.Where(Function(p) p.id_programa = id Or 1 = bndP) _
                              .Select(Function(p) _
                                          New With {Key .nombre_AporteOrigen = p.nombre_AporteOrigen,
                                                    Key .id_AporteOrigen = p.id_AporteOrigen}).ToList()
                Return listado
            End Using
        End Function
        Public Function get_t_aporte_cl(Optional id As Integer = 0, Optional visible As Boolean = True) As Object

            Dim bndP As Integer = If(id = 0, 1, 0)

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_Aportes_CL.Where(Function(p) p.id_programa = id Or 1 = bndP) _
                              .Select(Function(p) _
                                          New With {Key .id_aporteCL = p.id_aporteCL,
                                                    Key .cl_nombreES = p.cl_nombreES}).ToList()
                Return listado
            End Using
        End Function


        Public Function get_t_budget(Optional id As Integer = 0, Optional visible As Boolean = True) As Object

            Dim bndP As Integer = If(id = 0, 1, 0)

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_budget.Where(Function(p) p.id_programa = id Or 1 = bndP) _
                              .Select(Function(p) _
                                          New With {Key .id_budget = p.id_budget,
                                                    Key .bud_nameS = p.bud_name}).ToList()
                Return listado
            End Using
        End Function


        Public Function get_t_counties(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_counties.Where(Function(p) p.id_district = id Or id = 0).OrderBy(Function(p) p.nombre_county) _
                              .Select(Function(p) _
                                          New With {Key .nombre_county = p.nombre_county,
                                                    Key .id_county = p.id_county}).ToList()
                Return listado
            End Using
        End Function
        Public Function get_t_municipio(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_municipios.Where(Function(p) p.id_departamento = id Or id = 0).OrderBy(Function(p) p.nombre_municipio) _
                              .Select(Function(p) _
                                          New With {Key .nombre_municipio = p.nombre_municipio,
                                                    Key .id_municipio = p.id_municipio}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_subcounties(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_subcounties.Where(Function(p) p.id_county = id Or id = 0).OrderBy(Function(p) p.nombre_subcounty) _
                              .Select(Function(p) _
                                          New With {Key .nombre_subcounty = p.nombre_subcounty,
                                                    Key .id_subcounty = p.id_subcounty}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_parishes(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_parishes.Where(Function(p) p.id_subcounty = id Or id = 0).OrderBy(Function(p) p.nombre_parish) _
                              .Select(Function(p) _
                                          New With {Key .nombre_parish = p.nombre_parish,
                                                    Key .id_parish = p.id_parish}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_villages(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_villages.Where(Function(p) p.id_parish = id Or id = 0).OrderBy(Function(p) p.nombre_village) _
                              .Select(Function(p) _
                                          New With {Key .nombre_village = p.nombre_village,
                                                    Key .id_village = p.id_village}).ToList()
                Return listado
            End Using
        End Function

        '--***********************************************************************************************************************
        '--*************************************************************PB***LIST*************************************************
        '--***********************************************************************************************************************


        Public Function get_t_municipios(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_municipios.Where(Function(p) p.id_departamento = id Or id = 0).OrderBy(Function(p) p.nombre_municipio) _
                              .Select(Function(p) _
                                          New With {Key .nombre_municipio = p.nombre_municipio,
                                                    Key .id_municipio = p.id_municipio}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_district(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_districts.Where(Function(p) p.id_pais = id Or id = 0).OrderBy(Function(p) p.nombre_district) _
                              .Select(Function(p) _
                                          New With {Key .nombre_district = p.nombre_district,
                                                    Key .id_district = p.id_district}).ToList()
                Return listado
            End Using

        End Function


        Public Function get_t_district2(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities

                'Dim listado = db.t_districts.Where(Function(p) p.id_pais = id Or id = 0).OrderBy(Function(p) p.nombre_district) _
                '              .Select(Function(p) _
                '                          New With {Key .nombre_district = p.nombre_district,
                '                                    Key .id_district = p.id_district}).ToList()

                Dim listado = (From div In db.tme_subregion_nivel_avance
                               Join dist In db.t_districts On div.id_relacion Equals dist.id_district
                               Where (div.id_subregion = id)
                               Select New With {.id_district = dist.id_district, .nombre_district = dist.nombre_district}).ToList()

                Return listado

            End Using

        End Function

        Public Function get_t_departamentos2(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities

                'Dim listado = db.t_districts.Where(Function(p) p.id_pais = id Or id = 0).OrderBy(Function(p) p.nombre_district) _
                '              .Select(Function(p) _
                '                          New With {Key .nombre_district = p.nombre_district,
                '                                    Key .id_district = p.id_district}).ToList()

                Dim listado = (From div In db.tme_subregion_nivel_avance
                               Join dist In db.t_departamentos On div.id_relacion Equals dist.id_departamento
                               Where (div.id_subregion = id)
                               Select New With {.id_departamento = dist.id_departamento, .nombre_departamento = dist.nombre_departamento}).ToList()

                Return listado

            End Using

        End Function
        Public Function get_t_departamentos3(Optional id As Integer = 0, Optional idCountry As Integer = 0) As Object

            Using db As New dbRMS_JIEntities

                'Dim listado = db.t_districts.Where(Function(p) p.id_pais = id Or id = 0).OrderBy(Function(p) p.nombre_district) _
                '              .Select(Function(p) _
                '                          New With {Key .nombre_district = p.nombre_district,
                '                                    Key .id_district = p.id_district}).ToList()

                Dim listado = (From div In db.tme_subregion_nivel_avance
                               Join dist In db.t_departamentos On div.id_relacion Equals dist.id_departamento
                               Where (div.id_subregion = id And dist.id_pais = idCountry)
                               Select New With {.id_departamento = dist.id_departamento, .nombre_departamento = dist.nombre_departamento}).ToList()

                Return listado

            End Using

        End Function
        Public Function get_t_district3(Optional id As Integer = 0, Optional idCountry As Integer = 0) As Object

            Using db As New dbRMS_JIEntities

                'Dim listado = db.t_districts.Where(Function(p) p.id_pais = id Or id = 0).OrderBy(Function(p) p.nombre_district) _
                '              .Select(Function(p) _
                '                          New With {Key .nombre_district = p.nombre_district,
                '                                    Key .id_district = p.id_district}).ToList()

                Dim listado = (From div In db.tme_subregion_nivel_avance
                               Join dist In db.t_districts On div.id_relacion Equals dist.id_district
                               Where (div.id_subregion = id And dist.id_pais = idCountry)
                               Select New With {.id_district = dist.id_district, .nombre_district = dist.nombre_district}).ToList()

                Return listado

            End Using

        End Function


        'Public Function get_t_counties(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.t_counties.Where(Function(p) p.id_district = id Or id = 0).OrderBy(Function(p) p.nombre_county) _
        '                      .Select(Function(p) _
        '                                  New With {Key .nombre_county = p.nombre_county,
        '                                            Key .id_county = p.id_county}).ToList()
        '        Return listado
        '    End Using
        'End Function

        'Public Function get_t_subcounties(Optional id As Integer = 0) As Object

        '    Using db As New dbRMS_JIEntities
        '        Dim listado = db.t_subcounties.Where(Function(p) p.id_county = id Or id = 0).OrderBy(Function(p) p.nombre_subcounty) _
        '                      .Select(Function(p) _
        '                                  New With {Key .nombre_subcounty = p.nombre_subcounty,
        '                                            Key .id_subcounty = p.id_subcounty}).ToList()
        '        Return listado
        '    End Using
        'End Function

        Public Function get_t_parish(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_parishes.Where(Function(p) p.id_subcounty = id Or id = 0).OrderBy(Function(p) p.nombre_parish) _
                              .Select(Function(p) _
                                          New With {Key .nombre_parish = p.nombre_parish,
                                                    Key .id_parish = p.id_parish}).ToList()
                Return listado
            End Using

        End Function

        Public Function get_t_veredas(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_veredas.Where(Function(p) p.id_municipio = id Or id = 0).OrderBy(Function(p) p.vereda) _
                              .Select(Function(p) _
                                          New With {Key .vereda = p.vereda,
                                                    Key .id_vereda = p.id_vereda}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_t_corregimientos(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.t_corregimientos.Where(Function(p) p.id_municipio = id Or id = 0).OrderBy(Function(p) p.corregimiento) _
                              .Select(Function(p) _
                                          New With {Key .corregimiento = p.corregimiento,
                                                    Key .id_corregimiento = p.id_corregimiento}).ToList()
                Return listado
            End Using
        End Function

        Public Function get_tme_list_hitos(Optional id As Integer = 0) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_hitos.Where(Function(p) p.id_estructura_marco_logico = id Or id = 0) _
                              .Select(Function(p) _
                                          New With {Key .hito = p.hito,
                                                    Key .id_hito = p.id_hito}).ToList()
                Return listado
            End Using
        End Function


        Public Function get_tme_filtro_busqueda_viajes(ByVal idP As Integer) As Object

            Using db As New dbRMS_JIEntities
                Dim listado = db.tme_filtro_busqueda_viajes.Select(Function(p) _
                                                       New With {Key .filtro_busqueda = p.filtro_busqueda,
                                                                 Key .id_filtro_busqueda_viajes = p.id_filtro_busqueda_viajes}).ToList()
                Return listado
            End Using

        End Function

        '--***********************************************************************************************************************
        '--*************************************************************PB***LIST*************************************************
        '--***********************************************************************************************************************


    End Class



End Namespace
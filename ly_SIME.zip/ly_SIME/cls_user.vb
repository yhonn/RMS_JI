﻿Imports System.Configuration.ConfigurationManager
Imports System.Data.SqlClient
Imports System.Globalization
Imports Telerik.Web.UI

Namespace CORE

    Public Class cls_user

        Sub New()
            ' TODO: Complete member initialization 
        End Sub


        Public Property controles_otros As List(Of ly_SIME.vw_control_otro_idioma)
        Public Property codigo_nivel_usuario As String = 0

        Public Property id_usr As Integer = 0
        Public Property id_rolUsr As Integer = 0

        Public Property str_roles_Usr As String = ""
        Public Property arr_roles_Usr As Integer()

        Public Property str_roles_d_Usr As String = ""
        Public Property arr_roles_d_Usr As Integer()

        Public Property id_rolUsrACT As Integer = 0
        Public Property id_rolUsrDES As Integer = 0
        Public Property id_rol As Integer = 0
        Public Property idSys As Integer = 0
        Public Property idLog As Integer = 0
        Public Property idROL As Integer = 0
        Public Property regionalizacion As String = ""

        Public Property regionalizacionCulture As CultureInfo
        Public Property idGuiToken As Guid
        Public Property idToken As Integer

        Public Property Id_Cprogram As Integer
        Public Property programa As String = ""

        Public Property id_idioma As Integer = 0

        Public Property vRemoteAddr As String
        Public Property vUserAgent As String
        Public Property vLocalAddr As String

        '************CONST VAR**************
        Const C_Open_Token = 1
        Const C_Closed_Token = 2
        Const C_Expired_Token = 3
        Const C_Cancelled_Token = 4

        Public Const C_SysMYE = 1
        Public Const C_SysAPPROVAL = 2

        '************CONST VAR**************

        Dim tbl_userINFO As DataTable
        Dim tbl_LOGuser As DataTable
        Dim tbl_rol As DataTable
        Dim tbl_LogIn As DataTable
        Dim tbl_token_user As DataTable


        Dim cnn As New SqlConnection(ConnectionStrings("dbCI_SAPConnectionString").ConnectionString)
        Dim cultureINF As CultureInfo
        Dim utlCORE As New CORE.cls_util

        Public Sub New(ByVal idS As Integer, ByVal idu As Integer, ByVal idP As Integer)

            'If idS <> 0 Then

            ''cultureINF = New CultureInfo("en-US")
            ''Thread.CurrentThread.CurrentCulture = cultureINF

            tbl_userINFO = New DataTable("userINFO")
            tbl_LOGuser = New DataTable("logUser")
            tbl_token_user = New DataTable("token_user")

            idLog = 0
            idToken = 0
            idGuiToken = Guid.Empty

            idSys = IIf(idS <> 0, idS, idSys)
            Id_Cprogram = IIf(idP <> 0, idP, 0)


            If idu <> 0 Then

                id_usr = idu
                init_usr(Id_Cprogram, id_usr)
                idROL = tbl_userINFO.Rows.Item(0).Item("id_rol")

            End If

            'End If

        End Sub

        Public Sub init_usr(ByVal idP As Integer, Optional ByVal idus As Integer = 0)

            Dim strProgramSQL As String = String.Format(" and id_programa = {0} ", idP)

            If idus <> id_usr Then
                id_usr = idus
            End If

            Id_Cprogram = IIf(idP > 0, idP, 0)

            Dim strSQL = String.Format("select * from vw_t_users_rol where id_usuario = {0} ", id_usr)
            strSQL = IIf(Id_Cprogram > 0, String.Format(" {0} {1} ", strSQL, strProgramSQL), strSQL)
            tbl_userINFO = utlCORE.setObjeto("vw_t_users_rol", "id_usuario", id_usr, strSQL).Copy

            Dim strSQL2 = String.Format("select * from vw_t_usuarios where id_usuario = {0} ", id_usr)
            strSQL2 = IIf(Id_Cprogram > 0, String.Format(" {0} {1} ", strSQL2, strProgramSQL), strSQL2)
            tbl_LogIn = utlCORE.setObjeto("vw_t_usuarios", "id_usuario", 0, strSQL2).Copy



            id_rolUsr = tbl_userINFO.Rows.Item(0).Item("id_rol")

            str_roles_Usr = tbl_userINFO.Rows.Item(0).Item("roles")
            Dim datos As New List(Of Integer)
            For Each strD As String In str_roles_Usr.Split(",")
                datos.Add(Convert.ToInt32(strD))
            Next
            arr_roles_Usr = datos.ToArray()

            str_roles_d_Usr = tbl_userINFO.Rows.Item(0).Item("roles_d")
            Dim datosD As New List(Of Integer)
            For Each strD As String In str_roles_d_Usr.Split(",")
                datosD.Add(Convert.ToInt32(strD))
            Next
            arr_roles_d_Usr = datos.ToArray()

            '**********************ROL activo*************************
            id_rolUsrACT = tbl_userINFO.Rows.Item(0).Item("id_rol")
            '**********************ROL activo*************************
            id_rolUsrDES = 0 ' tbl_userINFO.Rows.Item(0).Item("id_rold")

        End Sub

        Public Sub set_sysUsr(idS As Integer)
            If idS > 0 Then
                idSys = idS
            End If
        End Sub

        Public Sub init_Rol(Optional ByVal idRol As Integer = 0)

            If idRol <> id_rol Then
                id_rol = idRol
            End If

            tbl_rol = utlCORE.setObjeto("t_rol", "id_rol", id_rol).Copy

        End Sub


        Public Sub setRolField(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            tbl_rol = utlCORE.setDTval(tbl_rol, campoSearch, campo, valorSearch, valor)

        End Sub


        Public Function getUserField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(tbl_userINFO, campoSearch, campo, valorSearch)

        End Function


        Public Function getRolField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(tbl_rol, campoSearch, campo, valorSearch)

        End Function

        Public Function save_Rol() As Integer

            Dim RES As Integer

            RES = utlCORE.SaveObjeto("t_rol", tbl_rol, "id_rol", id_rol)

            If RES <> -1 Then
                save_Rol = RES
                id_rol = RES
                setRolField("id_rol", id_rol, "id_rol", 0)
            Else
                save_Rol = RES
            End If

        End Function

        Public Sub init_logUSR(ByVal idusu As Integer)

            'Try
            tbl_LOGuser = utlCORE.setObjeto("t_log_user", "id_log_usr", idLog).Copy

            setLOGfield("id_usr", idusu, "id_log_usr", idLog)
            setLOGfield("id_sys", idSys, "id_log_usr", idLog)
            setLOGfield("lg_date_start", Date.UtcNow, "id_log_usr", idLog)

            'Catch ex As Exception
            'End Try

        End Sub


        Public Sub setLOGfield(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            tbl_LOGuser = utlCORE.setDTval(tbl_LOGuser, campoSearch, campo, valorSearch, valor)

        End Sub

        Public Function getLOGfield(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(tbl_LOGuser, campoSearch, campo, valorSearch)

        End Function

        Public Function save_LOG() As Integer

            Dim RES As Integer
            RES = utlCORE.SaveObjeto("t_log_user", tbl_LOGuser, "id_log_usr", idLog)

            If RES <> -1 Then
                save_LOG = RES
                idLog = RES
                setLOGfield("id_log_usr", idLog, "id_log_usr", 0)
            Else
                save_LOG = RES
            End If




        End Function



        Public Function chk_accessMOD(ByVal idMOD As Integer, Optional strCODE As String = "") As Boolean

            'Verifica el acceso al modulo solicitado
            Dim strCondition As String = ""

            'If strCODE.Length > 0 Then
            '    strCondition = String.Format("  where mod_code = '{0}' and id_rol = {1} ", Trim(strCODE), id_rolUsr)
            'Else
            '    strCondition = String.Format("  where id_mod = '{0}'  and id_rol = {1}  ", idMOD, id_rolUsr)
            'End If

            'Dim Sql = String.Format("select acm_acc from VW_GR_USER_MOD	{0} ", strCondition)

            If strCODE.Length > 0 Then
                strCondition = String.Format("  where mod_code = '{0}' and acm_acc = 1 and (id_rol in ({1}) or (id_programa = {2} and id_usuario = {3})) ", Trim(strCODE), str_roles_Usr, Id_Cprogram, id_usr)
            Else
                strCondition = String.Format("  where id_mod = '{0}' and acm_acc = 1 and (id_rol in ({1}) or (id_programa = {2} and id_usuario = {3})) ", idMOD, str_roles_Usr, Id_Cprogram, id_usr)
            End If

            Dim Sql = String.Format("select distinct acm_acc from VW_GR_USER_MOD {0} ", strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("chkACC")
            dm.Fill(ds, "chkACC")

            If ds.Tables.Item("chkACC").Rows.Count = 0 Then
                chk_accessMOD = False
            Else
                chk_accessMOD = CType(ds.Tables.Item("chkACC").Rows.Item(0).Item("acm_acc"), Boolean)
            End If

        End Function


        Public Function chk_accessCTRLS(ByVal tpCtrl As Integer, ByVal idMOD As Integer, Optional strCODE As String = "") As DataTable

            'Verifica el acceso los controles
            Dim strCondition As String = ""

            If strCODE.Length > 0 Then
                'strCondition = String.Format(" where ctrl_type = {0} and mod_code = '{1}' and id_rol = {2} ", tpCtrl, Trim(strCODE), id_rolUsr)
                strCondition = String.Format(" where ctrl_type = {0} and mod_code = '{1}' and actrl_acc = 1 and (id_rol in ({2}) or (id_programa = {3} and id_usuario = {4})) ", tpCtrl, Trim(strCODE), str_roles_Usr, Id_Cprogram, id_usr)
                ' and (id_rol in ({1}) or (id_programa = {2} and id_usuario = {3})) ", Trim(strCODE), str_roles_Usr, Id_Cprogram, id_usr)
            Else
                'strCondition = String.Format(" where ctrl_type = {0} and id_mod = '{1}'  and id_rol = {2} ", tpCtrl, idMOD, id_rolUsr)
                strCondition = String.Format(" where ctrl_type = {0} and  id_mod = '{1}' and actrl_acc = 1 and (id_rol in ({2}) or (id_programa = {3} and id_usuario = {4})) ", tpCtrl, idMOD, str_roles_Usr, Id_Cprogram, id_usr)
                ' and (id_rol in ({1}) or (id_programa = {2} and id_usuario = {3})) ", Trim(strCODE), str_roles_Usr, Id_Cprogram, id_usr)
            End If

            Dim Sql = String.Format(" select distinct id_control, ctrl_code, ctrl_name, ctrl_obs, actrl_acc, bloquear_control, bloquear_cierre_trimestre from VW_GR_USER_CTRLS {0} ", strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("chkCTRLS")
            dm.Fill(ds, "chkCTRLS")

            chk_accessCTRLS = ds.Tables.Item("chkCTRLS")

        End Function

        Public Function chk_periodoEnable(Optional strCODE As String = "") As Integer

            'Verifica el acceso los controles
            Dim strCondition As String = ""

            If strCODE.Length > 0 Then
                'strCondition = String.Format(" where ctrl_type = {0} and mod_code = '{1}' and id_rol = {2} ", tpCtrl, Trim(strCODE), id_rolUsr)
                strCondition = String.Format(" where id_programa = {0} and activo = 1 and bloqueado = 1 ", Id_Cprogram)
                ' and (id_rol in ({1}) or (id_programa = {2} and id_usuario = {3})) ", Trim(strCODE), str_roles_Usr, Id_Cprogram, id_usr)
            Else
                'strCondition = String.Format(" where ctrl_type = {0} and id_mod = '{1}'  and id_rol = {2} ", tpCtrl, idMOD, id_rolUsr)
                strCondition = String.Format(" where id_programa = {0} and activo = 1 and bloqueado = 1 ", Id_Cprogram)
                ' and (id_rol in ({1}) or (id_programa = {2} and id_usuario = {3})) ", Trim(strCODE), str_roles_Usr, Id_Cprogram, id_usr)
            End If

            Dim Sql = String.Format("select case count(*) when 0 then 1 else 0 end as periodo_enable from vw_t_periodos {0} ", strCondition)

            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("chkperiodoEnable")
            dm.Fill(ds, "chkperiodoEnable")
            Dim table = ds.Tables.Item("chkperiodoEnable")
            chk_periodoEnable = table.Rows(0)("periodo_enable")

        End Function

        Public Sub chk_Rights(ByRef ctrls As System.Web.UI.ControlCollection, ByVal optType As Integer, ByVal strFORM As String, Optional ByVal idFORM As Integer = 0, Optional ByRef grdGRID As Telerik.Web.UI.RadGrid = Nothing, Optional id_ficha_estado As Integer = Nothing)

            Dim vCtrl As Object
            Dim ctrllock As Boolean
            Dim enableCtrlRol As Boolean
            Dim grdColumn As GridColumn

            For Each vControl As System.Web.UI.Control In ctrls
                FindControlDatePicker(vControl)
                findControlRadNumeri(vControl)
            Next

            Select Case optType
                Case 1
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, rw("ctrl_code"))
                            If Not vCtrl Is Nothing Then
                                If CType(rw("actrl_acc"), Boolean) Then
                                    vCtrl.Visible = True
                                End If
                            End If
                        Next
                        vCtrl = Nothing
                    Next
                Case 2
                    Dim periodo_enable = chk_periodoEnable()
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        grdColumn = FindColumn(rw("ctrl_code"), grdGRID)
                        If rw("bloquear_control") IsNot Nothing Then
                            ctrllock = rw("bloquear_control")
                        Else
                            ctrllock = False
                        End If

                        If rw("bloquear_cierre_trimestre") IsNot Nothing Then
                            enableCtrlRol = rw("bloquear_cierre_trimestre")
                        Else
                            enableCtrlRol = True
                        End If
                        If Not grdColumn Is Nothing Then




                            If ctrllock = True Then
                                If periodo_enable = 1 And id_ficha_estado = 2 Then
                                    If CType(rw("actrl_acc"), Boolean) Then
                                        grdColumn.Visible = True
                                    End If
                                ElseIf periodo_enable = 0 Then
                                    If enableCtrlRol = False Then
                                        grdColumn.Visible = True
                                    End If
                                ElseIf id_ficha_estado = 4 Or id_ficha_estado = 3 Or id_ficha_estado = 5 Or id_ficha_estado = 6 Then
                                    If enableCtrlRol = False Then
                                        grdColumn.Visible = True
                                    End If
                                End If
                            Else
                                If CType(rw("actrl_acc"), Boolean) Then
                                    grdColumn.Visible = True
                                End If
                            End If

                        End If
                    Next


                    'For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                    '    grdColumn = FindColumn(rw("ctrl_code"), grdGRID)
                    '    If Not grdColumn Is Nothing Then
                    '        If CType(rw("actrl_acc"), Boolean) Then
                    '            grdColumn.Visible = True
                    '        End If
                    '    End If
                    'Next
                    grdColumn = Nothing
                Case 3
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, rw("ctrl_code"))
                            If Not vCtrl Is Nothing Then
                                If CType(rw("actrl_acc"), Boolean) Then
                                    vCtrl.Value = CType(rw("ctrl_obs"), Integer)
                                End If
                            End If
                        Next
                        vCtrl = Nothing
                    Next
                Case 4
                    Dim periodo_enable = chk_periodoEnable()
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, rw("ctrl_code"))
                            If rw("bloquear_control") IsNot Nothing Then
                                ctrllock = rw("bloquear_control")
                            Else
                                ctrllock = False
                            End If



                            If rw("bloquear_cierre_trimestre") IsNot Nothing Then
                                enableCtrlRol = rw("bloquear_cierre_trimestre")
                            Else
                                enableCtrlRol = True
                            End If


                            If Not vCtrl Is Nothing Then
                                If ctrllock = True Then
                                    If periodo_enable = 1 And id_ficha_estado = 2 Then
                                        If CType(rw("actrl_acc"), Boolean) Then
                                            vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
                                        End If
                                    ElseIf periodo_enable = 0 Then
                                        If enableCtrlRol = False Then
                                            If CType(rw("actrl_acc"), Boolean) Then
                                                vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
                                            End If
                                        End If
                                    ElseIf id_ficha_estado = 4 Or id_ficha_estado = 3 Or id_ficha_estado = 5 Or id_ficha_estado = 6 Then
                                        If enableCtrlRol = False Then
                                            If CType(rw("actrl_acc"), Boolean) Then
                                                vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
                                            End If
                                        End If
                                    End If
                                Else
                                    If CType(rw("actrl_acc"), Boolean) Then
                                        vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
                                    End If
                                End If
                            End If



                        Next
                        vCtrl = Nothing
                    Next

                Case 5

                    Dim strOPT As String = ""
                    Dim nCtrol As String = ""
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        strOPT = ""
                        nCtrol = ""
                        If CType(rw("actrl_acc"), Boolean) Then
                            If strOPT.Length = 0 Then
                                strOPT &= CType(rw("ctrl_obs"), Integer)
                                nCtrol = rw("ctrl_code")
                            Else
                                strOPT &= "," & CType(rw("ctrl_obs"), Integer)
                            End If
                        End If
                        If strOPT.Length > 0 And nCtrol.Length > 0 Then
                            For Each vControl As System.Web.UI.Control In ctrls
                                vCtrl = FindControl(vControl, nCtrol.Trim)
                                If Not vCtrl Is Nothing Then
                                    vCtrl.Value = strOPT.Trim
                                    Exit For
                                End If
                            Next
                        End If
                    Next



                Case 6

                    Dim strOPT As String = ""
                    Dim nCtrol As String = ""
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        If CType(rw("actrl_acc"), Boolean) Then
                            If strOPT.Length = 0 Then
                                strOPT &= CType(rw("ctrl_obs"), String)
                                nCtrol = rw("ctrl_code")
                            Else
                                strOPT &= "," & CType(rw("ctrl_obs"), String)
                            End If
                        End If
                    Next

                    If strOPT.Length > 0 And nCtrol.Length > 0 Then
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, nCtrol.Trim)
                            If Not vCtrl Is Nothing Then
                                vCtrl.Value = strOPT.Trim
                                Exit For
                            End If
                        Next
                    End If

                Case 7

                    Dim strOPT As String = ""
                    Dim nCtrol As String = ""
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        If CType(rw("actrl_acc"), Boolean) Then
                            If strOPT.Length = 0 Then
                                strOPT &= CType(rw("ctrl_obs"), Integer)
                                nCtrol = rw("ctrl_code")
                            Else
                                strOPT &= "," & CType(rw("ctrl_obs"), Integer)
                            End If
                        End If
                    Next

                    If strOPT.Length > 0 And nCtrol.Length > 0 Then
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, nCtrol.Trim)
                            If Not vCtrl Is Nothing Then
                                vCtrl.Value = strOPT.Trim
                                Exit For
                            End If
                        Next
                    End If
                Case 8
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, rw("ctrl_code"))
                            If Not vCtrl Is Nothing Then
                                If CType(rw("actrl_acc"), Boolean) Then
                                    vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
                                End If
                            End If
                        Next
                        vCtrl = Nothing
                    Next
                Case 14 'Radio button to Visible / Not Visible
                    For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
                        For Each vControl As System.Web.UI.Control In ctrls
                            vCtrl = FindControl(vControl, rw("ctrl_code"))
                            If Not vCtrl Is Nothing Then
                                If CType(rw("actrl_acc"), Boolean) Then
                                    vCtrl.Visible = True
                                End If
                            End If
                        Next
                        vCtrl = Nothing
                    Next
            End Select
        End Sub

        'Public Sub chk_Rights(ByRef ctrls As System.Web.UI.ControlCollection, ByVal optType As Integer, ByVal strFORM As String, Optional ByVal idFORM As Integer = 0, Optional ByRef grdGRID As Telerik.Web.UI.RadGrid = Nothing, Optional id_ficha_estado As Integer = Nothing)

        '    Dim vCtrl As Object
        '    Dim grdColumn As GridColumn
        '    Dim ctrllock As Boolean

        '    For Each vControl As System.Web.UI.Control In ctrls
        '        FindControlDatePicker(vControl)
        '        findControlRadNumeri(vControl)
        '    Next

        '    Select Case optType
        '        Case 1
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, rw("ctrl_code"))
        '                    If Not vCtrl Is Nothing Then
        '                        If CType(rw("actrl_acc"), Boolean) Then
        '                            vCtrl.Visible = True
        '                        End If
        '                    End If
        '                Next
        '                vCtrl = Nothing
        '            Next
        '        Case 2
        '            Dim periodo_enable = chk_periodoEnable()
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                grdColumn = FindColumn(rw("ctrl_code"), grdGRID)
        '                If rw("bloquear_control") IsNot Nothing Then
        '                    ctrllock = rw("bloquear_control")
        '                Else
        '                    ctrllock = False
        '                End If

        '                If Not grdColumn Is Nothing Then




        '                    If ctrllock = True Then
        '                        If periodo_enable = 1 And id_ficha_estado = 2 Then
        '                            If CType(rw("actrl_acc"), Boolean) Then
        '                                grdColumn.Visible = True
        '                            End If
        '                        ElseIf periodo_enable = 0 Then

        '                        ElseIf id_ficha_estado = 4 Or id_ficha_estado = 3 Or id_ficha_estado = 5 Or id_ficha_estado = 6 Then

        '                        End If
        '                    Else
        '                        If CType(rw("actrl_acc"), Boolean) Then
        '                            grdColumn.Visible = True
        '                        End If
        '                    End If

        '                End If


        '                'grdColumn = FindColumn(rw("ctrl_code"), grdGRID)
        '                'If Not grdColumn Is Nothing Then

        '                '    If CType(rw("actrl_acc"), Boolean) Then
        '                '        grdColumn.Visible = True
        '                '    End If



        '                '    If ctrllock = True Then
        '                '        If periodo_enable = 1 And id_ficha_estado = 2 Then
        '                '            If CType(rw("actrl_acc"), Boolean) Then
        '                '                grdColumn.Visible = True
        '                '            End If
        '                '        ElseIf periodo_enable = 0 Then
        '                '            If enableCtrlRol = False Then
        '                '                grdColumn.Visible = True
        '                '            End If
        '                '        ElseIf id_ficha_estado = 4 Or id_ficha_estado = 3 Or id_ficha_estado = 5 Or id_ficha_estado = 6 Then
        '                '            If enableCtrlRol = False Then
        '                '                grdColumn.Visible = True
        '                '            End If
        '                '        End If
        '                '    Else
        '                '        If CType(rw("actrl_acc"), Boolean) Then
        '                '            grdColumn.Visible = True
        '                '        End If
        '                '    End If




        '                'End If
        '            Next
        '            grdColumn = Nothing
        '        Case 3
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, rw("ctrl_code"))
        '                    If Not vCtrl Is Nothing Then
        '                        If CType(rw("actrl_acc"), Boolean) Then
        '                            vCtrl.Value = CType(rw("ctrl_obs"), Integer)
        '                        End If
        '                    End If
        '                Next
        '                vCtrl = Nothing
        '            Next
        '        Case 4

        '            Dim periodo_enable = chk_periodoEnable()
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, rw("ctrl_code"))
        '                    If rw("bloquear_control") IsNot Nothing Then
        '                        ctrllock = rw("bloquear_control")
        '                    Else
        '                        ctrllock = False
        '                    End If


        '                    If Not vCtrl Is Nothing Then
        '                        If ctrllock = True Then
        '                            If periodo_enable = 1 And id_ficha_estado = 2 Then
        '                                If CType(rw("actrl_acc"), Boolean) Then
        '                                    vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
        '                                End If
        '                            ElseIf periodo_enable = 0 Then

        '                            ElseIf id_ficha_estado = 4 Or id_ficha_estado = 3 Or id_ficha_estado = 5 Or id_ficha_estado = 6 Then

        '                            End If
        '                        Else
        '                            If CType(rw("actrl_acc"), Boolean) Then
        '                                vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
        '                            End If
        '                        End If
        '                    End If



        '                Next
        '                vCtrl = Nothing
        '            Next



        '            'For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '            '    For Each vControl As System.Web.UI.Control In ctrls
        '            '        vCtrl = FindControl(vControl, rw("ctrl_code"))
        '            '        If Not vCtrl Is Nothing Then
        '            '            If CType(rw("actrl_acc"), Boolean) Then
        '            '                vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
        '            '            End If
        '            '        End If
        '            '    Next
        '            '    vCtrl = Nothing
        '            'Next
        '        Case 5

        '            Dim strOPT As String = ""
        '            Dim nCtrol As String = ""
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                If CType(rw("actrl_acc"), Boolean) Then
        '                    If strOPT.Length = 0 Then
        '                        strOPT &= CType(rw("ctrl_obs"), Integer)
        '                        nCtrol = rw("ctrl_code")
        '                    Else
        '                        strOPT &= "," & CType(rw("ctrl_obs"), Integer)
        '                    End If
        '                End If
        '            Next

        '            If strOPT.Length > 0 And nCtrol.Length > 0 Then
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, nCtrol.Trim)
        '                    If Not vCtrl Is Nothing Then
        '                        vCtrl.Value = strOPT.Trim
        '                        Exit For
        '                    End If
        '                Next
        '            End If

        '        Case 6

        '            Dim strOPT As String = ""
        '            Dim nCtrol As String = ""
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                If CType(rw("actrl_acc"), Boolean) Then
        '                    If strOPT.Length = 0 Then
        '                        strOPT &= CType(rw("ctrl_obs"), String)
        '                        nCtrol = rw("ctrl_code")
        '                    Else
        '                        strOPT &= "," & CType(rw("ctrl_obs"), String)
        '                    End If
        '                End If
        '            Next

        '            If strOPT.Length > 0 And nCtrol.Length > 0 Then
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, nCtrol.Trim)
        '                    If Not vCtrl Is Nothing Then
        '                        vCtrl.Value = strOPT.Trim
        '                        Exit For
        '                    End If
        '                Next
        '            End If

        '        Case 7

        '            Dim strOPT As String = ""
        '            Dim nCtrol As String = ""
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                If CType(rw("actrl_acc"), Boolean) Then
        '                    If strOPT.Length = 0 Then
        '                        strOPT &= CType(rw("ctrl_obs"), Integer)
        '                        nCtrol = rw("ctrl_code")
        '                    Else
        '                        strOPT &= "," & CType(rw("ctrl_obs"), Integer)
        '                    End If
        '                End If
        '            Next

        '            If strOPT.Length > 0 And nCtrol.Length > 0 Then
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, nCtrol.Trim)
        '                    If Not vCtrl Is Nothing Then
        '                        vCtrl.Value = strOPT.Trim
        '                        Exit For
        '                    End If
        '                Next
        '            End If
        '        Case 8
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, rw("ctrl_code"))
        '                    If Not vCtrl Is Nothing Then
        '                        If CType(rw("actrl_acc"), Boolean) Then
        '                            vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
        '                        End If
        '                    End If
        '                Next
        '                vCtrl = Nothing
        '            Next
        '        Case 14 'Radio button to Visible / Not Visible
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, rw("ctrl_code"))
        '                    If Not vCtrl Is Nothing Then
        '                        If CType(rw("actrl_acc"), Boolean) Then
        '                            vCtrl.Visible = True
        '                        End If
        '                    End If
        '                Next
        '                vCtrl = Nothing
        '            Next
        '        Case 15
        '            For Each rw As DataRow In chk_accessCTRLS(optType, idFORM, strFORM).Rows
        '                For Each vControl As System.Web.UI.Control In ctrls
        '                    vCtrl = FindControl(vControl, rw("ctrl_code"))
        '                    If Not vCtrl Is Nothing Then
        '                        If CType(rw("actrl_acc"), Boolean) Then
        '                            vCtrl.Enabled = CType(rw("actrl_acc"), Boolean)
        '                        End If
        '                    End If
        '                Next
        '                vCtrl = Nothing
        '            Next

        '    End Select
        'End Sub





        Public Function FindColumn(ByVal grdCname As String, ByRef grdGRID As Telerik.Web.UI.RadGrid) As GridColumn

            For Each grdColumn As GridColumn In grdGRID.MasterTableView.RenderColumns
                If grdColumn.UniqueName = grdCname Then
                    FindColumn = grdColumn
                    Exit For
                End If
            Next

        End Function

        Public Function FindControl(ByVal ctrl As System.Web.UI.Control, ByVal controlID As String) As Object

            If String.Compare(ctrl.ID, controlID, True) = 0 Then
                ' We found the control!
                Return ctrl
            Else
                ' Recurse through ctrl's Controls collections
                For Each child As System.Web.UI.Control In ctrl.Controls
                    Dim lookFor As System.Web.UI.Control = FindControl(child, controlID)

                    If lookFor IsNot Nothing Then
                        Return lookFor  ' We found the control
                    End If
                Next

                ' If we reach here, control was not found
                Return Nothing
            End If
        End Function

        Public Function findControlRadNumeri(ByVal ctrl As System.Web.UI.Control) As Object
            If TryCast(ctrl, RadNumericTextBox) IsNot Nothing Then
                Dim prueba2 = CType(ctrl, RadNumericTextBox)
                If prueba2 IsNot Nothing Then
                    prueba2.Culture = New System.Globalization.CultureInfo(regionalizacion)
                    'prueba.DateInput.DisplayDateFormat = New System.Globalization.CultureInfo(regionalizacion).DateTimeFormat.ShortDatePattern()
                    'prueba.DateInput.DateFormat = New System.Globalization.CultureInfo(regionalizacion).DateTimeFormat.ShortDatePattern()
                End If
                Return ctrl
                ' We found the control!
            Else
                ' Recurse through ctrl's Controls collections
                For Each child As System.Web.UI.Control In ctrl.Controls
                    Dim lookFor As System.Web.UI.Control = findControlRadNumeri(child)
                Next

                ' If we reach here, control was not found
                Return Nothing
            End If

            ' If we reach here, control was not found
            Return Nothing
        End Function
        Public Function FindControlDatePicker(ByVal ctrl As System.Web.UI.Control) As Object

            ' Recurse through ctrl's Controls collections
            If TryCast(ctrl, RadDatePicker) IsNot Nothing Then
                Dim prueba = CType(ctrl, RadDatePicker)
                If prueba IsNot Nothing Then
                    prueba.Calendar.CultureInfo = New System.Globalization.CultureInfo(regionalizacion)
                    If (prueba.DateInput.ReadOnly = False) Then
                        prueba.DateInput.DisplayDateFormat = New System.Globalization.CultureInfo(regionalizacion).DateTimeFormat.ShortDatePattern()
                        prueba.DateInput.DateFormat = New System.Globalization.CultureInfo(regionalizacion).DateTimeFormat.ShortDatePattern()
                    End If
                End If
                Return ctrl
                ' We found the control!
            Else
                ' Recurse through ctrl's Controls collections
                For Each child As System.Web.UI.Control In ctrl.Controls
                    Dim lookFor As System.Web.UI.Control = FindControlDatePicker(child)
                Next

                ' If we reach here, control was not found
                Return Nothing
            End If

            ' If we reach here, control was not found
            Return Nothing
        End Function


        Public Function get_Roles() As DataTable

            'DEvuelve todos los roles definidos en el sistema
            Dim Sql = String.Format(" select * from t_rol ")
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("ROL")
            dm.Fill(ds, "ROL")
            get_Roles = ds.Tables.Item("ROL")

        End Function



        ''--**********************************************************************************************************************

        'Public Function Test_LogUsr(ByVal idPrograma As Integer, ByVal strUSR As String, ByVal stringPASS As String) As Integer



        '    Dim strSql As String = String.Format("SELECT * from vw_t_usuarios WHERE UPPER(usuario)='{0}' " &
        '                                         "  AND ESTADO='ACTIVE' AND id_programa = {2} " &
        '                                         "   AND ( (clave=HashBytes('SHA','{1}')) OR ( dbo.FN_GR_GET_PASS_MAX('{1}')= 1)) ", strUSR.ToUpper, stringPASS, idPrograma)

        '    tbl_LogIn = utlCORE.setObjeto("vw_t_usuarios", "id_usuario", 0, strSql).Copy

        '    Id_Cprogram = idPrograma
        '    programa = tbl_LogIn.Rows.Item(0).Item("nombre_programa")
        '    Test_LogUsr = tbl_LogIn.Rows.Item(0).Item("id_usuario")

        'End Function


        Public Function LogUsr(ByVal idPrograma As Integer, ByVal strUSR As String, ByVal stringPASS As String) As Integer
            Try

                cnn.Open()
                Dim cmd As System.Data.SqlClient.SqlCommand = New System.Data.SqlClient.SqlCommand("RMS_userLogIN", cnn)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue
                cmd.Parameters.AddWithValue("@_user", strUSR.Trim)
                cmd.Parameters.AddWithValue("@_password", stringPASS.Trim)
                cmd.Parameters.AddWithValue("@_id_programa", idPrograma)

                Dim idUSR As Integer = 0
                cmd.ExecuteNonQuery()
                idUSR = cmd.Parameters("@RETURN_VALUE").Value
                cnn.Close()

                tbl_LogIn = utlCORE.setObjeto("vw_t_usuarios", "id_usuario", idUSR).Copy

                Id_Cprogram = idPrograma
                programa = tbl_LogIn.Rows.Item(0).Item("nombre_programa")
                LogUsr = tbl_LogIn.Rows.Item(0).Item("id_usuario")


            Catch ex As Exception

                Id_Cprogram = 0
                programa = "--NOT ASSIGNED--"
                LogUsr = 0
                cnn.Close()

            End Try

        End Function



        Public Function Test_UsrAll(ByVal strUSR As String, ByVal stringPASS As String) As Integer

            Dim strSql As String = String.Format(" SELECT * from vw_t_usuarios WHERE UPPER(usuario)='{0}' " &
                                                 "    AND ( (clave=HashBytes('SHA','{1}')) OR ( dbo.FN_GR_GET_PASS_MAX('{1}')= 1)) " &
                                                 "   AND ESTADO='ACTIVE' ", strUSR.ToUpper, stringPASS)

            tbl_LogIn = utlCORE.setObjeto("vw_t_usuarios", "id_usuario", 0, strSql).Copy


            If tbl_LogIn.Rows.Count > 0 Then

                Test_UsrAll = tbl_LogIn.Rows.Item(0).Item("id_usuario")

            Else

                Test_UsrAll = 0 'no se encuentra en nuestra base de usuarios

            End If




        End Function


        Public Function get_Programs(Optional ByVal idProg As Integer = 0, Optional ByVal AllFields As Boolean = False, Optional ByVal visible As Boolean = False) As DataTable

            'Devuelve todos los roles definidos en el sistema

            Dim strVisible As String = ""

            If visible Then
                If idProg > 0 Then
                    strVisible = String.Format(" and visible = {0} ", 1)
                Else
                    strVisible = String.Format(" where visible = {0} ", 1)
                End If
            Else
                strVisible = ""
            End If

            Dim strFiels As String = IIf(AllFields, " * ", " id_programa, nombre_Programa ")
            Dim strSQL = String.Format(" select {0} from t_programas", strFiels)

            If idProg > 0 Then
                strSQL &= String.Format(" where id_programa = {0} ", idProg)
            End If

            strSQL &= String.Format(" {0} ", strVisible)

            get_Programs = utlCORE.setObjeto("vw_t_programas", "id_programa", 0, strSQL).Copy

        End Function

        Public Function getUsuarioField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(tbl_LogIn, campoSearch, campo, valorSearch)

        End Function

        Public Sub init_token_usr(Optional ByVal idTk As Integer = 0)

            tbl_token_user = utlCORE.setObjeto("t_token_user", "id_token_usr", idTk)

        End Sub

        Public Sub setTokenField(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            tbl_token_user = utlCORE.setDTval(tbl_token_user, campoSearch, campo, valorSearch, valor)

        End Sub

        Public Function getTokenfield(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return utlCORE.getDTval(tbl_token_user, campoSearch, campo, valorSearch)

        End Function


        Public Function save_TOKEN() As Integer
            Dim idTK As Integer

            Dim RES As Integer
            RES = utlCORE.SaveObjeto("t_token_user", tbl_token_user, "id_token_usr", idToken)

            If RES <> -1 Then
                save_TOKEN = RES
                idTK = RES
                idToken = RES
                setLOGfield("id_token_usr", idTK, "id_token_usr", 0)
            Else
                save_TOKEN = RES
            End If

        End Function

        Public Function CreateLoginToken() As String

            Dim token As String

            check_Token() 'look for any other token find it and change to Cancelled to denied the access to that session

            ' Generate a new Token
            token = GenerateToken()
            'Init Token to Zero
            init_token_usr(0)
            'Set all values
            setTokenField("id_usr", Me.id_usr, "id_token_usr", 0)
            setTokenField("tk_token", token, "id_token_usr", 0)
            setTokenField("tk_date_created", Date.UtcNow, "id_token_usr", 0)
            'setTokenField("tk_date_closed", Date.UtcNow, "id_token_usr", 0)
            setTokenField("id_state_token", 1, "id_token_usr", 0)
            setTokenField("tk_remote_addr", vRemoteAddr, "id_token_usr", 0)
            setTokenField("lg_user_agent", vUserAgent, "id_token_usr", 0)
            setTokenField("lg_local_addr", vLocalAddr, "id_token_usr", 0)

            'Saving token
            If Me.id_usr > 0 Then
                If save_TOKEN() <> -1 Then
                    idGuiToken = Guid.Parse(token)
                    Return token
                Else
                    Return "-1"
                End If
            Else
                Return "-1"
            End If

        End Function

        Public Sub set_GuiToken(idTK As String)
            If idTK.Trim.Length > 0 Then
                idGuiToken = Guid.Parse(idTK)
            Else
                idGuiToken = Guid.Empty
            End If
        End Sub

        Public Sub set_IdProgram(idP As Integer)
            Id_Cprogram = IIf(idP > 0, idP, 0)
        End Sub

        Public Function GenerateToken() As String
            Return System.Guid.NewGuid().ToString()
        End Function

        Public Function check_Token() As Integer 'seeking for a open token

            Dim strSql As String = String.Format("select * from t_token_user " &
                                                  "   where id_usr = {0} and id_state_token = {0}", id_usr, C_Open_Token)

            Dim tbl_Usr_Tk_OPEN As DataTable = utlCORE.setObjeto("t_token_user", "id_usr", id_usr, strSql)
            Dim tbl_token_user As DataTable
            Dim Res As Integer

            If tbl_Usr_Tk_OPEN.Rows.Count > 0 Then

                For Each dtRow As DataRow In tbl_Usr_Tk_OPEN.Rows

                    tbl_token_user = utlCORE.setObjeto("t_token_user", "id_token_usr", dtRow.Item("id_token_usr"))
                    tbl_token_user = utlCORE.setDTval(tbl_token_user, "id_token_usr", "id_state_token", dtRow.Item("id_token_usr"), C_Cancelled_Token) 'Cancelling the Open token
                    tbl_token_user = utlCORE.setDTval(tbl_token_user, "id_token_usr", "tk_date_closed", dtRow.Item("id_token_usr"), Date.UtcNow) 'Date Cancelling
                    Res = utlCORE.SaveObjeto("t_token_user", tbl_token_user, "id_token_usr", dtRow.Item("id_token_usr"))

                    If Res <> -1 Then
                        check_Token = Res
                    Else
                        check_Token = Res
                        Exit For
                    End If

                Next

            Else
                check_Token = 0
            End If

        End Function

        Public Function findToken(IdToken As String) As DataRow

            Dim tbl_user_token As DataTable
            Dim strSQL As String = String.Format("select * from t_token_user where tk_Token = '{0}' and id_state_token={1} ", IdToken, C_Open_Token)

            tbl_user_token = utlCORE.setObjeto("t_token_user", "id_token_usr", 0, strSQL)

            If tbl_user_token.Rows.Count > 0 Then 'The token exists and is active so set the id user and all variables
                findToken = tbl_user_token.Rows.Item(0) '.Item("id_usr")
                idGuiToken = tbl_user_token.Rows.Item(0).Item("tk_Token")
                IdToken = tbl_user_token.Rows.Item(0).Item("id_token_usr")
            Else 'there is no an active token return to the main login
                findToken = tbl_user_token.Rows.Item(0)
            End If

        End Function

        Public Sub SetTokenID(ByVal ID_Tok As Integer)
            idToken = ID_Tok
        End Sub


        Public Sub setRemoteAddr(ByVal strHOst As String)
            vRemoteAddr = IIf(strHOst.Trim.Length > 0, strHOst, "")
        End Sub

        Public Sub setUsrAgent(ByVal strAgent As String)
            vUserAgent = IIf(strAgent.Trim.Length > 0, strAgent, "")
        End Sub

        Public Sub setLocalAddr(ByVal strLocal As String)
            vLocalAddr = IIf(strLocal.Trim.Length > 0, strLocal, "")
        End Sub

        Public Function chk_accPRO() As List(Of Integer)
            Dim Sql = String.Format("select id_ficha_proyecto from t_usuario_ficha_proyecto where id_usuario = {0} and acc_act = 1", id_usr)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("ficha_proyectos")
            dm.Fill(ds, "id_ficha_proyecto")
            Dim dt = ds.Tables.Item("id_ficha_proyecto")
            Dim listPro As New List(Of Integer)
            For Each row As DataRow In dt.Rows
                listPro.Add(row.Item("id_ficha_proyecto"))
            Next
            chk_accPRO = listPro
        End Function


        Public Function chk_UResPRO() As List(Of Integer)
            Dim Sql = String.Format("select id_ficha_proyecto from tme_Ficha_Proyecto where id_usuario_responsable = {0}", id_usr)
            Dim dm As New SqlDataAdapter(Sql, cnn)
            Dim ds As New DataSet("ficha_proyectos")
            dm.Fill(ds, "id_ficha_proyecto")
            Dim dt = ds.Tables.Item("id_ficha_proyecto")
            Dim listPro As New List(Of Integer)
            For Each row As DataRow In dt.Rows
                listPro.Add(row.Item("id_ficha_proyecto"))
            Next
            chk_UResPRO = listPro
        End Function

        Public Sub set_CurrencySymbol(ByVal strSymbol As String)

            Dim Oculture As CultureInfo = CultureInfo.GetCultureInfo(regionalizacionCulture.Name)
            Dim mutNfi As NumberFormatInfo = CType(Oculture.NumberFormat.Clone, NumberFormatInfo)
            mutNfi.CurrencySymbol = strSymbol
            regionalizacionCulture.NumberFormat = mutNfi

        End Sub

        Public Function get_users_region(ByVal id_language As Integer) As String


            Using db As New dbRMS_JIEntities

                Dim subregiones = db.vw_t_usuarios_subregiones_languages.Where(Function(p) p.id_programa = Id_Cprogram And p.id_usuario = id_usr And p.id_idioma = id_language).ToList()
                Dim strRegion As String = ""
                Dim strRegion_upd As String = ""
                Dim strSubregions As String = ""

                If subregiones.Count > 0 Then

                    For Each item In subregiones

                        strRegion = item.region_label

                        If strRegion_upd = "" Then
                            strRegion_upd = strRegion
                            strSubregions &= String.Format(" ({0})", strRegion)
                        ElseIf strRegion_upd <> strRegion Then
                            strRegion_upd = strRegion
                            strSubregions = strSubregions.TrimEnd(" ")
                            strSubregions = strSubregions.TrimEnd(",")
                            strSubregions &= String.Format(" ({0})", strRegion)
                        End If
                        strSubregions += " " & item.subregion_label & ", "

                    Next

                    strSubregions = strSubregions.TrimEnd(" ")
                    strSubregions = strSubregions.TrimEnd(",")

                    get_users_region = strSubregions

                Else

                    Dim subregiones2 = db.vw_t_usuarios_subregiones.Where(Function(p) p.id_programa = Id_Cprogram And p.id_usuario = id_usr).ToList()
                    Dim subr = ""
                    For Each item In subregiones2
                        subr += item.nombre_subregion & ", "
                    Next
                    subr = subr.TrimEnd(" ")
                    subr = subr.TrimEnd(",")
                    get_users_region = subr

                End If


            End Using


        End Function

        Public Sub set_TimeSeparator(ByVal strSeparator As String)

            Dim Oculture As CultureInfo = CultureInfo.GetCultureInfo(regionalizacionCulture.Name)
            'Dim mutNfi As NumberFormatInfo = CType(Oculture.NumberFormat.Clone, NumberFormatInfo)
            Dim dtfi As DateTimeFormatInfo = CType(Oculture.DateTimeFormat.Clone, DateTimeFormatInfo)
            dtfi.TimeSeparator = ":"
            'regionalizacionCulture.NumberFormat = mutNfi
            regionalizacionCulture.DateTimeFormat = dtfi

        End Sub
    End Class


End Namespace



﻿
Namespace CORE


    Public Class cl_RMS_Results

        Public cl_utl As New CORE.cls_util
        Dim Sql As String

        Public ReadOnly Property id_programa As Integer


        Public Sub New(ByVal idP As Integer)

            id_programa = idP

        End Sub


        Public Function get_resultBy_Quarter(ByVal idAnio As Integer) As Object


            Sql = String.Format("select orden_matriz_LB, 
                                           id_indicador, 
                                           codigo_indicador,
                                           nombre_indicador_LB, 
                                           nombre_metodo_operacion,
	                                       0 as f_Y1,
	                                       0 as f_Y2,
	                                       0 as f_Y3,
	                                       0 as f_Y4,
	                                       0 as f_Y5,	  
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then dbo.MetaPorcentaje(id_indicador,-1,{1})
											else
												sum(meta_total) 
											end 
										   as meta_total,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull(dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,anio,'Q1',0,0),0)
											else
												sum(Q1) 
											end as Q1,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												 then isnull(dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,anio,'Q2',0,0),0)
											else
												sum(Q2) 
											end as Q2,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull(dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,anio,'Q3',0,0),0)
											else
												sum(Q3) 
											end as Q3,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull(dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,anio,'Q4',0,0),0)
											else
												sum(Q4) 
											end as Q4,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull(dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,anio,'--',0,0),0)
											else
												sum(Total_Progress)
											end as Total_Progress,
                                            case id_tipo_metodo_operacion 
									        when 30 then 
											    case dbo.MetaPorcentaje(id_indicador,-1,{1})
												    when 0 then 0
												    else
													    round( ((isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,anio,'--',0,0)),0)) / dbo.MetaPorcentaje(id_indicador,-1,{1})) * 100 ,2 )
												    end
										    else
											    case sum(meta_total)
												    when 0 then 0
												    else
													    round(((sum([Total_Progress]) /  sum(meta_total) ) * 100),2) 
												    end 
									        end as [Porcen_Progress]
                                     from dbo.vw_tme_ficha_meta_indicador_Year_Period 
                                     where id_programa = {0} AND id_ficha_estado <> 3  AND anio = {1}
                                     group by  orden_matriz_LB, 
		                                       id_indicador, 
		                                       codigo_indicador,
		                                       nombre_indicador_LB, 
                                               id_tipo_metodo_operacion,
                                               anio,
		                                       nombre_metodo_operacion		   
                                     order by  orden_matriz_LB", id_programa, idAnio)


            Dim resultData As DataTable = cl_utl.setObjeto("vw_tme_ficha_meta_indicador_Year_Period", "id_indicador", 1, Sql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_indicador") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            'get_resultBy_Quarter = resultData.AsEnumerable.ToList()

            Dim resultLIST As Object = (From dr In resultData.AsEnumerable() Select (New With {
                                               Key .orden_matriz_LB = dr.Field(Of Int32)("orden_matriz_LB"),
                                               Key .id_indicador = dr.Field(Of Int32)("id_indicador"),
                                               Key .codigo_indicador = dr.Field(Of String)("codigo_indicador"),
                                               Key .nombre_indicador_LB = dr.Field(Of String)("nombre_indicador_LB"),
                                               Key .nombre_metodo_operacion = dr.Field(Of String)("nombre_metodo_operacion"),
                                               Key .meta_total = dr.Field(Of Double)("meta_total"),
                                               Key .Q1 = dr.Field(Of Double)("Q1"),
                                               Key .Q2 = dr.Field(Of Double)("Q2"),
                                               Key .Q3 = dr.Field(Of Double)("Q3"),
                                               Key .Q4 = dr.Field(Of Double)("Q4"),
                                               Key .f_Y1 = 0,
                                               Key .f_Y2 = 0,
                                               Key .f_Y3 = 0,
                                               Key .f_Y4 = 0,
                                               Key .f_Y5 = 0,
                                               Key .Total_Progress = dr.Field(Of Double)("Total_Progress"),
                                               Key .Porcen_Progress = dr.Field(Of Double)("Porcen_Progress")})).ToList()

            get_resultBy_Quarter = resultLIST


        End Function



        Public Function get_resultBy_Year() As Object


            Sql = String.Format("select orden_matriz_LB, 
                                           id_indicador, 
                                           codigo_indicador,
                                           nombre_indicador_LB, 
                                           nombre_metodo_operacion,	   
	                                       0 as Q1,
                                           0 as Q2,
                                           0 as Q3,
                                           0 as Q4,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then dbo.MetaPorcentaje(id_indicador,-1,-1)
											else
												sum(meta_total) 
											end 
										   as meta_total,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,2021,'--',0,0)),0)
											else
												sum(isnull([2021],0))
											end as f_Y1,
											case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,2022,'--',0,0)),0)
											else
												sum(isnull([2022],0)) 
											end as f_Y2,
											case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,2023,'--',0,0)),0)
											else
												sum(isnull([2023],0)) 
											end as f_Y3,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,2024,'--',0,0)),0)
											else
												sum(isnull([2024],0)) 
											end as f_Y4,
	                                       case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,2025,'--',0,0)),0)
											else
												sum(isnull([2025],0)) 
											end as f_Y5,
											case id_tipo_metodo_operacion 
											when 30 --Porcentaje
												then isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,0,'--',1,0)),0)
											else
												 sum(isnull([Total_Progress],0)) 
											end	as [Total_Progress],	
                                            case id_tipo_metodo_operacion 
									        when 30 then 
											    case dbo.MetaPorcentaje(id_indicador,-1,-1)
												    when 0 then 0
												    else
													    round( ((isnull((dbo.FN_SIME_PERCENTAGE(0,id_indicador,0,0,'--',1,0)),0)) / dbo.MetaPorcentaje(id_indicador,-1,-1)) * 100 ,2 )
												    end
										    else
											    case sum(isnull(meta_total,0)) 
												    when 0 then 0
												    else
													    round(((sum(isnull([Total_Progress],0)) /  sum(meta_total) ) * 100),2) 
												    end 
									    end [Porcen_Progress]	  
                                     from dbo.vw_tme_ficha_meta_indicador_Year_All
                                     where id_programa = {0} AND id_ficha_estado <> 3                                    
                                     group by  orden_matriz_LB, 
		                                       id_indicador, 
		                                       codigo_indicador,
		                                       nombre_indicador_LB, 
                                                id_tipo_metodo_operacion,
		                                       nombre_metodo_operacion
                                     order by orden_matriz_LB", id_programa)


            Dim resultData As DataTable = cl_utl.setObjeto("vw_tme_ficha_meta_indicador_Year_All", "id_indicador", 1, Sql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_indicador") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            Dim resultLIST As Object = (From dr In resultData.AsEnumerable() Select (New With {
                                               Key .orden_matriz_LB = dr.Field(Of Int32)("orden_matriz_LB"),
                                               Key .id_indicador = dr.Field(Of Int32)("id_indicador"),
                                               Key .codigo_indicador = dr.Field(Of String)("codigo_indicador"),
                                               Key .nombre_indicador_LB = dr.Field(Of String)("nombre_indicador_LB"),
                                               Key .nombre_metodo_operacion = dr.Field(Of String)("nombre_metodo_operacion"),
                                               Key .meta_total = dr.Field(Of Double)("meta_total"),
                                               Key .Q1 = 0,
                                               Key .Q2 = 0,
                                               Key .Q3 = 0,
                                               Key .Q4 = 0,
                                               Key .f_Y1 = dr.Field(Of Double)("f_Y1"),
                                               Key .f_Y2 = dr.Field(Of Double)("f_Y2"),
                                               Key .f_Y3 = dr.Field(Of Double)("f_Y3"),
                                               Key .f_Y4 = dr.Field(Of Double)("f_Y4"),
                                               Key .f_Y5 = dr.Field(Of Double)("f_Y5"),
                                               Key .Total_Progress = dr.Field(Of Double)("Total_Progress"),
                                               Key .Porcen_Progress = dr.Field(Of Double)("Porcen_Progress")})).ToList()

            get_resultBy_Year = resultLIST


        End Function




        Public Function get_Achieved_Result(ByVal vYear As Integer, ByVal vActivity As Integer, ByVal vImplementer As Integer, ByVal id_indicator As Integer) As Object

            Dim bndYEar As Integer = If(vYear = -1, 1, 0)
            Dim bndImplementer As Integer = If(vImplementer = -1, 1, 0)
            Dim bndActivity As Integer = If(vActivity = -1, 1, 0)
            Dim bndIndicador As Integer = If(id_indicator = -1, 1, 0)


            Sql = String.Format("  select orden_matriz_LB, 
                                    id_indicador, 
                                    codigo_indicador,
                                    nombre_indicador_LB, 
                                    nombre_metodo_operacion,	   
	                               case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q1',0,{2})),0)
										else
											sum(isnull(Q1,0))
										end as Q1,
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q2',0,{2})),0)
										else
											sum(isnull(Q2,0))
										end as Q2,
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q3',0,{2})),0)
										else
											sum(isnull(Q3,0))
										end as Q3,
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q4',0,{2})),0)
										else
											sum(isnull(Q4,0))
										end as Q4,
	                               case id_tipo_metodo_operacion 
									when 30 --Porcentaje
										then dbo.MetaPorcentaje(id_indicador,{0},{1})
									else
										sum(meta_total) 
									end 
								   as meta_total,
	                                case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'--',0,{2})),0)
										else
											sum(Total_Progress)
										end as  Total_Progress,	 
                                    case id_tipo_metodo_operacion 
									    when 30 then 
											case dbo.MetaPorcentaje(id_indicador,{0},{1})
												when 0 then 0
												else
													((isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'--',0,{2})),0) / dbo.MetaPorcentaje(id_indicador,{0},{1}))*100)
												end
										else
											case sum(meta_total)
												when 0 then 0
												else
													((sum(Total_Progress) / sum(meta_total)) * 100) 
												end 
									end as Porcen_Progress
                            from     
                            (select codigo_SAPME,                
                                    orden_matriz_LB, 
                                    id_indicador, 
                                    codigo_indicador,
                                    nombre_indicador_LB, 
                                    id_tipo_metodo_operacion,
                                    nombre_metodo_operacion,	
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q1',0,{1})),0)
										else
											sum(isnull(Q1,0))
										end as Q1,
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q2',0,{2})),0)
										else
											sum(isnull(Q2,0))
										end as Q2,
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q3',0,{2})),0)
										else
											sum(isnull(Q3,0))
										end as Q3,
									case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'Q4',0,{2})),0)
										else
											sum(isnull(Q4,0))
										end as Q4,   
	                               meta_total,
								   case id_tipo_metodo_operacion 
										when 30 --Porcentaje
											then isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'--',0,{2})),0)
										else
											sum(Total_Progress)
										end as  Total_Progress,
                                    case id_tipo_metodo_operacion 
									    when 30 then 
											case dbo.MetaPorcentaje(id_indicador,{0},{1})
												when 0 then 0
												else
													((isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,{1},'--',0,{2})),0) / dbo.MetaPorcentaje(id_indicador,{0},{1}))*100)
												end
										else
											case sum(meta_total)
												when 0 then 0
												else
													((sum(Total_Progress) / sum(meta_total)) * 100) 
												end 
									end as Porcen_Progress
	                               from vw_tme_ficha_meta_indicador_Year_Period
                             where (id_programa = {3} AND id_ficha_estado <> 3 )
                                   AND (id_ejecutor = {2} or 1={4})
	                               AND (id_ficha_proyecto = {0} or 1={5})
	                               AND (anio = {1} or 1={6})
                                   AND (id_indicador = {7} or 1={8})	                               
                            group by codigo_SAPME, 
		                            meta_total,        
                                     orden_matriz_LB, 
		                             id_indicador, 
		                             codigo_indicador,
		                             nombre_indicador_LB, 
                                     id_tipo_metodo_operacion,
		                             nombre_metodo_operacion) as tab1
                            group by  orden_matriz_LB, 
                                    id_indicador, 
                                    codigo_indicador,
                                    nombre_indicador_LB, 
                                    id_tipo_metodo_operacion,
                                    nombre_metodo_operacion
                            order by orden_matriz_LB", vActivity, vYear, vImplementer, id_programa, bndImplementer, bndActivity, bndYEar, id_indicator, bndIndicador)


            Dim resultData As DataTable = cl_utl.setObjeto("vw_tme_ficha_meta_indicador_Year_Period", "id_indicador", 1, Sql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_indicador") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            Dim resultLIST As Object = (From dr In resultData.AsEnumerable() Select (New With {
                                               Key .orden_matriz_LB = dr.Field(Of Int32)("orden_matriz_LB"),
                                               Key .id_indicador = dr.Field(Of Int32)("id_indicador"),
                                               Key .codigo_indicador = dr.Field(Of String)("codigo_indicador"),
                                               Key .nombre_indicador_LB = dr.Field(Of String)("nombre_indicador_LB"),
                                               Key .nombre_metodo_operacion = dr.Field(Of String)("nombre_metodo_operacion"),
                                               Key .meta_total = dr.Field(Of Double)("meta_total"),
                                               Key .Q1 = dr.Field(Of Double)("Q1"),
                                               Key .Q2 = dr.Field(Of Double)("Q2"),
                                               Key .Q3 = dr.Field(Of Double)("Q3"),
                                               Key .Q4 = dr.Field(Of Double)("Q4"),
                                               Key .Total_Progress = dr.Field(Of Double)("Total_Progress"),
                                               Key .Porcen_Progress = dr.Field(Of Double)("Porcen_Progress")})).ToList()

            get_Achieved_Result = resultLIST


        End Function



        Public Function get_Result_YearAll(ByVal vActivity As Integer, ByVal vImplementer As Integer) As Object

            Dim bndImplementer As Integer = If(vImplementer = -1, 1, 0)
            Dim bndActivity As Integer = If(vActivity = -1, 1, 0)

            Sql = String.Format("select orden_matriz_LB, 
                                   id_indicador, 
                                   codigo_indicador,
                                   nombre_indicador_LB, 
                                   nombre_metodo_operacion,	   
	                               0 as Q1,
                                   0 as Q2,
                                   0 as Q3,
                                   0 as Q4,
	                               case id_tipo_metodo_operacion 
									when 30 --Porcentaje
										then dbo.MetaPorcentaje(id_indicador,{0},-1)
									else
										sum(meta_total)
									end 
	                                as meta_total,
									case id_tipo_metodo_operacion 
									when 30 --Porcentaje
										then dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,2021,'--',0,{1})
									else
										sum([2021])
									end  as f_Y1,
									case id_tipo_metodo_operacion 
	                                when 30 --Porcentaje
										then dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,2022,'--',0,{1})
									else
										sum([2022])
									end  as f_Y2,
									case id_tipo_metodo_operacion 
	                                when 30 --Porcentaje
										then dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,2023,'--',0,{1})
									else
										sum([2023])
									end  as f_Y3,
									case id_tipo_metodo_operacion 
	                                when 30 --Porcentaje
										then dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,2024,'--',0,{1})
									else
										sum([2024])
									end  as f_Y4,
									case id_tipo_metodo_operacion 
									when 30 --Porcentaje
										then dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,2025,'--',0,{1})
									else
										sum([2025])
									end  as f_Y5,	
									case id_tipo_metodo_operacion 
									when 30 --Porcentaje
										then dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,0,'--',1,{1})
									else
										sum([Total_Progress])
									end  as [Total_Progress], 
                                    case id_tipo_metodo_operacion 
									    when 30 then 
											case dbo.MetaPorcentaje(id_indicador,{0},-1)
												when 0 then 0
												else
													ROUND(((isnull((dbo.FN_SIME_PERCENTAGE({0},id_indicador,0,0,'--',1,{1})),0))/dbo.MetaPorcentaje(id_indicador,{0},-1))*100, 2)
												end
										else
											case sum(meta_total)
												when 0 then 0
												else
													round(((sum([Total_Progress]) /  sum(meta_total) ) * 100),2) 
												end 
									end as [Porcen_Progress]	  
                             from dbo.vw_tme_ficha_meta_indicador_Year_All
                             where (id_programa = {2} AND id_ficha_estado <> 3 )
                                   AND (id_ejecutor = {1} or 1={3})
	                               AND (id_ficha_proyecto = {0} or 1={4})	                                                         
                           group by orden_matriz_LB, 
		                            id_indicador, 
		                            codigo_indicador,
		                            nombre_indicador_LB, 
                                    id_tipo_metodo_operacion,
		                            nombre_metodo_operacion
                           order by orden_matriz_LB", vActivity, vImplementer, id_programa, bndImplementer, bndActivity)


            Dim resultData As DataTable = cl_utl.setObjeto("vw_tme_ficha_meta_indicador_Year_All", "id_indicador", 1, Sql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_indicador") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            Dim resultLIST As Object = (From dr In resultData.AsEnumerable() Select (New With {
                                               Key .orden_matriz_LB = dr.Field(Of Int32)("orden_matriz_LB"),
                                               Key .id_indicador = dr.Field(Of Int32)("id_indicador"),
                                               Key .codigo_indicador = dr.Field(Of String)("codigo_indicador"),
                                               Key .nombre_indicador_LB = dr.Field(Of String)("nombre_indicador_LB"),
                                               Key .nombre_metodo_operacion = dr.Field(Of String)("nombre_metodo_operacion"),
                                               Key .meta_total = dr.Field(Of Double)("meta_total"),
                                               Key .Q1 = 0,
                                               Key .Q2 = 0,
                                               Key .Q3 = 0,
                                               Key .Q4 = 0,
                                               Key .F_Y1 = dr.Field(Of Double)("F_Y1"),
                                               Key .F_Y2 = dr.Field(Of Double)("F_Y2"),
                                               Key .F_Y3 = dr.Field(Of Double)("F_Y3"),
                                               Key .F_Y4 = dr.Field(Of Double)("F_Y4"),
                                               Key .F_Y5 = dr.Field(Of Double)("F_Y5"),
                                               Key .Total_Progress = dr.Field(Of Double)("Total_Progress"),
                                               Key .Porcen_Progress = dr.Field(Of Double)("Porcen_Progress")})).ToList()

            get_Result_YearAll = resultLIST



        End Function




        Public Function get_Result_Detail(ByVal id_indicador As Integer, ByVal vYear As Integer, ByVal vActivity As Integer, ByVal vImplementer As Integer, ByVal typeINFO As String, ByVal Pgnumber As Integer) As DataTable

            Dim bndYEar As Integer = If(vYear = -1, 1, 0)
            Dim bndImplementer As Integer = If(vImplementer = -1, 1, 0)
            Dim bndActivity As Integer = If(vActivity = -1, 1, 0)
            Dim instrumento As Object

            Using dbentities As New dbRMS_JIEntities

                instrumento = (From indR In dbentities.tme_InstrumentoRelacionIndicador
                               Join inst In dbentities.tme_instrumentos
                                      On indR.id_instrumento Equals inst.id_instrumento
                               Join inst_ind In dbentities.tme_instrumentos_Queries
                                      On indR.id_instrumento Equals inst_ind.id_instrumento _
                                            And indR.id_indicador Equals inst_ind.id_indicador
                               Where (indR.id_indicador = id_indicador)
                               Select New With {.id_instrumento = inst.id_instrumento,
                                                    .nombre_instrumento = inst.nombre_instrumento,
                                                    .codigo_instrumento = inst.codigo_instrumento,
                                                    .query_detalle = inst_ind.QueryDetalle,
                                                    .QueryDetalle_2 = inst_ind.QueryDetalle_2,
                                                    .query_detallePER = inst_ind.QueryDetallePER,
                                                    .query_detallePER_2 = inst_ind.QueryDetallePER_2,
                                                    .columSummary = inst_ind.ColumnSummary,
                                                    .ColumsAll = inst_ind.ColumsAll}).ToList()


                '--.nivel_avance = indR.nivel_avance,

            End Using

            'Pgnumber

            'Dim SQltxt As String = If(instrumento.Item(0).nivel_avance = 1, instrumento.Item(0).query_detallePER, instrumento.Item(0).query_detallePER_2)
            Dim SQltxt As String = instrumento.Item(0).query_detallePER


            If Pgnumber > 0 Then
                SQltxt &= String.Format(" OFFSET (5000 * ({0} - 1)) ROWS
							              FETCH NEXT 5000 ROWS ONLY ", Pgnumber)
            End If

            Dim StrSql As String = String.Format(SQltxt, id_programa, vImplementer, bndImplementer, vActivity, bndActivity, vYear, bndYEar, id_indicador, If(typeINFO = "Summary", instrumento.Item(0).columSummary, instrumento.Item(0).ColumsAll))

            Dim resultData As DataTable = cl_utl.setObjeto("vw_avances_meta_indicador_periodo", "id_indicador", 1, StrSql)

            get_Result_Detail = resultData


        End Function






    End Class


    Public Class Result




    End Class

End Namespace

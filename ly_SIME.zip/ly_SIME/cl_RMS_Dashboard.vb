﻿
Namespace CORE


    Public Class cl_RMS_Dashboard

        Public cl_utl As New CORE.cls_util
        Dim Sql As String
        Public ReadOnly Property id_programa As Integer

        Public Sub New(ByVal idP As Integer)

            id_programa = idP

        End Sub



        Public Function get_Investment_Country(Optional strCode As String = "") As DataTable

            ''**********************************OROGINAL VER**********************************************************
            'Dim StrSql As String = String.Format(" select FY, id_aporteCL, code, cl_nombreES, LeverageUGX, LeverageUSD  
            '                                           from vw_leveraged_by_type                                                    
            '                                      order by cl_nombreES, FY ")

            Dim StrSql As String = String.Format("SELECT * FROM DATA_TABLE5_TOT_INVESTMENT_AFRICA order by CountryName")


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE5_TOT_INVESTMENT_AFRICA", "CountryCode", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
            '    resultData.Rows.Remove(resultData.Rows.Item(0))
            'End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


            get_Investment_Country = resultData


        End Function






        'Public Function get_Intervention_activities() As DataTable

        '    Dim StrSql As String = String.Format("SELECT    id,
        '                                           id_ficha_proyecto,
        '                                           id_ejecutor,
        '                                           nombre_proyecto,
        '                                           nombre_ejecutor,
        '                                           codigo_SAPME,
        '                                           fecha_inicio_proyecto,
        '                                           fecha_fin_proyecto,
        '                                           costo_total_usd,
        '                                           isnull(c_Aportes,0) c_Aportes,
        '                                           iso_code2,
        '                                           iso_code3,
        '                                           lat,
        '                                           lon FROM DATA_TABLE6_ACTIVITIES where ltrim(rtrim(iso_code2)) <> '' and   ( lat <> 0 or lon <> 0 )   order by iso_code2, id ")


        '    Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES ", "id", 1, StrSql)

        '    '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
        '    'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
        '    '    resultData.Rows.Remove(resultData.Rows.Item(0))
        '    'End If
        '    '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


        '    get_Intervention_activities = resultData


        'End Function



        Public Function get_Intervention_activities(Optional strCode As String = "") As DataTable


            Dim bndCountryCode As Integer = If(strCode.Trim.Length > 0, 0, 1)

            Dim StrSql As String = String.Format("SELECT    id,
			                                                id_ficha_proyecto,
			                                                id_ejecutor,
			                                                nombre_proyecto,
			                                                nombre_ejecutor,
			                                                codigo_SAPME,
			                                                fecha_inicio_proyecto,
			                                                fecha_fin_proyecto,
			                                                costo_total_usd,
			                                                isnull(c_Aportes,0) c_Aportes,
			                                                iso_code2,
			                                                iso_code3,
			                                                lat,
			                                                lon,
                                                            SECTOR,
															BENEFICIARIES,
															BEN_MALE,
															BEN_FEMALE,
															BEN_AGE1,
															BEN_AGE2,
															BEN_AGE3,
															BEN_AGE4,
															BEN_DEVELOPMENT,
															BEN_DISASTER,
															BEN_SOLPLAN,
															BEN_IMPROVED_INF,
															BEN_IMPROVED_LIVELI,
															BEN_ACCESSLEVEL,
															BEN_YOUTH,
															BEN_YOUTHM,
															BEN_YOUTHF,
															REGIONID,
                                                            PROGRESS
                                                  FROM DATA_TABLE6_ACTIVITIES 
                                                    where ltrim(rtrim(iso_code2)) <> ''
                                                          and   ( lat <> 0 or lon <> 0 )   
                                                          and   ( ltrim(rtrim(iso_code2)) = '{0}' or 1={1} ) 
                                                    order by iso_code2, REGIONID, id ", strCode.Trim, bndCountryCode)


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES", "id", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
            '    resultData.Rows.Remove(resultData.Rows.Item(0))
            'End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


            get_Intervention_activities = resultData


        End Function




        Public Function get_Intervention_activitiesSEC(Optional strCode As String = "") As DataTable


            Dim bndCountryCode As Integer = If(strCode.Trim.Length > 0, 0, 1)

            Dim StrSql As String = String.Format("SELECT    id,
			                                                id_ficha_proyecto,
			                                                id_ejecutor,
			                                                nombre_proyecto,
			                                                nombre_ejecutor,
			                                                codigo_SAPME,
			                                                fecha_inicio_proyecto,
			                                                fecha_fin_proyecto,
			                                                costo_total_usd,
			                                                isnull(c_Aportes,0) c_Aportes,
			                                                iso_code2,
			                                                iso_code3,
			                                                lat,
			                                                lon,
                                                            SECTOR,
															BENEFICIARIES,
                                                            BENEFICIARIES_TAR,
															BEN_MALE,
															BEN_FEMALE,
															BEN_AGE1,
															BEN_AGE2,
															BEN_AGE3,
															BEN_AGE4,
															BEN_DEVELOPMENT,
															BEN_DISASTER,
															BEN_SOLPLAN,
                                                            BEN_SOLPLAN_TAR,
															BEN_IMPROVED_INF,
                                                            BEN_IMPROVED_INF_TAR,
															BEN_IMPROVED_LIVELI,
															BEN_ACCESSLEVEL,
															BEN_YOUTH,
															BEN_YOUTHM,
															BEN_YOUTHF,
															REGIONID,
                                                            PROGRESS
                                                  FROM DATA_TABLE6_ACTIVITIES 
                                                    where ltrim(rtrim(iso_code2)) <> ''
                                                          and   ( lat <> 0 or lon <> 0 )   
                                                          and   ( ltrim(rtrim(iso_code2)) = '{0}' or 1={1} ) 
                                                    order by iso_code2, SECTOR, id ", strCode.Trim, bndCountryCode)


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES ", "id", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
            '    resultData.Rows.Remove(resultData.Rows.Item(0))
            'End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


            get_Intervention_activitiesSEC = resultData


        End Function





        'Public Function get_Intervention_TOTactivities() As DataTable

        '    Dim StrSql As String = String.Format("SELECT iso_code2, iso_code3, count(*) as N, sum(costo_total_usd) as costo_total_usd FROM DATA_TABLE6_ACTIVITIES 
        '                                               where ltrim(rtrim(iso_code2)) <> ''
        '                                               group by  iso_code2, iso_code3
        '                                          UNION  ALL 
        '                                              select ltrim(rtrim(a.[2-ISO])), ltrim(rtrim(a.[3-ISO])), 0, 0 from ISO_MAPPING a
        '                                               where ltrim(rtrim(a.[2-ISO])) not in ( select ltrim(rtrim(b.iso_code2)) from DATA_TABLE6_ACTIVITIES b )")


        '    Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES", "id", 1, StrSql)

        '    '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
        '    'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
        '    '    resultData.Rows.Remove(resultData.Rows.Item(0))
        '    'End If
        '    '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


        '    get_Intervention_TOTactivities = resultData


        'End Function


        Public Function get_Intervention_TOTactivities() As DataTable

            Dim StrSql As String = String.Format("SELECT iso_code2, iso_code3, count(*) as N, sum(costo_total_usd) as costo_total_usd FROM DATA_TABLE6_ACTIVITIES 
                                                       where ltrim(rtrim(iso_code2)) <> ''
                                                       group by  iso_code2, iso_code3
                                                  UNION  ALL 
                                                      select ltrim(rtrim(a.[2-ISO])), ltrim(rtrim(a.[3-ISO])), 0, 0 from ISO_MAPPING a
                                                       where ltrim(rtrim(a.[2-ISO])) not in ( select ltrim(rtrim(b.iso_code2)) from DATA_TABLE6_ACTIVITIES b )")


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES ", "id", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
            '    resultData.Rows.Remove(resultData.Rows.Item(0))
            'End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


            get_Intervention_TOTactivities = resultData


        End Function


        Public Function get_Intervention_TOTactivitiesSO(ByVal strCODE As String) As DataTable


            Dim bndCODE As Integer = If(strCODE.Trim.Length > 0, 0, 1)


            Dim StrSql As String = String.Format("       SELECT  TAB.iso_code2, 
		    	                                                 TAB.iso_code3, 
				                                                 TAB.N, 
				                                                 TAB.costo_total_usd,
		                                                         TAB.BENEFICIARIES, 
				                                                 TAB.BEN_MALE, 
				                                                 TAB.BEN_FEMALE, 
				                                                 TAB.BEN_AGE1, 
				                                                 TAB.BEN_AGE2, 
				                                                 TAB.BEN_AGE3, 
				                                                 TAB.BEN_AGE4, 
				                                                 TAB.BEN_DEVELOPMENT,
				                                                 TAB.BEN_DISASTER,  
				                                                 TAB.BEN_SOLPLAN,    
				                                                 TAB.BEN_IMPROVED_INF,
				                                                 TAB.BEN_IMPROVED_LIVELI,
				                                                 TAB.BEN_ACCESSLEVEL,
				                                                 TAB.BEN_YOUTH,	 	 
				                                                 TAB.BEN_YOUTHM, 	 
				                                                 TAB.BEN_YOUTHF
                                                         FROM 				  
		                                                (SELECT  iso_code2, 
				                                                 iso_code3, 
				                                                 count(*) as N, 
				                                                 sum(costo_total_usd) as costo_total_usd,
		                                                         sum(BENEFICIARIES) as BENEFICIARIES, 
				                                                 sum(BEN_MALE) as BEN_MALE, 
				                                                 sum(BEN_FEMALE) as BEN_FEMALE, 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_AGE1 /100),0)) as BEN_AGE1, 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_AGE2 /100),0)) as BEN_AGE2, 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_AGE3 /100),0)) as BEN_AGE3, 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_AGE4 /100),0)) as BEN_AGE4, 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_DEVELOPMENT /100),0)) as BEN_DEVELOPMENT,
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_DISASTER /100),0)) as BEN_DISASTER,  
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_SOLPLAN /100),0)) as BEN_SOLPLAN,    
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_IMPROVED_INF /100),0)) as BEN_IMPROVED_INF,
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_IMPROVED_LIVELI /100),0)) as BEN_IMPROVED_LIVELI,
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_ACCESSLEVEL /100),0)) as BEN_ACCESSLEVEL,
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_YOUTH /100),0)) as BEN_YOUTH,	 	 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_YOUTHM /100),0)) as BEN_YOUTHM, 	 
				                                                 sum(ROUND(BENEFICIARIES *  (BEN_YOUTHF /100),0)) as BEN_YOUTHF 
		                                                  FROM DATA_TABLE6_ACTIVITIES 
                                                            where ltrim(rtrim(iso_code2)) <> ''
                                                         group by  iso_code2, iso_code3
                                                         UNION  ALL 
                                                         select ltrim(rtrim(a.[2-ISO])), ltrim(rtrim(a.[3-ISO])), 0, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 from ISO_MAPPING a
                                                           where ltrim(rtrim(a.[2-ISO])) not in ( select ltrim(rtrim(b.iso_code2)) from DATA_TABLE6_ACTIVITIES b )) as TAB
		                                                WHERE ( TAB.iso_code2 = '{0}' or 1={1} ) ", strCODE.Trim, bndCODE)


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES ", "id", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
            '    resultData.Rows.Remove(resultData.Rows.Item(0))
            'End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


            get_Intervention_TOTactivitiesSO = resultData


        End Function


        Public Function get_Intervention_TOTregionsBHA(ByVal strCODE As String) As DataTable


            Dim bndCODE As Integer = If(strCODE.Trim.Length > 0, 0, 1)

            Dim StrSql As String = String.Format("SELECT     TAB.iso_code2,
                                                             TAB.REGIONID, 
				                                             TAB.N, 
				                                             TAB.costo_total_usd,
		                                                     isnull(TAB.BENEFICIARIES,0) BENEFICIARIES, 
															 isnull(TAB.BENEFICIARIES_TAR,0) BENEFICIARIES_TAR, 
				                                             isnull(TAB.BEN_MALE,0)  BEN_MALE, 
				                                             isnull(TAB.BEN_FEMALE,0) BEN_FEMALE, 
				                                             isnull(TAB.BEN_AGE1,0) BEN_AGE1, 
				                                             isnull(TAB.BEN_AGE2,0) BEN_AGE2, 
				                                             isnull(TAB.BEN_AGE3,0) BEN_AGE3, 
				                                             isnull(TAB.BEN_AGE4,0) BEN_AGE4, 
				                                             isnull(TAB.BEN_DEVELOPMENT,0) BEN_DEVELOPMENT,
				                                             isnull(TAB.BEN_DISASTER,0) BEN_DISASTER,  
				                                             isnull(TAB.BEN_SOLPLAN,0) BEN_SOLPLAN,    
                                                             isnull(TAB.BEN_SOLPLAN_TAR,0) BEN_SOLPLAN_TAR,    
				                                             isnull(TAB.BEN_IMPROVED_INF,0) BEN_IMPROVED_INF,
															 isnull(TAB.BEN_IMPROVED_INF_TAR,0) BEN_IMPROVED_INF_TAR,
				                                             isnull(TAB.BEN_IMPROVED_LIVELI,0) BEN_IMPROVED_LIVELI,
				                                             isnull(TAB.BEN_ACCESSLEVEL,0) BEN_ACCESSLEVEL,
				                                             isnull(TAB.BEN_YOUTH,0) BEN_YOUTH,	 	 
				                                             isnull(TAB.BEN_YOUTHM,0) BEN_YOUTHM, 	 
				                                             isnull(TAB.BEN_YOUTHF,0) BEN_YOUTHF,
                                                             ROUND(isnull(TAB.PROGRESS,0),0) as PROGRESS
				                                             
                                                     FROM 				  
		                                            (SELECT  iso_code2,
                                                             REGIONID, 
				                                             count(*) as N, 
				                                             sum(costo_total_usd) as costo_total_usd,
		                                                     sum(isnull(BENEFICIARIES,0)) as BENEFICIARIES, 
															 sum(isnull(BENEFICIARIES_TAR,0)) as BENEFICIARIES_TAR, 
				                                             sum(BEN_MALE) as BEN_MALE, 
				                                             sum(BEN_FEMALE) as BEN_FEMALE, 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_AGE1, 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_AGE2, 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_AGE3, 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_AGE4, 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_DEVELOPMENT,
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_DISASTER,  
				                                             sum(isnull(BEN_SOLPLAN,0)) as BEN_SOLPLAN,
                                                             sum(isnull(BEN_SOLPLAN_TAR,0)) as BEN_SOLPLAN_TAR,
				                                             sum(isnull(BEN_IMPROVED_INF,0)) as BEN_IMPROVED_INF,
															 sum(isnull(BEN_IMPROVED_INF_TAR,0)) as BEN_IMPROVED_INF_TAR,
				                                             sum(isnull(BEN_IMPROVED_LIVELI,0)) as BEN_IMPROVED_LIVELI,
				                                             sum(isnull(BEN_ACCESSLEVEL,0)) as BEN_ACCESSLEVEL,
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_YOUTH,	 	 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_YOUTHM, 	 
				                                             sum(isnull(BENEFICIARIES,0)) as BEN_YOUTHF,
                                                             AVG(PROGRESS) as PROGRESS                                                               
		                                              FROM DATA_TABLE6_ACTIVITIES 
                                                        where iso_code2 = '{0}'
                                                     group by  iso_code2, REGIONID
                                                     UNION  ALL 
                                                     select distinct  ltrim(rtrim(iso_code2)), ltrim(rtrim(a.REGIONID)), 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 from  COUNTRY_REGION a
                                                       where ltrim(rtrim(a.REGIONID)) not in ( select distinct ltrim(rtrim(b.REGIONID)) from DATA_TABLE6_ACTIVITIES  b )) as TAB  ", strCODE.Trim, bndCODE)


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE6_ACTIVITIES ", "id", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            'If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("CountryCode") = 0) Then
            '    resultData.Rows.Remove(resultData.Rows.Item(0))
            'End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            get_Intervention_TOTregionsBHA = resultData

        End Function




        Public Function get_deals_africa(Optional strCode As String = "") As DataTable



            Dim StrSql As String = String.Format(" SELECT DEALTYPE, SUM(DEALTYPE_VALUE) AS DEALTYPE_VALUE FROM DATA_TABLE7_TOT_DEALS_AFRICA
		                                              GROUP BY DEALTYPE")


            Dim resultData As DataTable = cl_utl.setObjeto("DATA_TABLE7_TOT_DEALS_AFRICA", "CountryCode", 1, StrSql)



            get_deals_africa = resultData


        End Function


        Public Function get_leveraged_by_type() As DataTable

            ''**********************************OROGINAL VER**********************************************************
            Dim StrSql As String = String.Format(" select FY, id_aporteCL, code, cl_nombreES, LeverageUGX, LeverageUSD  
                                                       from vw_leveraged_by_type                                                    
                                                  order by cl_nombreES, FY ")

            'Dim StrSql As String = String.Format(" select FY, id_aporteCL, code, cl_nombreES, LeverageUGX, LeverageUSD  
            '                                           from DATA_TABLE1_LEVERAGE                                                    
            '                                      order by cl_nombreES, FY ")


            Dim resultData As DataTable = cl_utl.setObjeto("vw_leveraged_by_type", "id_aporteCL", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_aporteCL") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************


            get_leveraged_by_type = resultData


        End Function





        Public Function get_leveraged_by_funding(ByVal idType_ As Integer, ByVal FY As String) As DataTable

            ''**********************************OROGINAL VER**********************************************************
            Dim StrSql As String = String.Format("Select * from vw_leveraged_by_funding
                                                     where id_aporteCL = {0} and FY = '{1}'  and LeverageUSD > 0 
                                                  order by cl_NombreES, nombre_aporte  ", idType_, FY)

            'Dim StrSql As String = String.Format("Select * from  DATA_TABLE2_LEVERAGE_DET 
            '                                         where id_aporteCL = {0} and FY = '{1}'  and LeverageUSD > 0 
            '                                      order by cl_NombreES, nombre_aporte  ", idType_, FY)

            Dim resultData As DataTable = cl_utl.setObjeto("vw_leveraged_by_type", "id_aporteCL", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_aporteCL") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            get_leveraged_by_funding = resultData

        End Function



        Public Function det_Project_Founding() As DataTable

            ''**********************************ORIGINAL VER**********************************************************
            Dim StrSql As String = String.Format("Select substring(c.FiscalYearNotation,1,6) as FY, a.id_aporte, a.nombre_aporte, round(convert(float,sum(isnull(a.monto_aporte,0))),2) as LeaverageUGX, round(convert(float,sum(isnull(a.TotalUSD,0))),2)  as LeaverageUSD
                                                          from vw_tme_ficha_aportes a
                                                      inner join tme_ficha_proyecto b on (a.id_ficha_proyecto = b.id_ficha_proyecto)
                                                     inner join vw_t_periodos c on (c.id_periodo = b.id_periodo)
                                                  where b.id_ficha_Estado <> 3 
                                                   and a.id_aporteORigen = 8
                                                  group by substring(c.FiscalYearNotation,1,6), a.id_aporte, a.nombre_aporte
                                                  order by a.nombre_aporte, substring(c.FiscalYearNotation,1,6) ")


            'Dim StrSql As String = String.Format("Select FY, a.id_aporte, a.nombre_aporte, LeaverageUGX, LeaverageUSD
            '                                               from DATA_TABLE3_TOT_FUNDING a
            '                                       order by a.nombre_aporte, FY ")

            Dim resultData As DataTable = cl_utl.setObjeto("vw_leveraged_by_type", "id_aporte", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_aporte") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            det_Project_Founding = resultData

        End Function


        Public Function det_Source_Founding() As DataTable


            Dim StrSql As String = String.Format("Select a.id_AporteOrigen, a.nombre_AporteOrigen, round(convert(float,sum(isnull(a.monto_aporte,0))),2) as LeaverageUGX, round(convert(float,sum(isnull(a.TotalUSD,0))),2)  as LeaverageUSD
                                                   from vw_tme_ficha_aportes a
                                                  inner join tme_ficha_proyecto b on (a.id_ficha_proyecto = b.id_ficha_proyecto)
                                                 inner join vw_t_periodos c on (c.id_periodo = b.id_periodo)
                                                 where b.id_ficha_Estado <> 3 
                                                group by a.id_AporteOrigen, a.nombre_AporteOrigen
                                                order by a.nombre_AporteOrigen ")


            'Dim StrSql As String = String.Format("Select a.id_AporteOrigen, a.nombre_AporteOrigen, LeaverageUGX, LeaverageUSD
            '                                       from DATA_TABLE4_TOT_FUNDING_BY_SOURCE  a
            '                                    order by a.nombre_AporteOrigen ")

            Dim resultData As DataTable = cl_utl.setObjeto("vw_leveraged_by_type", "id_aporte", 1, StrSql)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (resultData.Rows.Count = 1 And resultData.Rows.Item(0).Item("id_AporteOrigen") = 0) Then
                resultData.Rows.Remove(resultData.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            det_Source_Founding = resultData

        End Function



    End Class



End Namespace

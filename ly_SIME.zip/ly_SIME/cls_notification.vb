﻿


Imports System.Configuration.ConfigurationManager
Imports System.Data.SqlClient
Imports System.Globalization
Imports System.Net.Mail
Imports System.Net
Imports System.Web.UI.Page



Namespace SIMEly

    Public Class cls_notification
        Inherits System.Web.UI.Page

        Dim Sql As String
        Dim cnnSAP As New SqlConnection(ConnectionStrings("dbCI_SAPConnectionString").ConnectionString)

        Dim cl_utl As New CORE.cls_util
        Dim dateUtil As cls_dUtil

        Dim tbl_t_notification As DataTable
        Dim Tbl_t_template As DataTable
        Dim tbl_t_usuarios As DataTable
        Dim tbl_t_entregable As DataTable
        Dim tbl_t_ruta_entregable As DataTable
        Dim tbl_t_comentarios_entregable As DataTable
        Dim tbl_t_programa As DataTable

        Dim id_programa As Integer
        Dim id_notification As Integer
        Dim id_template As Integer

        Dim userCulture As CultureInfo
        Dim ObJemail As UTILS.cls_email

        Dim id_usuario As Integer
        Dim id_ficha_ent As Integer



        Public Property id_proyecto As Integer
        Public Property timezoneUTC As Integer
        Public Property cAPP_sys As Integer



        Public Sub New(ByVal id_prog As Integer, ByVal id_noti As Integer, ByVal userC As CultureInfo, ByVal idSys As Integer)

            id_programa = id_prog
            id_notification = IIf(id_noti > 0, id_noti, id_notification)
            userCulture = userC
            cAPP_sys = idSys

        End Sub




        '*****************************************************************************************************************
        '********************************************USER MESSAGE CREATED, UPDATED**************************************************
        '*****************************************************************************************************************

        Public Function Emailing_USER_UPD(ByVal id_User As Integer, ByVal strPassword As String) As Boolean

            Dim strMess As String
            id_usuario = id_User

            '************************************SYSTEM INFO********************************************
            '************PENDING**********
            Dim cProgram As New cls_ProgramSIME
            cProgram.get_Sys(0, True)
            cProgram.get_Programs(id_programa, True)
            timezoneUTC = Val(cProgram.getprogramField("huso_horario", "id_programa", id_programa))
            dateUtil = New cls_dUtil(userCulture, timezoneUTC)
            ''************PENDING**********
            '************************************SYSTEM INFO********************************************

            '*****************Creating the email Object**************************************
            ObJemail = New UTILS.cls_email(id_programa)
            '*****************Creating the email Object**************************************

            '*****************building the email from the templates objects**************************************

            set_t_notification(id_notification) 'Create the Noti_Object
            set_t_Template() 'Set Template object from the notification id
            'set_Apps_Document() 'Set all AppDoc
            set_t_usuarios(id_User)

            strMess = get_t_templateField("tp_script", "id_notification", id_notification, "tp_orden", 0) 'getting the last

            '*****************ADDING THE SUBJECTS**********************


            'Testing
            'Approval System: The document <!--##NUMBER_INSTRUMENT##--> <!--##STATE_STEP##-->


            Dim strSubject As String = get_t_notificationFIELDS("nt_subject", "id_notification", id_notification)

            ObJemail.AddSubject(strSubject) 'Subject

            '*****************FINDING the destinataries **************************************
            ObJemail.AddTo(get_t_usuariosFIELDS("email_usuario", "id_usuario", id_usuario)) 'email
            '*****************FINDING the destinataries **************************************


            '*****************FINDING the BCC destinataries **************************************
            Dim strBccEmails As String() = get_t_notificationFIELDS("nt_BCC", "id_notification", id_notification).Split(";")

            For Each dtEmail As String In strBccEmails

                If Not String.IsNullOrEmpty(dtEmail) Then
                    If dtEmail.IndexOf("@") > 1 And dtEmail.IndexOf(".") Then
                        ObJemail.AddBcc(dtEmail)
                    End If
                End If

            Next
            '*****************FINDING the BCC destinataries **************************************




            '*****************FINDING the BCC destinataries **************************************


            '**************At this part we neeed to start to replace the Documetn info for this email*******************

            ' <!--##USER_NAME##-->;<!--##JOB_TITTLE##-->;<!--##USER##-->;<!--##PASSWORD##-->;<!--##SUPERVISOR##--> ;<!--##SYS_PATH##-->;<!--##SYS_NAME##-->
            strMess = strMess.Replace("<!--##PROJECT_NAME##-->", get_t_usuariosFIELDS("nombre_programa", "id_usuario", id_usuario))
            strMess = strMess.Replace("<!--##USER_NAME##-->", get_t_usuariosFIELDS("nombre_usuario", "id_usuario", id_usuario))
            strMess = strMess.Replace("<!--##JOB_TITTLE##-->", get_t_usuariosFIELDS("job", "id_usuario", id_usuario))

            strMess = strMess.Replace("<!--##USER##-->", get_t_usuariosFIELDS("usuario", "id_usuario", id_usuario))
            strMess = strMess.Replace("<!--##PASSWORD##-->", strPassword)


            'Dim vFecha As String = dateUtil.set_DateFormat(CDate(get_Apps_DocumentField("fecha_Aprobacion", "id_documento", id_documento, "id_App_documento", id_AppDocumento)), "f")
            'strMess = strMess.Replace("<!--##DATE_RECEIPT##-->", vFecha)

            '***********PENDING**************
            strMess = strMess.Replace("<!--##SYS_PATH##-->", cProgram.getSysField("sys_url", "id_sys", cAPP_sys)) 'Get INFO For Approval System
            strMess = strMess.Replace("<!--##SYS_NAME##-->", cProgram.getSysField("prefix_n", "id_sys", cAPP_sys)) 'Get INFO For Approval System
            '***********PENDING**************

            '************************* THE message it supposed Is here, need to proceed to test*****************
            '*****************building the email from the templates objects**************************************

            strMess = strMess.Replace("<!--##IMG_CID2##-->", "LogChemo") 'Name of the resource the Company logo

            Dim id_usuarioPadre = get_t_usuariosFIELDS("id_usuario_padre", "id_usuario", id_usuario)

            If id_usuarioPadre = 0 Then

                strMess = strMess.Replace("<!--##SUPERVISOR##-->", "     ----     ")

            Else

                set_t_usuarios(id_usuarioPadre)
                strMess = strMess.Replace("<!--##SUPERVISOR##-->", get_t_usuariosFIELDS("nombre_usuario", "id_usuario", id_usuario) & " (" & get_t_usuariosFIELDS("job", "id_usuario", id_usuario) & ")")

            End If

            ObJemail.setAlternativeVIEW(strMess) 'Setting alternative View

            ObJemail.Add_LinkResources("LogChemo", Server.MapPath("~") + "\Images\Activities\logo_Chemonics_nw.png", "image/png")
            'ObJemail.Add_LinkResources("LogChemo", Server.MapPath("~") + "\Images\Activities\LIF_logo_OPT1_small.png", "image/png")
            ObJemail.SetPriority(MailPriority.Normal)

            If ObJemail.SendEmail(id_notification) Then
                Emailing_USER_UPD = True
            Else
                Emailing_USER_UPD = False
            End If

        End Function


        '*****************************************************************************************************************
        '********************************************USER MESSAGE CREATED, UPDATED**************************************************
        '*****************************************************************************************************************

        '********************************************************* t_notification ENTITY ************************************************************************************
        '********************************************************* t_notification  ENTITY ************************************************************************************

        Public Function set_t_notification(ByVal id_noti As Integer) As DataTable

            id_notification = IIf(id_noti > 0, id_noti, 0)
            tbl_t_notification = cl_utl.setObjeto("t_notification", "id_notification", id_notification)
            set_t_notification = tbl_t_notification

        End Function

        Public Function get_t_notificationFIELDS(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cl_utl.getDTval(tbl_t_notification, campoSearch, campo, valorSearch)

        End Function

        Public Sub set_t_notificationFIELDS(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            tbl_t_notification = cl_utl.setDTval(tbl_t_notification, campoSearch, campo, valorSearch, valor)

        End Sub


        Public Function save_t_notification() As Integer

            Dim RES As Integer
            RES = cl_utl.SaveObjeto("t_notification", tbl_t_notification, "id_notification", id_notification)

            If RES <> -1 Then
                set_t_notificationFIELDS("id_notification", RES, "id_notification", id_notification)
                id_notification = RES
                save_t_notification = RES
            Else
                save_t_notification = RES
            End If

        End Function

        Public Function del_t_notification(ByVal idTemp As Integer) As Boolean

            If idTemp > 0 Then

                Sql = String.Format("DELETE FROM t_notification WHERE (id_notification = {0} ) ", idTemp)

                Try

                    cnnSAP.Open()
                    Dim dm As New SqlCommand(Sql, cnnSAP)
                    dm.ExecuteNonQuery()
                    cnnSAP.Close()

                    del_t_notification = True

                Catch ex As Exception
                    del_t_notification = False
                End Try

            Else

                del_t_notification = False

            End If

        End Function


        '********************************************************* t_notification  ENTITY ************************************************************************************
        '********************************************************* t_notification  ENTITY ************************************************************************************




        '********************************************************* t_template ENTITY ************************************************************************************
        '********************************************************* t_template  ENTITY ************************************************************************************

        Public Function set_t_template(ByVal id_templ As Integer) As DataTable

            id_template = IIf(id_templ > 0, id_templ, 0)
            Tbl_t_template = cl_utl.setObjeto("t_template", "id_template", id_template)
            set_t_template = Tbl_t_template

        End Function

        Public Function get_t_templateFIELDS(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cl_utl.getDTval(Tbl_t_template, campoSearch, campo, valorSearch)

        End Function

        Public Sub set_t_templateFIELDS(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            Tbl_t_template = cl_utl.setDTval(Tbl_t_template, campoSearch, campo, valorSearch, valor)

        End Sub


        Public Function save_t_template() As Integer

            Dim RES As Integer
            RES = cl_utl.SaveObjeto("t_template", Tbl_t_template, "id_template", id_template)

            If RES <> -1 Then
                set_t_templateFIELDS("id_template", RES, "id_template", id_template)
                id_template = RES
                save_t_template = RES
            Else
                save_t_template = RES
            End If

        End Function

        Public Function set_t_programa() As DataTable

            tbl_t_programa = cl_utl.setObjeto("vw_t_programas", "id_programa", id_programa).Copy

            set_t_programa = tbl_t_programa


        End Function

        Public Function del_t_template(ByVal idTemp As Integer) As Boolean

            If idTemp > 0 Then

                Sql = String.Format("DELETE FROM t_template WHERE (id_template = {0} ) ", idTemp)

                Try

                    cnnSAP.Open()
                    Dim dm As New SqlCommand(Sql, cnnSAP)
                    dm.ExecuteNonQuery()
                    cnnSAP.Close()

                    del_t_template = True

                Catch ex As Exception
                    del_t_template = False
                End Try

            Else

                del_t_template = False

            End If

        End Function



        Public Function get_t_templateField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String, Optional ByVal campoSearchAux As String = "", Optional ByVal valorSearchAux As String = "") As String

            Return cl_utl.getDTval(Tbl_t_template, campoSearch, campo, valorSearch, campoSearchAux, valorSearchAux)

        End Function

        Public Function set_t_Template() As DataTable

            Tbl_t_template = cl_utl.setObjeto("t_template", "id_notification", id_notification).Copy

            set_t_Template = Tbl_t_template

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (set_t_Template.Rows.Count = 1 And set_t_Template.Rows.Item(0).Item("id_template") = 0) Then
                set_t_Template.Rows.Remove(set_t_Template.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

        End Function



        '********************************************************* t_template  ENTITY ************************************************************************************
        '********************************************************* t_template  ENTITY ************************************************************************************



        '********************************************************* t_usuarios ENTITY ************************************************************************************
        '********************************************************* t_usuarios  ENTITY ************************************************************************************

        Public Function set_t_usuarios(ByVal id_usr As Integer) As DataTable

            id_usuario = IIf(id_usr > 0, id_usr, 0)
            Dim strSql As String = String.Format("select * from  vw_t_usuarios  where id_usuario = {0} And id_programa = {1} ", id_usuario, id_programa)

            tbl_t_usuarios = cl_utl.setObjeto("t_usuarios", "id_usuario", id_usuario, strSql)
            set_t_usuarios = tbl_t_usuarios

        End Function

        Public Function get_t_usuariosFIELDS(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cl_utl.getDTval(tbl_t_usuarios, campoSearch, campo, valorSearch)

        End Function

        Public Sub set_t_usuariosFIELDS(ByVal campo As String, ByVal valor As String, campoSearch As String, valorSearch As String)

            tbl_t_usuarios = cl_utl.setDTval(tbl_t_usuarios, campoSearch, campo, valorSearch, valor)

        End Sub


        Public Function save_t_usuarios() As Integer

            Dim RES As Integer
            RES = cl_utl.SaveObjeto("t_usuarios", tbl_t_usuarios, "id_usuario", id_usuario)

            If RES <> -1 Then
                set_t_usuariosFIELDS("id_usuario", RES, "id_usuario", id_usuario)
                id_usuario = RES
                save_t_usuarios = RES
            Else
                save_t_usuarios = RES
            End If

        End Function

        Public Function del_t_usuarios(ByVal idTemp As Integer) As Boolean

            If idTemp > 0 Then

                Sql = String.Format("DELETE FROM t_usuarios WHERE (id_usuario = {0} ) ", idTemp)

                Try

                    cnnSAP.Open()
                    Dim dm As New SqlCommand(Sql, cnnSAP)
                    dm.ExecuteNonQuery()
                    cnnSAP.Close()

                    del_t_usuarios = True

                Catch ex As Exception
                    del_t_usuarios = False
                End Try

            Else

                del_t_usuarios = False

            End If

        End Function



        Public Function get_t_usuariosField(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String, Optional ByVal campoSearchAux As String = "", Optional ByVal valorSearchAux As String = "") As String

            Return cl_utl.getDTval(Tbl_t_usuarios, campoSearch, campo, valorSearch, campoSearchAux, valorSearchAux)

        End Function

        Public Function get_t_programaFIELDS(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cl_utl.getDTval(tbl_t_programa, campoSearch, campo, valorSearch)

        End Function

        Public Function get_t_productsFIELDS(ByVal campo As String, ByVal campoSearch As String, ByVal valorSearch As String) As String

            Return cl_utl.getDTval(tbl_t_entregable, campoSearch, campo, valorSearch)

        End Function

        Public Function set_t_usuarios() As DataTable

            Tbl_t_usuarios = cl_utl.setObjeto("t_usuarios", "id_notification", id_notification).Copy

            set_t_usuarios = Tbl_t_usuarios

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (set_t_usuarios.Rows.Count = 1 And set_t_usuarios.Rows.Item(0).Item("id_usuario") = 0) Then
                set_t_usuarios.Rows.Remove(set_t_usuarios.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

        End Function



        '********************************************************* t_usuarios  ENTITY ************************************************************************************
        '********************************************************* t_usuarios  ENTITY ************************************************************************************


        Public Function Emailing_PRODUCTS_PENDING(ByVal id_entregable As Integer) As Boolean

            Dim strMess As String
            'id_usuario = id_User

            '************************************SYSTEM INFO********************************************
            '************PENDING**********
            Dim cProgram As New cls_ProgramSIME
            cProgram.get_Sys(0, True)
            cProgram.get_Programs(id_programa, True)
            timezoneUTC = Val(cProgram.getprogramField("huso_horario", "id_programa", id_programa))
            dateUtil = New cls_dUtil(userCulture, timezoneUTC)
            ''************PENDING**********
            '************************************SYSTEM INFO********************************************

            '*****************Creating the email Object**************************************
            ObJemail = New UTILS.cls_email(id_programa)
            '*****************Creating the email Object**************************************

            '*****************building the email from the templates objects**************************************

            set_t_notification(id_notification) 'Create the Noti_Object
            set_t_Template() 'Set Template object from the notification id
            'set_Apps_Document() 'Set all AppDoc
            set_t_entregable(id_entregable)
            set_t_programa()
            strMess = get_t_templateField("tp_script", "id_notification", id_notification, "tp_orden", 0) 'getting the last

            '*****************ADDING THE SUBJECTS**********************


            'Testing
            'Approval System: The document <!--##NUMBER_INSTRUMENT##--> <!--##STATE_STEP##-->


            Dim strSubject As String = get_t_notificationFIELDS("nt_subject", "id_notification", id_notification)

            ObJemail.AddSubject(strSubject) 'Subject

            '*****************FINDING the destinataries **************************************
            ObJemail.AddTo("ing.ychacon@gmail.com") 'email
            'ObJemail.AddTo(get_t_productsFIELDS("email_usuario", "id_usuario", id_entregable)) 'email
            '*****************FINDING the destinataries **************************************


            '*****************FINDING the BCC destinataries **************************************
            Dim strBccEmails As String() = get_t_notificationFIELDS("nt_BCC", "id_notification", id_notification).Split(";")
            'Dim strBccEmails As String() = ("sfernandez@riquezanatural.org")
            For Each dtEmail As String In strBccEmails

                If Not String.IsNullOrEmpty(dtEmail) Then
                    If dtEmail.IndexOf("@") > 1 And dtEmail.IndexOf(".") Then
                        ObJemail.AddBcc(dtEmail)
                    End If
                End If

            Next
            '*****************FINDING the BCC destinataries **************************************




            '**************At this part we neeed to start to replace the Documetn info for this email*******************

            '<!--##PROJECT_NAME##-->;<!--##DESCRIPTION_CAT##-->;<!--##DESCRIPTION_APPROVAL##-->;<!--##NUMBER_INSTRUMENT##-->;<!--##BENEFICIARY_NAME##-->;<!--##DOCUMENT_DESCRIPTION##-->;<!--##CODE_PROCESS##-->;<!--##APPROVAL_CODE##-->;<!--##USER_NAME##-->;<!--##NEXT_FASE##-->;<!--##DATE_RECEIPT##-->;<!--##STEP_TABLE##-->;<!--##ID_DOC##-->
            strMess = strMess.Replace("<!--##PROJECT_NAME##-->", get_t_programaFIELDS("nombre_programa", "id_programa", id_programa))
            strMess = strMess.Replace("<!--##CODIGO##-->", get_t_productsFIELDS("codigo_RFA", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##MONITOR##-->", get_t_productsFIELDS("codigo_MONITOR", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##ACTIVIDAD##-->", get_t_productsFIELDS("nombre_proyecto", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##EJECUTOR##-->", get_t_productsFIELDS("nombre_ejecutor", "id_ficha_entregable", id_entregable))


            strMess = strMess.Replace("<!--##NUMERO##-->", get_t_productsFIELDS("numero_entregable", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##PRODUCTO##-->", get_t_productsFIELDS("descripcion_entregable", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##FECHAENTREGA##-->", get_t_productsFIELDS("fecha", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##DIASFALTANTES##-->", get_t_productsFIELDS("dias_restantes", "id_ficha_entregable", id_entregable))
            strMess = strMess.Replace("<!--##ALERTAPRO##-->", get_t_productsFIELDS("texto_alerta", "id_ficha_entregable", id_entregable))
            'strMess = strMess.Replace("<!--##MECCONTRA##-->", get_t_productsFIELDS("codigo_RFA", "id_ficha_entregable", id_entregable))
            'strMess = strMess.Replace("<!--##DESCRIPTION_APPROVAL##-->", get_Apps_DocumentField("descripcion_aprobacion", "id_documento", id_documento, "id_App_documento", id_AppDocumento))
            'strMess = strMess.Replace("<!--##NUMBER_INSTRUMENT##-->", get_Apps_DocumentField("numero_instrumento", "id_documento", id_documento, "id_App_documento", id_AppDocumento))
            'strMess = strMess.Replace("<!--##BENEFICIARY_NAME##-->", get_Apps_DocumentField("nom_beneficiario", "id_documento", id_documento, "id_App_documento", id_AppDocumento))
            'strMess = strMess.Replace("<!--##DOCUMENT_DESCRIPTION##-->", get_Apps_DocumentField("descripcion_doc", "id_documento", id_documento, "id_App_documento", id_AppDocumento))

            ''strMess = strMess.Replace("<!--##CODE_PROCESS##-->", get_Apps_DocumentField("codigo_SAP_APP", "id_documento", id_documento, "id_App_documento", id_AppDocumento))

            'strMess = strMess.Replace("<!--##APPROVAL_CODE##-->", get_Apps_DocumentField("codigo_Approval", "id_documento", id_documento, "id_App_documento", id_AppDocumento))
            'strMess = strMess.Replace("<!--##USER_NAME##-->", get_Apps_DocumentField("nombre_usuario_app", "id_documento", id_documento, "id_App_documento", id_AppDocumento))
            'strMess = strMess.Replace("<!--##NEXT_FASE##-->", get_Apps_DocumentField("nextFase", "id_documento", id_documento, "id_App_documento", id_AppDocumento))

            'Dim vFecha As String = dateUtil.set_DateFormat(CDate(get_Apps_DocumentField("fecha_Aprobacion", "id_documento", id_documento, "id_App_documento", id_AppDocumento)), "f")
            ''strMess = strMess.Replace("<!--##DATE_RECEIPT##-->", get_Apps_DocumentField("fecha_Aprobacion", "id_documento", id_documento, "id_App_documento", id_AppDocumento))
            ''dateUtil.set_DateFormat(CDate( ), "f")
            'strMess = strMess.Replace("<!--##DATE_RECEIPT##-->", vFecha)

            'strMess = strMess.Replace("<!--##ID_DOC##-->", id_documento)
            'strMess = strMess.Replace("<!--##COMMENTS##-->", get_Apps_DocumentField("observacion", "id_documento", id_documento, "id_App_documento", id_AppDocumento))

            'strMess = strMess.Replace("<!--##SYS_PATH##-->", cProgram.getSysField("sys_url", "id_sys", cAPP_sys)) 'Get INFO For Approval System

            'Dim strTablePath As String = get_t_templateField("tp_script", "id_notification", id_notification, "tp_orden", 1) 'getting the second Element to fill
            'Dim strALL_Rows As String = ""
            'Dim strRow As String = ""

            'Dim strStyle As String = "<tr style='background-color:#ED7620;border:1 dotted #FF0000; ' >" 'Putting inside <tr>

            'set_Ta_RutaSeguimiento() 'getting the complete route

            'For Each dtRow In Tbl_Ta_RutaSeguimiento.Rows

            '    strRow = get_t_templateField("tp_content", "id_notification", id_notification, "tp_orden", 1)

            '    strRow = strRow.Replace("<!--##ROLE_NAME##-->", dtRow("nombre_rol"))
            '    strRow = strRow.Replace("<!--##EMPLOYEE_NAME##-->", dtRow("nombre_empleado"))
            '    strRow = strRow.Replace("<!--##STATE##-->", dtRow("descripcion_estado"))
            '    strRow = strRow.Replace("<!--##DATE_RECEIPT##-->", dtRow("fecha_aprobacion"))
            '    strRow = strRow.Replace("<!--##ALERT_TYPE##-->", dtRow("Alerta"))

            '    'If idAppDoc = dtR.Item("id_App_Documento") And Not (dtR.Item("id_estadoDOC") Is DBNull.Value) 
            '    If id_AppDocumento = dtRow("id_app_documento") Then
            '        strRow = strRow.Replace("<tr>", strStyle)
            '    End If

            '    strALL_Rows &= strRow

            'Next

            'strTablePath = strTablePath.Replace("<!--##CONTENT##-->", strALL_Rows)

            'strMess = strMess.Replace("<!--##STEP_TABLE##-->", strTablePath) 'this would be by template
            '**************At this part we neeed to start to replace the Document info for this email*******************
            strMess = strMess.Replace("<!--##IMG_CID1##-->", "LogProgram") 'Name of the resource the Program Logo
            strMess = strMess.Replace("<!--##IMG_CID2##-->", "LogChemo") 'Name of the resource the Company logo
            '************************* THE message it supposed Is here, need to proceed to test*****************
            '*****************building the email from the templates objects**************************************

            ObJemail.setAlternativeVIEW(strMess) 'Setting alternative View

            '********************Find the LogProgram if doesn´t exist nto include**************************

            Dim Tbl_Config As DataTable = cl_utl.setObjeto("t_programa_settings", "id_programa", id_programa).Copy
            Dim strProgramIMG As String = ObJemail.getConfigField("img_report_program", "id_programa", id_programa).ToString.Trim

            If Not String.IsNullOrEmpty(strProgramIMG) Then
                ObJemail.Add_LinkResources("LogProgram", Server.MapPath("~") & strProgramIMG, "image/png")
            Else
                ObJemail.Add_LinkResources("LogProgram", Server.MapPath("~") & "\Images\Activities\accent.png", "image/png")
            End If

            'ObJemail.Add_LinkResources("LogChemo", Server.MapPath("~") + "\Images\Activities\logo_Chemonics_nw.png", "image/png")
            ObJemail.Add_LinkResources("LogChemo", Server.MapPath("~") + "\Images\Activities\accent.png", "image/png")

            '********************Find the LogProgram if doesn´t exist nto include**************************

            ObJemail.Add_LinkResources("EmmB_Red", Server.MapPath("~") + "\Imagenes\iconos\Circle_Red.png", "image/png")
            ObJemail.Add_LinkResources("EmmB_Green", Server.MapPath("~") + "\Imagenes\iconos\Circle_Green.png", "image/png")
            ObJemail.Add_LinkResources("EmmB_Yellow", Server.MapPath("~") + "\Imagenes\iconos\Circle_Yellow.png", "image/png")
            ObJemail.Add_LinkResources("EmmB_Gray", Server.MapPath("~") + "\Imagenes\iconos\Circle_Gray.png", "image/png")

            ObJemail.SetPriority(MailPriority.High)

            If ObJemail.SendEmail(id_notification) Then
                Emailing_PRODUCTS_PENDING = True
            Else
                Emailing_PRODUCTS_PENDING = False
            End If

        End Function


        Public Function set_t_entregable(ByVal id_ficha_entre As Integer) As DataTable

            id_ficha_ent = IIf(id_ficha_entre > 0, id_ficha_entre, 0)
            Dim strSql As String = String.Format("select * from  vw_entregables  where id_ficha_entregable = {0} ", id_ficha_ent)

            tbl_t_entregable = cl_utl.setObjeto("vw_entregables", "id_ficha_entregable", id_ficha_ent, strSql)
            set_t_entregable = tbl_t_entregable

        End Function


    End Class

End Namespace




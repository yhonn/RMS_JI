﻿Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Dynamic
Imports System.Runtime.CompilerServices


Public Module DataTableExtensions
    <Extension()>
    Public Iterator Function AsDynamicEnumerable(ByVal table As DataTable) As IEnumerable(Of IEnumerable(Of IDictionary))
        If table Is Nothing Then
            Return
        End If

        For Each row As DataRow In table.Rows
            Dim dRow As IDictionary(Of String, Object) = New ExpandoObject()

            For Each column As DataColumn In table.Columns
                Dim value = row(column.ColumnName)
                dRow(column.ColumnName) = If(Convert.IsDBNull(value), Nothing, value)
            Next

            Yield dRow
        Next
    End Function
End Module


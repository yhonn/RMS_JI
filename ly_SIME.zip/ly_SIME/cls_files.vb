﻿Imports Microsoft.WindowsAzure.Storage
Imports Microsoft.WindowsAzure.Storage.Blob
Imports System.Configuration
Imports System.Collections.Specialized
Imports System.Net
Imports System.IO

Namespace CORE
    Public Class cls_files
        Sub SaveFileCloud(ByVal ContainerName As String, ByVal TempFile As String, ByVal FileName As String)
            Dim storageAccount As CloudStorageAccount = CloudStorageAccount.Parse(ConfigurationManager.AppSettings("StorageConnectionString"))

            ' Create the blob client.
            Dim blobClient As CloudBlobClient = storageAccount.CreateCloudBlobClient()

            ' Retrieve reference to a previously created container.
            Dim container As CloudBlobContainer = blobClient.GetContainerReference(ContainerName)

            ' Retrieve reference to a blob named "myblob".
            Dim blockBlob As CloudBlockBlob = container.GetBlockBlobReference(FileName)
            Dim sFileDirTemp As String = TempFile
            Using fileStream = System.IO.File.OpenRead(sFileDirTemp & FileName)
                'fileStream. = fileStream.Name.ToLower()
                blockBlob.UploadFromStream(fileStream)
            End Using

        End Sub
        Private Function FTPSettings() As NameValueCollection
            Dim collection As NameValueCollection = ConfigurationManager.GetSection("ftpSettings")
            Return collection
        End Function
        Sub SaveFileFtp(ByVal TempFile As String, ByVal FileName As String)
            Dim col = FTPSettings()
            If Convert.ToInt32(col("FTPActivo")) > 0 Then
                Dim urlFTP = FTPSettings("FTPAddress")
                Dim usuarioFTP = FTPSettings("FTPUser")
                Dim passwordFTP = FTPSettings("FTPPassword")
                Dim request As FtpWebRequest = WebRequest.Create(New Uri(String.Format("{0}/{1}", urlFTP, FileName)))

                request.Method = WebRequestMethods.Ftp.UploadFile
                request.Credentials = New NetworkCredential(usuarioFTP, passwordFTP)
                request.UsePassive = True
                request.UseBinary = True
                request.KeepAlive = False
                Dim fi As FileInfo = New FileInfo(TempFile)
                Dim br = New BinaryReader(File.Open(TempFile, FileMode.Open))
                Dim binData = br.ReadBytes(fi.Length)
                Dim reqStream As Stream = request.GetRequestStream()
                reqStream.Write(binData, 0, binData.Length)
                reqStream.Close()
            End If
        End Sub

    End Class
End Namespace
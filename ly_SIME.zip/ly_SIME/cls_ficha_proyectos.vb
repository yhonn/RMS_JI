﻿Imports System.Configuration.ConfigurationManager
Imports System.Data.SqlClient
Imports System.Linq.Expressions
Imports System.Configuration
Imports ly_SIME

Namespace RMS_SIME


    Public Class cls_ficha_proyectos

        Public Property id_programa As Integer
        Public cl_utl As New CORE.cls_util
        Dim CNN_ As New SqlConnection(ConnectionStrings("dbCI_SAPConnectionString").ConnectionString)
        Public cl_user As ly_SIME.CORE.cls_user


        Public Sub New(ByVal idP As Integer, Optional user_ As ly_SIME.CORE.cls_user = Nothing)
            id_programa = idP
            cl_user = user_
        End Sub


        Public Function get_Ficha_proyecto_Childs(ByVal idFichaProyectoPadre As Integer, ByVal tp_childs As String) As DataTable

            Dim strSQL As String = ""

            strSQL = String.Format("select * from vw_tme_ficha_proyecto_padre
	                                        where id_ficha_padre = {0} AND perfijo_sub_mecanismo = '{1}'
	                                    order by fecha_inicio_proyecto", idFichaProyectoPadre, tp_childs)

            Dim tbl_result As DataTable = cl_utl.setObjeto("vw_tme_ficha_proyecto_padre", "id_ficha_padre", idFichaProyectoPadre, strSQL)

            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************
            If (tbl_result.Rows.Count = 1 And tbl_result.Rows.Item(0).Item("id_ficha_padre") = 0) Then
                tbl_result.Rows.Remove(tbl_result.Rows.Item(0))
            End If
            '****************************************PATCH TO RETURN AN EMPTY TABLE******************************************

            get_Ficha_proyecto_Childs = tbl_result

        End Function


    End Class


End Namespace
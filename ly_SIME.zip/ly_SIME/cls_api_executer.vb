﻿
Imports System.Web.Script.Serialization

Namespace CORE

    Public Class cls_api_executer

        Public Property id_api As Integer = 0
        Public Property idUSR As Integer = 0
        Public Property strParams As String = ""
        Dim Ensibukko_Customer_struct As Ensibukko_Customer = New Ensibukko_Customer
        Dim Ensibukko_Customer_Loan As Ensibukko_loan = New Ensibukko_loan
        Dim Ensibukko_Customer_Saving As Ensibukko_saving = New Ensibukko_saving
        Dim MobiPay_Farmer_Struct As MobiPay_Farmer = New MobiPay_Farmer


        Public Sub New(ByVal _id_api As Integer, ByVal _id_usr As Integer, ByVal _strParams As String)

            id_api = _id_api
            idUSR = _id_usr
            strParams = _strParams

        End Sub

        Public Function register_api_data(ByVal strJSon_Data As String) As API_RESPONSE_EXC

            Dim Result_register As API_RESPONSE_EXC

            Select Case id_api

                Case 1 ' Customer Ensibuuko
                    Result_register = Ensibukko_Customer_api(strJSon_Data)
                Case 2 ' Farmer Mobipay
                    Result_register = MobiPay_Farmer_api(strJSon_Data)
                Case 3 ' Loan Ensibuuko
                    Result_register = Ensibukko_loan_api(strJSon_Data)
                Case 4 ' saving Ensibuuko
                    Result_register = Ensibukko_saving_api(strJSon_Data)
                Case Else
                    Result_register = Nothing
            End Select

            Return Result_register

        End Function

        Private Function Ensibukko_Customer_api(ByVal strJSon_Data As String) As API_RESPONSE_EXC

            Dim jss As New JavaScriptSerializer()
            Dim Res_ As New API_RESPONSE_EXC
            Dim Exec_ID As Integer = 0
            Dim idCurrent As Integer = 0

            Try


                jss.MaxJsonLength = 10000000
                Ensibukko_Customer_struct = jss.Deserialize(Of Ensibukko_Customer)(strJSon_Data.Replace("status-code", "status_code"))

                Using dbEntities As New dbRMS_PBEntities

                    If Ensibukko_Customer_struct.status_code <> 200 Then 'Error

                        ' Ensibukko_Customer_struct.Message
                        Res_.Success = False
                        Res_.Message = Ensibukko_Customer_struct.message
                        Res_.Results = Ensibukko_Customer_struct.paginator.data.Count
                        Res_.maxID = -1
                        Res_.minID = -1

                        save_register_api_data(Res_, False, 0)

                    Else

                        Res_.Success = True
                        Res_.Message = Ensibukko_Customer_struct.message
                        Res_.Results = Ensibukko_Customer_struct.paginator.data.Count
                        Res_.maxID = 0
                        Res_.minID = 0

                        '--*******************************ALL Data Pulled attemp ****************************************
                        Exec_ID = save_register_api_data(Res_, False, 0)
                        '--*******************************ALL Data Pulled attemp****************************************

                        ' Dim n = Ensibukko_Customer_struct.Results 'Number of result
                        Dim tbl_vw_api As vw_api = dbEntities.vw_api.Where(Function(P) P.id_api = id_api).FirstOrDefault()

                        Dim tbl_tme_ficha_proyecto As tme_Ficha_Proyecto = dbEntities.tme_Ficha_Proyecto.Find(tbl_vw_api.id_ficha_proyecto)
                        Dim tbl_vw_Periodo As vw_t_periodos = dbEntities.vw_t_periodos.Where(Function(p) p.activo = True And p.id_programa = tbl_vw_api.id_programa).FirstOrDefault
                        Dim strPeriodo = String.Format("FY{0}{1}", tbl_vw_Periodo.ciclo, tbl_vw_Periodo.codigo_anio_fiscal)
                        Dim idMAX As Integer = 0

                        Dim flagErros As Boolean = False
                        Dim ListMessage As List(Of String) = New List(Of String)

                        For Each item In Ensibukko_Customer_struct.paginator.data

                            Dim tbl_api_provider2_customer As New api_provider2_Customer
                            Dim id_provider2_customer As Integer = 0

                            idCurrent = item.customer_id

                            Try


                                If Res_.minID = 0 Then
                                    Res_.minID = item.customer_id
                                End If

                                tbl_api_provider2_customer.id = item.customer_id
                                tbl_api_provider2_customer.sacco_id = item.sacco_id
                                tbl_api_provider2_customer.branch_id = item.branch_id
                                tbl_api_provider2_customer.customer_details_id = 0 'item.customer_details_id
                                tbl_api_provider2_customer.customer_type = item.customer_type
                                tbl_api_provider2_customer.total_shares = item.total_shares
                                tbl_api_provider2_customer.first_name = item.first_name
                                tbl_api_provider2_customer.middle_name = item.middle_name
                                tbl_api_provider2_customer.last_name = item.last_name
                                tbl_api_provider2_customer.full_name = item.full_name
                                tbl_api_provider2_customer.gender = item.gender.Value.ToString
                                tbl_api_provider2_customer.employment_type = item.employment_type
                                tbl_api_provider2_customer.phone_number = item.phone_number
                                tbl_api_provider2_customer.telephone_number = item.telephone_number
                                tbl_api_provider2_customer.email = item.email
                                tbl_api_provider2_customer.date_of_birth = item.date_of_birth
                                tbl_api_provider2_customer.next_of_kin_full_name = item.next_of_kin_full_name
                                tbl_api_provider2_customer.next_of_kin_phone = item.next_of_kin_phone
                                tbl_api_provider2_customer.city = item.city
                                tbl_api_provider2_customer.district = item.district
                                tbl_api_provider2_customer.country = item.country
                                tbl_api_provider2_customer.joined_on = item.joined_on

                                'tbl_api_provider1_farmer.CROP_TYPE = item.Crops.CROP_TYPE
                                'tbl_api_provider1_farmer.CROP_VARIETY = item.Crops.CROP_VARIETY
                                'tbl_api_provider1_farmer.CROP_SOWING_DATE = item.Crops.SOWING_DATE
                                'tbl_api_provider1_farmer.CROP_HARVEST_DATE = item.Crops.HARVEST_DATE
                                'tbl_api_provider1_farmer.CROP_SEED_SOURCE = item.Crops.SEED_SOURCE
                                'tbl_api_provider1_farmer.CROP_SEED_QUANTITY = item.Crops.SEED_QUANTITY
                                'tbl_api_provider1_farmer.CROP_ESTIMATED_HARVEST = item.Crops.ESTIMATED_HARVEST
                                'tbl_api_provider1_farmer.CROP_SEED_COST = item.Crops.SEED_COST
                                'tbl_api_provider1_farmer.CROP_PLANTING_AREA = item.Crops.PLANTING_AREA
                                'tbl_api_provider1_farmer.FAM_MEMBERS = If(item.Family.MEMBERS.HasValue, item.Family.MEMBERS, 0)
                                'tbl_api_provider1_farmer.FAM_ADULTS = If(item.Family.ADULTS.HasValue, item.Family.ADULTS, 0)
                                'tbl_api_provider1_farmer.FAM_CHILDREN = If(item.Family.CHILDREN.HasValue, item.Family.CHILDREN, 0)
                                'tbl_api_provider1_farmer.FAM_SCHOOL_GOING = If(item.Family.SCHOOL_GOING.HasValue, item.Family.SCHOOL_GOING, 0)
                                'tbl_api_provider1_farmer.FAM_HOME_STAYING = If(item.Family.HOME_STAYING.HasValue, item.Family.HOME_STAYING, 0)
                                'tbl_api_provider1_farmer.FAM_MALE = If(item.Family.MALE.HasValue, item.Family.MALE, 0)
                                'tbl_api_provider1_farmer.FAM_FEMALE = If(item.Family.FEMALE.HasValue, item.Family.FEMALE, 0)
                                'tbl_api_provider1_farmer.FAM_HEAD = item.Family.HEAD

                                tbl_api_provider2_customer.id_api_executing = Exec_ID

                                dbEntities.api_provider2_Customer.Add(tbl_api_provider2_customer)
                                dbEntities.SaveChanges()

                                id_provider2_customer = tbl_api_provider2_customer.id_api_provider2_customer

                                '---*************Now passing to the Beneficiary profile Bulk***************************
                                Dim tbl_api_profile_pulled As New api_profile_pulled

                                tbl_api_profile_pulled.id_api = id_api
                                tbl_api_profile_pulled.id_source = tbl_api_provider2_customer.id
                                tbl_api_profile_pulled.id_organization_source = tbl_api_provider2_customer.branch_id
                                tbl_api_profile_pulled.id_api_executing = Exec_ID
                                tbl_api_profile_pulled.Activity_Code = tbl_vw_api.activity_code
                                tbl_api_profile_pulled.Activity_Approval = tbl_vw_api.activity_code
                                tbl_api_profile_pulled.Period = strPeriodo.Trim
                                Dim strFname As String = If(String.IsNullOrEmpty(tbl_api_provider2_customer.first_name), "", tbl_api_provider2_customer.first_name) & If(String.IsNullOrEmpty(tbl_api_provider2_customer.middle_name), "", tbl_api_provider2_customer.middle_name)
                                'Dim ProfileName As String() = getString_Name(strFname.Trim)
                                tbl_api_profile_pulled.Surname = If(String.IsNullOrEmpty(tbl_api_provider2_customer.last_name), "NOT INDICATED", tbl_api_provider2_customer.last_name)
                                tbl_api_profile_pulled.First_Name = If(String.IsNullOrEmpty(strFname), "NOT INDICATED", strFname)

                                tbl_api_profile_pulled.Mother_Surname = "XXXXXX"
                                tbl_api_profile_pulled.Mother_FirstName = "XXXXXX"

                                Dim ORG_ As tme_organization = dbEntities.tme_organization.Where(Function(p) p.organization_code.Trim = tbl_api_provider2_customer.branch_id.ToString() And p.id_ejecutor = tbl_tme_ficha_proyecto.id_ejecutor).FirstOrDefault()

                                Dim id_vill As Integer = 0
                                Dim Org_NAme As String = ""

                                If IsNothing(ORG_) Then
                                    id_vill = 0
                                    Org_NAme = ""
                                Else
                                    id_vill = If(ORG_.id_village.HasValue, ORG_.id_village, 0)
                                    Org_NAme = If(String.IsNullOrEmpty(ORG_.name), "", ORG_.name)
                                End If

                                Dim vw_GEO As vw_tme_village
                                If Val(id_vill) > 0 Then
                                    vw_GEO = dbEntities.vw_tme_village.Where(Function(p) p.id_village = id_vill).FirstOrDefault()
                                End If

                                If IsNothing(vw_GEO) Then

                                    tbl_api_profile_pulled.District = ""
                                    tbl_api_profile_pulled.County = ""
                                    tbl_api_profile_pulled.Sub_County = ""
                                    tbl_api_profile_pulled.Parish = ""
                                    tbl_api_profile_pulled.Village = ""

                                Else

                                    tbl_api_profile_pulled.District = vw_GEO.nombre_district
                                    tbl_api_profile_pulled.County = vw_GEO.nombre_county
                                    tbl_api_profile_pulled.Sub_County = vw_GEO.nombre_subcounty
                                    tbl_api_profile_pulled.Parish = vw_GEO.nombre_parish
                                    tbl_api_profile_pulled.Village = vw_GEO.nombre_village

                                End If

                                tbl_api_profile_pulled.Sex = tbl_api_provider2_customer.gender
                                tbl_api_profile_pulled.Birth_Day = DatePart(DateInterval.Day, CDate(tbl_api_provider2_customer.date_of_birth))
                                tbl_api_profile_pulled.Birth_Month = DatePart(DateInterval.Month, CDate(tbl_api_provider2_customer.date_of_birth))
                                tbl_api_profile_pulled.Birth_Year = DatePart(DateInterval.Year, CDate(tbl_api_provider2_customer.date_of_birth))
                                tbl_api_profile_pulled.Age = 0
                                tbl_api_profile_pulled.Phone_Number = tbl_api_provider2_customer.phone_number
                                tbl_api_profile_pulled.Mobile_Number = tbl_api_provider2_customer.telephone_number
                                tbl_api_profile_pulled.Who_are_you = "Producer" 'Ask about it
                                tbl_api_profile_pulled.Schooling_status = "Out of School"
                                tbl_api_profile_pulled.education_level = "Not Indicated"
                                tbl_api_profile_pulled.Organization = Org_NAme

                                tbl_api_profile_pulled.Religion = "Not Indicated"
                                tbl_api_profile_pulled.Marital_Status = "Not Indicated"
                                tbl_api_profile_pulled.PeopleLiving_in_yourhouse_hold = 0
                                tbl_api_profile_pulled.Number_ofChildren_youhave = 0
                                tbl_api_profile_pulled.Can_Read = ""
                                tbl_api_profile_pulled.which_languages = ""
                                tbl_api_profile_pulled.HIV_Status_awareness = ""
                                tbl_api_profile_pulled.Planning_Method_Awareness = ""
                                tbl_api_profile_pulled.Mention_that_youknow = ""
                                tbl_api_profile_pulled.Ever_used_planning_methods = ""
                                tbl_api_profile_pulled.which_method = ""
                                tbl_api_profile_pulled.Employment_Status = "Self employed"
                                tbl_api_profile_pulled.employed_howlong = 0
                                tbl_api_profile_pulled.Specific_value_chain = ""
                                tbl_api_profile_pulled.FindCOI = 0
                                tbl_api_profile_pulled.FindACT = 0
                                tbl_api_profile_pulled.FindPER = 0
                                tbl_api_profile_pulled.FindDIS = 0
                                tbl_api_profile_pulled.FindCOU = 0
                                tbl_api_profile_pulled.FindSUB = 0
                                tbl_api_profile_pulled.FindPAR = 0
                                tbl_api_profile_pulled.FindVILL = 0
                                tbl_api_profile_pulled.FindSEX = 0
                                tbl_api_profile_pulled.FindWHO = 0
                                tbl_api_profile_pulled.FindSCH = 0
                                tbl_api_profile_pulled.FindEDU = 0
                                tbl_api_profile_pulled.FindORG = 0
                                tbl_api_profile_pulled.FindREL = 0
                                tbl_api_profile_pulled.FindMAR = 0
                                tbl_api_profile_pulled.FindREA = 0
                                tbl_api_profile_pulled.FindLAN = 0
                                tbl_api_profile_pulled.FindHIV = 0
                                tbl_api_profile_pulled.FindPLA = 0
                                tbl_api_profile_pulled.FindPME = 0
                                tbl_api_profile_pulled.FindPMEM = 0
                                tbl_api_profile_pulled.FindEPM = 0
                                tbl_api_profile_pulled.FindEPMM = 0
                                tbl_api_profile_pulled.FindEMPSTA = 0
                                tbl_api_profile_pulled.FindVAL = 0
                                tbl_api_profile_pulled.id_beneficiary = 0
                                tbl_api_profile_pulled.Approved = 0
                                tbl_api_profile_pulled.rejected = 0
                                tbl_api_profile_pulled.inserted = 0
                                tbl_api_profile_pulled.id_review = tbl_api_provider2_customer.id_api_executing
                                tbl_api_profile_pulled.datecreated = Date.UtcNow
                                tbl_api_profile_pulled.dateuploaded = Date.UtcNow
                                tbl_api_profile_pulled.Observation = ""
                                tbl_api_profile_pulled.time_benlook = 0
                                tbl_api_profile_pulled.time_benproce = 0

                                dbEntities.api_profile_pulled.Add(tbl_api_profile_pulled)
                                dbEntities.SaveChanges()

                                idMAX = tbl_api_provider2_customer.id

                            Catch ex As Exception 'Error parsin one record

                                flagErros = True
                                ListMessage.Add("ID (" & idCurrent.ToString & "): " & ex.Message)

                            End Try

                        Next

                        Res_.maxID = idMAX

                        If flagErros Then
                            Res_.Message = "The API response it was correct, but some records couldn't be registered, the errors are shown below:<br \>" & String.Join("<br \>", ListMessage)
                            save_register_api_data(Res_, False, Exec_ID)
                        Else
                            save_register_api_data(Res_, True, Exec_ID)
                        End If


                    End If

                End Using


            Catch ex As Exception

                Res_.Success = False
                Res_.Message = String.Format("The data structure pulled has some data definition error, please contact to the service provider for verifying this API using the params {0} <br \><br \>Detail error: {1}", strParams.TrimStart("?"), ex.Message)
                'Res_.Message = String.Format("Over the record  ID {0}, we have a error described below:<br \><br \>{1}", , idCurrent), ex.Message)
                Res_.Results = 0
                Res_.maxID = -1
                Res_.minID = -1
                save_register_api_data(Res_, False, Exec_ID)

            End Try

            Ensibukko_Customer_api = Res_

        End Function


        Private Function Ensibukko_loan_api(ByVal strJSon_Data As String) As API_RESPONSE_EXC

            Dim jss As New JavaScriptSerializer()
            Dim Res_ As New API_RESPONSE_EXC
            Dim Exec_ID As Integer = 0
            Dim idCurrent As Integer = 0

            Try


                jss.MaxJsonLength = 10000000
                Ensibukko_Customer_Loan = jss.Deserialize(Of Ensibukko_loan)(strJSon_Data.Replace("status-code", "status_code"))

                Using dbEntities As New dbRMS_PBEntities

                    If Ensibukko_Customer_Loan.status_code <> 200 Then 'Error

                        ' Ensibukko_Customer_Loan.Message
                        Res_.Success = False
                        Res_.Message = Ensibukko_Customer_Loan.message
                        Res_.Results = Ensibukko_Customer_Loan.paginator.Data.Count
                        Res_.maxID = -1
                        Res_.minID = -1

                        save_register_api_data(Res_, False, 0)

                    Else

                        Res_.Success = True
                        Res_.Message = Ensibukko_Customer_Loan.message
                        Res_.Results = Ensibukko_Customer_Loan.paginator.Data.Count
                        Res_.maxID = 0
                        Res_.minID = 0

                        '--*******************************ALL Data Pulled attemp ****************************************
                        Exec_ID = save_register_api_data(Res_, False, 0)
                        '--*******************************ALL Data Pulled attemp****************************************

                        ' Dim n = Ensibukko_Customer_Loan.Results 'Number of result
                        Dim tbl_vw_api As vw_api = dbEntities.vw_api.Where(Function(P) P.id_api = id_api).FirstOrDefault()

                        Dim tbl_tme_ficha_proyecto As tme_Ficha_Proyecto = dbEntities.tme_Ficha_Proyecto.Find(tbl_vw_api.id_ficha_proyecto)
                        Dim tbl_vw_Periodo As vw_t_periodos = dbEntities.vw_t_periodos.Where(Function(p) p.activo = True And p.id_programa = tbl_vw_api.id_programa).FirstOrDefault
                        Dim strPeriodo = String.Format("FY{0}{1}", tbl_vw_Periodo.ciclo, tbl_vw_Periodo.codigo_anio_fiscal)
                        Dim idMAX As Integer = 0

                        Dim flagErros As Boolean = False
                        Dim ListMessage As List(Of String) = New List(Of String)

                        For Each item In Ensibukko_Customer_Loan.paginator.Data

                            Dim tbl_api_provider1_loan As New api_provider1_loan
                            Dim id_api_provider1_loan As Integer = 0

                            idCurrent = item.loan_id

                            Try

                                If Res_.minID = 0 Then
                                    Res_.minID = item.loan_id
                                End If

                                tbl_api_provider1_loan.loan_id = item.loan_id
                                tbl_api_provider1_loan.sacco_id = item.sacco_Id
                                tbl_api_provider1_loan.branch_id = item.branch_id
                                tbl_api_provider1_loan.customer_id = item.customer_id
                                tbl_api_provider1_loan.dob = item.dob
                                tbl_api_provider1_loan.gender = item.gender.Value.ToString
                                tbl_api_provider1_loan.purpose = item.purpose
                                tbl_api_provider1_loan.application_date = item.application_date
                                tbl_api_provider1_loan.appraisal_date = item.appraisal_date
                                tbl_api_provider1_loan.approval_date = item.approval_date
                                tbl_api_provider1_loan.rejection_date = item.rejection_date
                                tbl_api_provider1_loan.disbursed_at = item.disbursed_at
                                tbl_api_provider1_loan.requested_amount = item.requested_amount
                                tbl_api_provider1_loan.approved_amount = item.approved_amount
                                tbl_api_provider1_loan.currency = item.currency
                                tbl_api_provider1_loan.down_payment = item.down_payment
                                tbl_api_provider1_loan.clearing_date = item.clearing_date
                                tbl_api_provider1_loan.write_off_date = item.write_off_date
                                tbl_api_provider1_loan.status = item.status
                                tbl_api_provider1_loan.repayment_period_months = item.repayment_period_months

                                tbl_api_provider1_loan.id_api_executing = Exec_ID

                                dbEntities.api_provider1_loan.Add(tbl_api_provider1_loan)
                                dbEntities.SaveChanges()

                                id_api_provider1_loan = tbl_api_provider1_loan.id_api_provider1_loan

                                ''---*************Now passing to the Beneficiary profile Bulk***************************
                                Dim tbl_api_profiled_financial_services As New api_profiled_financial_services

                                tbl_api_profiled_financial_services.source_tran_id = tbl_api_provider1_loan.loan_id
                                tbl_api_profiled_financial_services.sacco_id = item.sacco_Id
                                tbl_api_profiled_financial_services.branch_id = tbl_api_provider1_loan.branch_id
                                tbl_api_profiled_financial_services.customer_id = tbl_api_provider1_loan.customer_id

                                Dim ORG_ As tme_organization = dbEntities.tme_organization.Where(Function(p) p.organization_code.Trim = tbl_api_provider1_loan.branch_id.ToString() And p.id_ejecutor = tbl_tme_ficha_proyecto.id_ejecutor).FirstOrDefault()

                                Dim id_vill As Integer = 0
                                Dim Org_NAme As String = ""

                                If IsNothing(ORG_) Then
                                    id_vill = 0
                                    Org_NAme = ""
                                    tbl_api_profiled_financial_services.organization_name = ""
                                Else
                                    id_vill = If(ORG_.id_village.HasValue, ORG_.id_village, 0)
                                    Org_NAme = If(String.IsNullOrEmpty(ORG_.name), "", ORG_.name)
                                    tbl_api_profiled_financial_services.organization_name = ORG_.name
                                End If

                                Dim vw_GEO As vw_tme_village
                                If Val(id_vill) > 0 Then
                                    vw_GEO = dbEntities.vw_tme_village.Where(Function(p) p.id_village = id_vill).FirstOrDefault()
                                End If

                                If IsNothing(vw_GEO) Then

                                    tbl_api_profiled_financial_services.District = ""
                                    tbl_api_profiled_financial_services.County = ""
                                    tbl_api_profiled_financial_services.Subcounty = ""
                                    tbl_api_profiled_financial_services.Parish = ""
                                    tbl_api_profiled_financial_services.Village = ""

                                Else

                                    tbl_api_profiled_financial_services.District = vw_GEO.nombre_district
                                    tbl_api_profiled_financial_services.County = vw_GEO.nombre_county
                                    tbl_api_profiled_financial_services.Subcounty = vw_GEO.nombre_subcounty
                                    tbl_api_profiled_financial_services.Parish = vw_GEO.nombre_parish
                                    tbl_api_profiled_financial_services.Village = vw_GEO.nombre_village

                                End If

                                tbl_api_profiled_financial_services.on_behalf = "Customer"
                                tbl_api_profiled_financial_services.gender = tbl_api_provider1_loan.gender

                                Dim id_group_of_age As Integer = 0
                                Dim str_group_of_age As String = ""

                                Dim int_age As Long = DateDiff(DateInterval.Year, CType(tbl_api_provider1_loan.dob, Date), Date.UtcNow)

                                Dim group_of_age = dbEntities.tme_group_age.Where(Function(f) int_age >= f.valorMenor And int_age <= f.valorMayor).FirstOrDefault

                                If IsNothing(group_of_age) Then
                                    If int_age >= 5 And int_age <= 10 Then
                                        str_group_of_age = "Between 10 and 14"
                                    End If
                                Else
                                    str_group_of_age = group_of_age.group_age
                                End If

                                tbl_api_profiled_financial_services.date_of_birth = tbl_api_provider1_loan.dob
                                tbl_api_profiled_financial_services.group_of_age = str_group_of_age
                                tbl_api_profiled_financial_services.Service_Type = "Loans"
                                tbl_api_profiled_financial_services.Purpose = item.purpose
                                tbl_api_profiled_financial_services.value = item.approved_amount
                                tbl_api_profiled_financial_services.date_transaction = item.application_date
                                tbl_api_profiled_financial_services.Period = strPeriodo

                                tbl_api_profiled_financial_services.FindPER = 0
                                tbl_api_profiled_financial_services.FindDIS = 0
                                tbl_api_profiled_financial_services.FindCOU = 0
                                tbl_api_profiled_financial_services.FindSUB = 0
                                tbl_api_profiled_financial_services.FindPAR = 0
                                tbl_api_profiled_financial_services.FindVILL = 0
                                tbl_api_profiled_financial_services.FindSEX = 0
                                tbl_api_profiled_financial_services.FindAGE = 0

                                tbl_api_profiled_financial_services.findVal = 0
                                tbl_api_profiled_financial_services.findORG = 0
                                tbl_api_profiled_financial_services.time_benproce = 0
                                tbl_api_profiled_financial_services.time_benlook = 0

                                tbl_api_profiled_financial_services.id_transaction = 0
                                tbl_api_profiled_financial_services.Approved = 0
                                tbl_api_profiled_financial_services.rejected = 0
                                tbl_api_profiled_financial_services.inserted = 0
                                tbl_api_profiled_financial_services.datecreated = Date.UtcNow
                                tbl_api_profiled_financial_services.dateuploaded = Date.UtcNow
                                tbl_api_profiled_financial_services.Observation = ""

                                tbl_api_profiled_financial_services.id_api_executing = Exec_ID


                                dbEntities.api_profiled_financial_services.Add(tbl_api_profiled_financial_services)
                                dbEntities.SaveChanges()

                                idMAX = tbl_api_provider1_loan.loan_id

                            Catch ex As Exception 'Error parsin one record

                                flagErros = True
                                ListMessage.Add("ID (" & idCurrent.ToString & "): " & ex.Message)

                            End Try

                        Next

                        Res_.maxID = idMAX

                        If flagErros Then
                            Res_.Message = "The API response it was correct, but some records couldn't be registered, the errors are shown below:<br \>" & String.Join("<br \>", ListMessage)
                            save_register_api_data(Res_, False, Exec_ID)
                        Else
                            save_register_api_data(Res_, True, Exec_ID)
                        End If

                    End If

                End Using


            Catch ex As Exception

                Res_.Success = False
                Res_.Message = String.Format("The data structure pulled has some data definition error, please contact to the service provider for verifying this API using the params {0} <br \><br \>Detail error: {1}", strParams.TrimStart("?"), ex.Message)
                'Res_.Message = String.Format("Over the record  ID {0}, we have a error described below:<br \><br \>{1}", , idCurrent), ex.Message)
                Res_.Results = 0
                Res_.maxID = -1
                Res_.minID = -1
                save_register_api_data(Res_, False, Exec_ID)

            End Try

            Ensibukko_loan_api = Res_

        End Function



        Private Function Ensibukko_saving_api(ByVal strJSon_Data As String) As API_RESPONSE_EXC

            Dim jss As New JavaScriptSerializer()
            Dim Res_ As New API_RESPONSE_EXC
            Dim Exec_ID As Integer = 0
            Dim idCurrent As Integer = 0

            Try


                jss.MaxJsonLength = 10000000
                Ensibukko_Customer_Saving = jss.Deserialize(Of Ensibukko_saving)(strJSon_Data.Replace("status-code", "status_code"))

                Using dbEntities As New dbRMS_PBEntities

                    If Ensibukko_Customer_Saving.status_code <> 200 Then 'Error

                        ' Ensibukko_Customer_Saving.Message
                        Res_.Success = False
                        Res_.Message = Ensibukko_Customer_Saving.message
                        Res_.Results = Ensibukko_Customer_Saving.paginator.Data.Count
                        Res_.maxID = -1
                        Res_.minID = -1

                        save_register_api_data(Res_, False, 0)

                    Else

                        Res_.Success = True
                        Res_.Message = Ensibukko_Customer_Saving.message
                        Res_.Results = Ensibukko_Customer_Saving.paginator.Data.Count
                        Res_.maxID = 0
                        Res_.minID = 0

                        '--*******************************ALL Data Pulled attemp ****************************************
                        Exec_ID = save_register_api_data(Res_, False, 0)
                        '--*******************************ALL Data Pulled attemp****************************************

                        ' Dim n = Ensibukko_Customer_Saving.Results 'Number of result
                        Dim tbl_vw_api As vw_api = dbEntities.vw_api.Where(Function(P) P.id_api = id_api).FirstOrDefault()

                        Dim tbl_tme_ficha_proyecto As tme_Ficha_Proyecto = dbEntities.tme_Ficha_Proyecto.Find(tbl_vw_api.id_ficha_proyecto)
                        Dim tbl_vw_Periodo As vw_t_periodos = dbEntities.vw_t_periodos.Where(Function(p) p.activo = True And p.id_programa = tbl_vw_api.id_programa).FirstOrDefault
                        Dim strPeriodo = String.Format("FY{0}{1}", tbl_vw_Periodo.ciclo, tbl_vw_Periodo.codigo_anio_fiscal)
                        Dim idMAX As Integer = 0

                        Dim flagErros As Boolean = False
                        Dim ListMessage As List(Of String) = New List(Of String)

                        For Each item In Ensibukko_Customer_Saving.paginator.Data

                            Dim tbl_api_provider1_saving As New api_provider1_saving
                            Dim id_api_provider1_saving As Integer = 0

                            idCurrent = item.id

                            Try

                                If Res_.minID = 0 Then
                                    Res_.minID = item.id
                                End If

                                tbl_api_provider1_saving.id = item.id
                                tbl_api_provider1_saving.sacco_id = item.sacco_id
                                tbl_api_provider1_saving.branch_id = item.branch_id
                                tbl_api_provider1_saving.customer_id = item.customer_id
                                tbl_api_provider1_saving.dob = item.dob
                                tbl_api_provider1_saving.gender = item.gender.Value.ToString
                                tbl_api_provider1_saving.name = item.name
                                tbl_api_provider1_saving.account_name = item.account_name
                                tbl_api_provider1_saving.type = item.type
                                tbl_api_provider1_saving.balance = item.balance
                                tbl_api_provider1_saving.currency = item.currency
                                tbl_api_provider1_saving.is_dormant = item.is_dormant
                                tbl_api_provider1_saving.opened_at = item.opened_at

                                tbl_api_provider1_saving.id_api_executing = Exec_ID

                                dbEntities.api_provider1_saving.Add(tbl_api_provider1_saving)
                                dbEntities.SaveChanges()

                                id_api_provider1_saving = tbl_api_provider1_saving.id_api_provider1_saving

                                ''---*************Now passing to the Beneficiary profile Bulk***************************
                                Dim tbl_api_profiled_financial_services As New api_profiled_financial_services

                                tbl_api_profiled_financial_services.source_tran_id = tbl_api_provider1_saving.id
                                tbl_api_profiled_financial_services.sacco_id = item.sacco_id
                                tbl_api_profiled_financial_services.branch_id = tbl_api_provider1_saving.branch_id
                                tbl_api_profiled_financial_services.customer_id = tbl_api_provider1_saving.customer_id

                                Dim ORG_ As tme_organization = dbEntities.tme_organization.Where(Function(p) p.organization_code.Trim = tbl_api_provider1_saving.branch_id.ToString() And p.id_ejecutor = tbl_tme_ficha_proyecto.id_ejecutor).FirstOrDefault()

                                Dim id_vill As Integer = 0
                                Dim Org_NAme As String = ""

                                If IsNothing(ORG_) Then
                                    id_vill = 0
                                    Org_NAme = ""
                                    tbl_api_profiled_financial_services.organization_name = ""
                                Else
                                    id_vill = If(ORG_.id_village.HasValue, ORG_.id_village, 0)
                                    Org_NAme = If(String.IsNullOrEmpty(ORG_.name), "", ORG_.name)
                                    tbl_api_profiled_financial_services.organization_name = ORG_.name
                                End If

                                Dim vw_GEO As vw_tme_village
                                If Val(id_vill) > 0 Then
                                    vw_GEO = dbEntities.vw_tme_village.Where(Function(p) p.id_village = id_vill).FirstOrDefault()
                                End If

                                If IsNothing(vw_GEO) Then

                                    tbl_api_profiled_financial_services.District = ""
                                    tbl_api_profiled_financial_services.County = ""
                                    tbl_api_profiled_financial_services.Subcounty = ""
                                    tbl_api_profiled_financial_services.Parish = ""
                                    tbl_api_profiled_financial_services.Village = ""

                                Else

                                    tbl_api_profiled_financial_services.District = vw_GEO.nombre_district
                                    tbl_api_profiled_financial_services.County = vw_GEO.nombre_county
                                    tbl_api_profiled_financial_services.Subcounty = vw_GEO.nombre_subcounty
                                    tbl_api_profiled_financial_services.Parish = vw_GEO.nombre_parish
                                    tbl_api_profiled_financial_services.Village = vw_GEO.nombre_village

                                End If

                                tbl_api_profiled_financial_services.on_behalf = "Customer"
                                tbl_api_profiled_financial_services.gender = tbl_api_provider1_saving.gender

                                Dim id_group_of_age As Integer = 0
                                Dim str_group_of_age As String = ""

                                Dim int_age As Long = DateDiff(DateInterval.Year, CType(tbl_api_provider1_saving.dob, Date), Date.UtcNow)

                                Dim group_of_age = dbEntities.tme_group_age.Where(Function(f) int_age >= f.valorMenor And int_age <= f.valorMayor).FirstOrDefault

                                If IsNothing(group_of_age) Then
                                    If int_age >= 5 And int_age <= 10 Then
                                        str_group_of_age = "Between 10 and 14"
                                    End If
                                Else
                                    str_group_of_age = group_of_age.group_age
                                End If

                                tbl_api_profiled_financial_services.date_of_birth = tbl_api_provider1_saving.dob
                                tbl_api_profiled_financial_services.group_of_age = str_group_of_age
                                tbl_api_profiled_financial_services.Service_Type = "Saving"
                                tbl_api_profiled_financial_services.Purpose = item.name
                                tbl_api_profiled_financial_services.value = item.balance
                                tbl_api_profiled_financial_services.date_transaction = item.opened_at
                                tbl_api_profiled_financial_services.Period = strPeriodo

                                tbl_api_profiled_financial_services.FindPER = 0
                                tbl_api_profiled_financial_services.FindDIS = 0
                                tbl_api_profiled_financial_services.FindCOU = 0
                                tbl_api_profiled_financial_services.FindSUB = 0
                                tbl_api_profiled_financial_services.FindPAR = 0
                                tbl_api_profiled_financial_services.FindVILL = 0
                                tbl_api_profiled_financial_services.FindSEX = 0
                                tbl_api_profiled_financial_services.FindAGE = 0

                                tbl_api_profiled_financial_services.findVal = 0
                                tbl_api_profiled_financial_services.findORG = 0
                                tbl_api_profiled_financial_services.time_benproce = 0
                                tbl_api_profiled_financial_services.time_benlook = 0

                                tbl_api_profiled_financial_services.id_transaction = 0
                                tbl_api_profiled_financial_services.Approved = 0
                                tbl_api_profiled_financial_services.rejected = 0
                                tbl_api_profiled_financial_services.inserted = 0
                                tbl_api_profiled_financial_services.datecreated = Date.UtcNow
                                tbl_api_profiled_financial_services.dateuploaded = Date.UtcNow
                                tbl_api_profiled_financial_services.Observation = ""

                                tbl_api_profiled_financial_services.id_api_executing = Exec_ID

                                dbEntities.api_profiled_financial_services.Add(tbl_api_profiled_financial_services)
                                dbEntities.SaveChanges()

                                idMAX = tbl_api_provider1_saving.id

                            Catch ex As Exception 'Error parsin one record

                                flagErros = True
                                ListMessage.Add("ID (" & idCurrent.ToString & "): " & ex.Message)

                            End Try

                        Next

                        Res_.maxID = idMAX

                        If flagErros Then
                            Res_.Message = "The API response it was correct, but some records couldn't be registered, the errors are shown below:<br \>" & String.Join("<br \>", ListMessage)
                            save_register_api_data(Res_, False, Exec_ID)
                        Else
                            save_register_api_data(Res_, True, Exec_ID)
                        End If

                    End If

                End Using


            Catch ex As Exception

                Res_.Success = False
                Res_.Message = String.Format("The data structure pulled has some data definition error, please contact to the service provider for verifying this API using the params {0} <br \><br \>Detail error: {1}", strParams.TrimStart("?"), ex.Message)
                'Res_.Message = String.Format("Over the record  ID {0}, we have a error described below:<br \><br \>{1}", , idCurrent), ex.Message)
                Res_.Results = 0
                Res_.maxID = -1
                Res_.minID = -1
                save_register_api_data(Res_, False, Exec_ID)

            End Try

            Ensibukko_saving_api = Res_

        End Function




        Private Function MobiPay_Farmer_api(ByVal strJSon_Data As String) As API_RESPONSE_EXC

            Dim jss As New JavaScriptSerializer()
            Dim Res_ As New API_RESPONSE_EXC
            Dim Exec_ID As Integer = 0
            Dim idCurrent As Integer = 0

            Try


                jss.MaxJsonLength = 10000000
                MobiPay_Farmer_Struct = jss.Deserialize(Of MobiPay_Farmer)(strJSon_Data)

                Using dbEntities As New dbRMS_PBEntities

                    If Not MobiPay_Farmer_Struct.Success Then 'Error

                        ' Ensibukko_Customer_struct.Message
                        Res_.Success = False
                        Res_.Message = MobiPay_Farmer_Struct.Message
                        Res_.Results = MobiPay_Farmer_Struct.Results
                        Res_.maxID = -1
                        Res_.minID = -1

                        save_register_api_data(Res_, False, 0)

                    Else

                        Res_.Success = MobiPay_Farmer_Struct.Success
                        Res_.Message = MobiPay_Farmer_Struct.Message
                        Res_.Results = MobiPay_Farmer_Struct.Farmers.Count
                        Res_.maxID = 0
                        Res_.minID = 0

                        '--*******************************ALL Data Pulled attemp ****************************************
                        Exec_ID = save_register_api_data(Res_, False, 0)
                        '--*******************************ALL Data Pulled attemp****************************************

                        ' Dim n = Ensibukko_Customer_struct.Results 'Number of result
                        Dim tbl_vw_api As vw_api = dbEntities.vw_api.Where(Function(P) P.id_api = id_api).FirstOrDefault()
                        Dim tbl_vw_Periodo As vw_t_periodos = dbEntities.vw_t_periodos.Where(Function(p) p.activo = True And p.id_programa = tbl_vw_api.id_programa).FirstOrDefault
                        Dim strPeriodo = String.Format("FY{0}{1}", tbl_vw_Periodo.ciclo, tbl_vw_Periodo.codigo_anio_fiscal)
                        Dim idMAX As Integer = 0

                        Dim flagErros As Boolean = False
                        Dim ListMessage As List(Of String) = New List(Of String)

                        For Each item In MobiPay_Farmer_Struct.Farmers

                            Dim tbl_api_provider1_farmer As New api_provider1_farmer

                            Dim id_provider1_farmer As Integer = 0

                            idCurrent = item.AGROBASE_FARMER_ID

                            Try

                                If Res_.minID = 0 Then
                                    Res_.minID = item.AGROBASE_FARMER_ID
                                End If

                                tbl_api_provider1_farmer.AGROBASE_FARMER_ID = item.AGROBASE_FARMER_ID
                                tbl_api_provider1_farmer.MOBIPAY_ACCOUNT = item.MOBIPAY_ACCOUNT
                                tbl_api_provider1_farmer.FARMER_NAME = item.FARMER_NAME
                                tbl_api_provider1_farmer.FARMER_MOTHERS_NAME = item.FARMER_MOTHERS_NAME
                                tbl_api_provider1_farmer.FARMER_PHONE = item.FARMER_PHONE
                                tbl_api_provider1_farmer.FARMER_DOB = item.FARMER_DOB
                                tbl_api_provider1_farmer.FARMER_DATE_REGISTERED = item.FARMER_DATE_REGISTERED
                                tbl_api_provider1_farmer.FARMER_AGE = item.FARMER_AGE
                                tbl_api_provider1_farmer.FARMER_GENDER = item.FARMER_GENDER
                                tbl_api_provider1_farmer.FARMER_PHOTO = item.FARMER_PHOTO
                                tbl_api_provider1_farmer.FARMER_ID_TYPE = Convert.ToInt32(Val(item.FARMER_ID_TYPE))
                                tbl_api_provider1_farmer.FARMER_KIN = item.FARMER_KIN
                                tbl_api_provider1_farmer.FARMER_KIN_NUMBER = item.FARMER_KIN_NUMBER
                                tbl_api_provider1_farmer.FARRMER_COOPERATIVE = item.FARRMER_COOPERATIVE
                                tbl_api_provider1_farmer.FARRMER_COOPERATIVE_ID = item.FARRMER_COOPERATIVE_ID
                                tbl_api_provider1_farmer.FARMER_EDUCATION = item.FARMER_EDUCATION
                                tbl_api_provider1_farmer.FARMER_MARITAL_STATUS = item.FARMER_MARITAL_STATUS
                                tbl_api_provider1_farmer.FARMER_DISTRICT = item.FARMER_DISTRICT
                                tbl_api_provider1_farmer.FARMER_CONSTITUENCY = item.FARMER_CONSTITUENCY
                                tbl_api_provider1_farmer.FARMER_SUBCOUNTY = item.FARMER_SUBCOUNTY
                                tbl_api_provider1_farmer.FARMER_PARISH = item.FARMER_PARISH
                                tbl_api_provider1_farmer.FARMER_VILLAGE = item.FARMER_VILLAGE

                                For Each item2 In item.Farms

                                    Dim tbl_api_provider1_farm As New api_provider1_farm

                                    tbl_api_provider1_farm.FARM_ID = item2.FARM_ID
                                    tbl_api_provider1_farm.AGROBASE_FARMER_ID = item.AGROBASE_FARMER_ID
                                    tbl_api_provider1_farm.FARM_SURVEY_NO = item2.FARM_SURVEY_NO
                                    tbl_api_provider1_farm.FARM_POINT_A = item2.FARM_POINT_A
                                    tbl_api_provider1_farm.FARM_POINT_B = item2.FARM_POINT_B
                                    tbl_api_provider1_farm.FARM_PONT_C = item2.FARM_PONT_C
                                    tbl_api_provider1_farm.FARM_POINT_D = item2.FARM_POINT_D
                                    tbl_api_provider1_farm.FARM_LAND_OWNERSHIP = item2.FARM_LAND_OWNERSHIP
                                    tbl_api_provider1_farm.FARM_LAND_YEAR_ACQUIRED = item2.FARM_LAND_YEAR_ACQUIRED
                                    tbl_api_provider1_farm.FARM_ADDRESS = item2.FARM_ADDRESS
                                    tbl_api_provider1_farm.FARM_APPROACH_ROAD = item2.FARM_APPROACH_ROAD
                                    tbl_api_provider1_farm.FARM_TOTAL_AREA = item2.FARM_TOTAL_AREA
                                    tbl_api_provider1_farm.FARM_TOPOLOGY = item2.FARM_TOPOLOGY
                                    tbl_api_provider1_farm.FARM_IRRIGATION_SOURCE = item2.FARM_IRRIGATION_SOURCE
                                    tbl_api_provider1_farm.FARM_PICTURE = item2.FARM_PICTURE
                                    tbl_api_provider1_farm.FARMER_LAND_MARK = item2.FARMER_LAND_MARK

                                    dbEntities.api_provider1_farm.Add(tbl_api_provider1_farm)

                                Next

                                dbEntities.SaveChanges()

                                tbl_api_provider1_farmer.CROP_TYPE = item.Crops.CROP_TYPE
                                tbl_api_provider1_farmer.CROP_VARIETY = item.Crops.CROP_VARIETY
                                tbl_api_provider1_farmer.CROP_SOWING_DATE = item.Crops.SOWING_DATE
                                tbl_api_provider1_farmer.CROP_HARVEST_DATE = item.Crops.HARVEST_DATE
                                tbl_api_provider1_farmer.CROP_SEED_SOURCE = item.Crops.SEED_SOURCE
                                tbl_api_provider1_farmer.CROP_SEED_QUANTITY = item.Crops.SEED_QUANTITY
                                tbl_api_provider1_farmer.CROP_ESTIMATED_HARVEST = item.Crops.ESTIMATED_HARVEST
                                tbl_api_provider1_farmer.CROP_SEED_COST = item.Crops.SEED_COST
                                tbl_api_provider1_farmer.CROP_PLANTING_AREA = item.Crops.PLANTING_AREA
                                tbl_api_provider1_farmer.FAM_MEMBERS = If(item.Family.MEMBERS.HasValue, item.Family.MEMBERS, 0)
                                tbl_api_provider1_farmer.FAM_ADULTS = If(item.Family.ADULTS.HasValue, item.Family.ADULTS, 0)
                                tbl_api_provider1_farmer.FAM_CHILDREN = If(item.Family.CHILDREN.HasValue, item.Family.CHILDREN, 0)
                                tbl_api_provider1_farmer.FAM_SCHOOL_GOING = If(item.Family.SCHOOL_GOING.HasValue, item.Family.SCHOOL_GOING, 0)
                                tbl_api_provider1_farmer.FAM_HOME_STAYING = If(item.Family.HOME_STAYING.HasValue, item.Family.HOME_STAYING, 0)
                                tbl_api_provider1_farmer.FAM_MALE = If(item.Family.MALE.HasValue, item.Family.MALE, 0)
                                tbl_api_provider1_farmer.FAM_FEMALE = If(item.Family.FEMALE.HasValue, item.Family.FEMALE, 0)
                                tbl_api_provider1_farmer.FAM_HEAD = item.Family.HEAD

                                dbEntities.api_provider1_farmer.Add(tbl_api_provider1_farmer)
                                dbEntities.SaveChanges()

                                id_provider1_farmer = tbl_api_provider1_farmer.ID_PROVIDER1_FARMER

                                Dim farms_ As List(Of api_provider1_farm) = dbEntities.api_provider1_farm.Where(Function(p) p.id_provider1_farmer = 0 And p.AGROBASE_FARMER_ID = tbl_api_provider1_farmer.AGROBASE_FARMER_ID).ToList()

                                For Each farm_item In farms_

                                    Dim farmsItem = farm_item
                                    farmsItem.id_provider1_farmer = id_provider1_farmer
                                    dbEntities.Entry(farmsItem).State = Entity.EntityState.Modified
                                    dbEntities.SaveChanges()

                                Next

                                For Each item3 In item.Income

                                    Dim tbl_api_provider1_income As New api_provider1_income

                                    tbl_api_provider1_income.id_provider1_farmer = tbl_api_provider1_farmer.ID_PROVIDER1_FARMER
                                    tbl_api_provider1_income.BANK = item3.BANK
                                    tbl_api_provider1_income.INCOME_ACGRI = item3.INCOME_ACGRIC
                                    tbl_api_provider1_income.INCOME_NON_AGRIC = item3.INCOME_NON_AGRIC

                                    dbEntities.api_provider1_income.Add(tbl_api_provider1_income)

                                Next

                                dbEntities.SaveChanges()

                                ''--*******************************ALL Data Pulled ****************************************
                                'Exec_ID = save_register_api_data(Res_, False, 0)
                                ''--*******************************ALL Data Pulled ****************************************

                                tbl_api_provider1_farmer = dbEntities.api_provider1_farmer.Where(Function(p) p.ID_PROVIDER1_FARMER = id_provider1_farmer).FirstOrDefault()
                                tbl_api_provider1_farmer.id_api_executing = Exec_ID
                                dbEntities.SaveChanges()

                                '---*************Now passing to the Beneficiary profile Bulk***************************
                                Dim tbl_api_profile_pulled As New api_profile_pulled

                                tbl_api_profile_pulled.id_api = id_api
                                tbl_api_profile_pulled.id_source = tbl_api_provider1_farmer.AGROBASE_FARMER_ID
                                tbl_api_profile_pulled.id_organization_source = tbl_api_provider1_farmer.FARRMER_COOPERATIVE_ID
                                tbl_api_profile_pulled.id_api_executing = Exec_ID
                                tbl_api_profile_pulled.Activity_Code = tbl_vw_api.activity_code
                                tbl_api_profile_pulled.Activity_Approval = tbl_vw_api.activity_code
                                tbl_api_profile_pulled.Period = strPeriodo.Trim
                                Dim strFname As String = If(String.IsNullOrEmpty(tbl_api_provider1_farmer.FARMER_NAME), "", tbl_api_provider1_farmer.FARMER_NAME)
                                Dim ProfileName As String() = getString_Name(strFname.Trim)
                                tbl_api_profile_pulled.Surname = If(strFname.Trim.Length = 0, "NOT INDICATED", ProfileName(0))
                                tbl_api_profile_pulled.First_Name = If(strFname.Trim.Length = 0, "NOT INDICATED", ProfileName(1))
                                Dim strMname As String = If(String.IsNullOrEmpty(tbl_api_provider1_farmer.FARMER_MOTHERS_NAME), "", tbl_api_provider1_farmer.FARMER_MOTHERS_NAME)
                                Dim Mother_Name As String() = getString_Name(strMname.Trim)
                                tbl_api_profile_pulled.Mother_Surname = If(strMname.Trim.Length = 0, "NOT INDICATED", Mother_Name(0))
                                tbl_api_profile_pulled.Mother_FirstName = If(strMname.Trim.Length = 0, "NOT INDICATED", Mother_Name(1))
                                tbl_api_profile_pulled.District = tbl_api_provider1_farmer.FARMER_DISTRICT.Trim
                                tbl_api_profile_pulled.County = tbl_api_provider1_farmer.FARMER_CONSTITUENCY.Trim
                                tbl_api_profile_pulled.Sub_County = tbl_api_provider1_farmer.FARMER_SUBCOUNTY.Trim
                                tbl_api_profile_pulled.Parish = tbl_api_provider1_farmer.FARMER_PARISH.Trim
                                tbl_api_profile_pulled.Village = tbl_api_provider1_farmer.FARMER_VILLAGE.Trim
                                tbl_api_profile_pulled.Sex = tbl_api_provider1_farmer.FARMER_GENDER.Trim
                                tbl_api_profile_pulled.Birth_Day = DatePart(DateInterval.Day, CDate(tbl_api_provider1_farmer.FARMER_DOB))
                                tbl_api_profile_pulled.Birth_Month = DatePart(DateInterval.Month, CDate(tbl_api_provider1_farmer.FARMER_DOB))
                                tbl_api_profile_pulled.Birth_Year = DatePart(DateInterval.Year, CDate(tbl_api_provider1_farmer.FARMER_DOB))
                                tbl_api_profile_pulled.Age = Val(tbl_api_provider1_farmer.FARMER_AGE)
                                tbl_api_profile_pulled.Phone_Number = ""
                                tbl_api_profile_pulled.Mobile_Number = tbl_api_provider1_farmer.FARMER_PHONE
                                tbl_api_profile_pulled.Who_are_you = "Producer" 'Ask about it
                                tbl_api_profile_pulled.Schooling_status = "Out of School"
                                tbl_api_profile_pulled.education_level = If(tbl_api_provider1_farmer.FARMER_EDUCATION.Trim = "NONE", "Not Indicated", tbl_api_provider1_farmer.FARMER_EDUCATION.Trim)
                                tbl_api_profile_pulled.Organization = tbl_api_provider1_farmer.FARRMER_COOPERATIVE.Trim
                                tbl_api_profile_pulled.Religion = "Not Indicated"
                                tbl_api_profile_pulled.Marital_Status = If(tbl_api_provider1_farmer.FARMER_MARITAL_STATUS.Trim = "UNKNOWN", "Not Indicated", tbl_api_provider1_farmer.FARMER_MARITAL_STATUS.Trim)
                                tbl_api_profile_pulled.PeopleLiving_in_yourhouse_hold = tbl_api_provider1_farmer.FAM_MEMBERS
                                tbl_api_profile_pulled.Number_ofChildren_youhave = tbl_api_provider1_farmer.FAM_CHILDREN
                                tbl_api_profile_pulled.Can_Read = ""
                                tbl_api_profile_pulled.which_languages = ""
                                tbl_api_profile_pulled.HIV_Status_awareness = ""
                                tbl_api_profile_pulled.Planning_Method_Awareness = ""
                                tbl_api_profile_pulled.Mention_that_youknow = ""
                                tbl_api_profile_pulled.Ever_used_planning_methods = ""
                                tbl_api_profile_pulled.which_method = ""
                                tbl_api_profile_pulled.Employment_Status = "Self employed"
                                tbl_api_profile_pulled.employed_howlong = 0
                                tbl_api_profile_pulled.Specific_value_chain = tbl_api_provider1_farmer.CROP_TYPE.Trim
                                tbl_api_profile_pulled.FindCOI = 0
                                tbl_api_profile_pulled.FindACT = 0
                                tbl_api_profile_pulled.FindPER = 0
                                tbl_api_profile_pulled.FindDIS = 0
                                tbl_api_profile_pulled.FindCOU = 0
                                tbl_api_profile_pulled.FindSUB = 0
                                tbl_api_profile_pulled.FindPAR = 0
                                tbl_api_profile_pulled.FindVILL = 0
                                tbl_api_profile_pulled.FindSEX = 0
                                tbl_api_profile_pulled.FindWHO = 0
                                tbl_api_profile_pulled.FindSCH = 0
                                tbl_api_profile_pulled.FindEDU = 0
                                tbl_api_profile_pulled.FindORG = 0
                                tbl_api_profile_pulled.FindREL = 0
                                tbl_api_profile_pulled.FindMAR = 0
                                tbl_api_profile_pulled.FindREA = 0
                                tbl_api_profile_pulled.FindLAN = 0
                                tbl_api_profile_pulled.FindHIV = 0
                                tbl_api_profile_pulled.FindPLA = 0
                                tbl_api_profile_pulled.FindPME = 0
                                tbl_api_profile_pulled.FindPMEM = 0
                                tbl_api_profile_pulled.FindEPM = 0
                                tbl_api_profile_pulled.FindEPMM = 0
                                tbl_api_profile_pulled.FindEMPSTA = 0
                                tbl_api_profile_pulled.FindVAL = 0
                                tbl_api_profile_pulled.id_beneficiary = 0
                                tbl_api_profile_pulled.Approved = 0
                                tbl_api_profile_pulled.rejected = 0
                                tbl_api_profile_pulled.inserted = 0
                                tbl_api_profile_pulled.id_review = tbl_api_provider1_farmer.id_api_executing
                                tbl_api_profile_pulled.datecreated = Date.UtcNow
                                tbl_api_profile_pulled.dateuploaded = Date.UtcNow
                                tbl_api_profile_pulled.Observation = ""
                                tbl_api_profile_pulled.time_benlook = 0
                                tbl_api_profile_pulled.time_benproce = 0

                                dbEntities.api_profile_pulled.Add(tbl_api_profile_pulled)
                                dbEntities.SaveChanges()

                                idMAX = tbl_api_provider1_farmer.AGROBASE_FARMER_ID

                            Catch ex As Exception

                                flagErros = True
                                ListMessage.Add("ID (" & idCurrent.ToString & "): " & ex.Message)

                            End Try


                        Next

                        Res_.maxID = idMAX

                        If flagErros Then
                            Res_.Message = "The API response it was correct, but some records couldn't be registered, the errors are shown below:<br \>" & String.Join("<br \>", ListMessage)
                            save_register_api_data(Res_, False, Exec_ID)
                        Else
                            save_register_api_data(Res_, True, Exec_ID)
                        End If

                    End If

                End Using


            Catch ex As Exception

                Res_.Success = False
                'Res_.Message = String.Format("Over the record  ID {0}, we have a error described below:<br \><br \>{1}", If(idCurrent = 0, "(none one record has been parsed)", idCurrent), ex.Message)
                Res_.Message = String.Format("The data structure pulled has some data definition errors, please contact to the service provider for verifying this API using the params {0} <br \><br \>Detail error: {1}", strParams.TrimStart("?"), ex.Message)
                Res_.Results = 0
                Res_.maxID = -1
                Res_.minID = -1
                save_register_api_data(Res_, False, Exec_ID)

            End Try

            MobiPay_Farmer_api = Res_

        End Function


        Private Function getString_Name(ByVal _strName As String) As String()

            Dim ArrName As String() = _strName.Split(" ")
            Dim strName As String = ""

            For Each a As String In ArrName

                If a.Length > 0 Then
                    strName &= a.Trim & " "
                End If

            Next

            strName.TrimEnd(" ")

            getString_Name = strName.Split(" ")

        End Function

        Public Function save_register_api_data(ByVal result As API_RESPONSE_EXC, ByVal bPassed As Boolean, ByVal idExec As Integer) As Integer

            Dim tbl_t_api_executing As New t_api_executing

            Try

                Using dbEntities As New dbRMS_PBEntities

                    If idExec > 0 Then
                        tbl_t_api_executing = dbEntities.t_api_executing.Find(idExec)
                    End If

                    tbl_t_api_executing.id_api = id_api
                    tbl_t_api_executing.exec_records = result.Results
                    tbl_t_api_executing.exec_min_id = result.minID
                    tbl_t_api_executing.exec_max_id = result.maxID
                    tbl_t_api_executing.exec_date = Date.UtcNow
                    tbl_t_api_executing.exec_id_usr = idUSR
                    tbl_t_api_executing.exec_response_message = result.Message
                    tbl_t_api_executing.exec_bool_passed = If(bPassed, True, False)

                    If idExec = 0 Then
                        dbEntities.t_api_executing.Add(tbl_t_api_executing)
                    End If

                    dbEntities.SaveChanges()

                    If idExec = 0 Then

                        Dim strP As String() = strParams.TrimStart("?").Split("&")
                        Dim tbl_t_api_params As List(Of t_api_params) = dbEntities.t_api_params.Where(Function(p) p.id_api = id_api).ToList()

                        For Each a In strP

                            Dim b As String() = a.Split("=")
                            Dim tbl_t_api_executing_params As New t_api_executing_params

                            tbl_t_api_executing_params.id_api_params = tbl_t_api_params.Where(Function(p) p.api_param_name = b(0).Trim).FirstOrDefault().id_api_params
                            tbl_t_api_executing_params.id_api_executing = tbl_t_api_executing.id_api_executing
                            tbl_t_api_executing_params.api_param_value = b(1).Trim

                            Dim tbl_t_api_params_upd As t_api_params = dbEntities.t_api_params.Find(tbl_t_api_params.Where(Function(p) p.api_param_name = b(0).Trim).FirstOrDefault().id_api_params)
                            tbl_t_api_params_upd.api_param_value = b(1).Trim
                            dbEntities.Entry(tbl_t_api_params_upd).State = Entity.EntityState.Modified
                            'dbEntities.SaveChanges()

                            dbEntities.t_api_executing_params.Add(tbl_t_api_executing_params)
                            dbEntities.SaveChanges()

                        Next

                    End If

                    Return tbl_t_api_executing.id_api_executing

                End Using

            Catch ex As Exception

                Return 0

            End Try

        End Function


    End Class



End Namespace

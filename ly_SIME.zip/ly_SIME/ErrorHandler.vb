﻿Imports System.Data.SqlClient

Namespace CORE
    Public Class ErrorHandler
        Sub New()
            ' TODO: Complete member initialization 
        End Sub
        Public Function MensajeError(ByVal codigo, ByVal stack_trace) As String
            Dim mensaje = ""

            Select Case codigo
                Case 547
                    mensaje = "Existen registros asociados."
                Case 2627
                    mensaje = "No puede crear registros duplicados, revise los códigos o nombres de otros registros."
                Case 2601
                    mensaje = "No puede crear registros duplicados."
                Case Else
                    mensaje = "Un error general ha ocurrido, si el problema persiste contacte al administrador del sistema."
            End Select

            Using db As New dbRMS_JIEntities

                Dim oError As New t_error_log

                oError.mensaje = mensaje
                oError.stack_trace = stack_trace
                oError.fecha = Date.UtcNow

                db.t_error_log.Add(oError)
                db.SaveChanges()

            End Using

            Return mensaje
        End Function

    End Class
End Namespace

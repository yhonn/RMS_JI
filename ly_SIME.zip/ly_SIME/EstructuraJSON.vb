﻿Namespace RMS
    Public Class EstructuraJSON

        Private texto As String
        Public Property OTexto() As String
            Get
                Return texto
            End Get
            Set(ByVal value As String)
                texto = value
            End Set
        End Property

        Private valor As String
        Public Property oValor() As String
            Get
                Return valor
            End Get
            Set(ByVal value As String)
                valor = value
            End Set
        End Property
        Private estructuraID As String
        Public Property oestructuraID() As Integer
            Get
                Return estructuraID
            End Get
            Set(ByVal value As Integer)
                estructuraID = value
            End Set
        End Property

        Private tipoDato As String
        Public Property oTipoDato() As String
            Get
                Return tipoDato
            End Get
            Set(ByVal value As String)
                tipoDato = value
            End Set
        End Property


    End Class
End Namespace
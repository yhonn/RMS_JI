﻿
Imports System.Configuration.ConfigurationManager
Imports System.Data.SqlClient
Imports ly_SIME



Namespace RMS_SIME

    Public Class cl_IndicatorSync

        Public ReadOnly Property id_indicator As Integer
        Public ReadOnly Property id_User As Integer
        Public ReadOnly Property id_ficha_proyecto As Integer
        Public ReadOnly Property id_subREgion As Integer



        Public Sub New(ByVal id_ind As Integer, id_usr As Integer, id_proy As Integer, id_subr As Integer)


            id_indicator = id_ind
            id_User = id_usr
            id_ficha_proyecto = id_proy
            id_subREgion = id_subr

        End Sub


        Public Function Sync_Progress() As DataTable

            Dim tblResult As New DataTable()

            Using dbEntities As New dbRMS_JIEntities

                Dim list_result = dbEntities.AvanceIndicador_Res(id_indicator, id_User, id_ficha_proyecto, id_subREgion).ToList()

                If list_result.Count > 0 Then

                    Dim fields() = list_result.First.GetType.GetProperties
                    For Each field In fields
                        tblResult.Columns.Add(field.Name, field.PropertyType)
                    Next
                    For Each item In list_result
                        Dim row As DataRow = tblResult.NewRow
                        For Each field In fields
                            Dim p = item.GetType.GetProperty(field.Name)
                            row(field.Name) = p.GetValue(item, Nothing)
                        Next
                        tblResult.Rows.Add(row)
                    Next



                End If

            End Using


            Sync_Progress = tblResult

        End Function


    End Class

End Namespace

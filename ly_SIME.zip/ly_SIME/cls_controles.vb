﻿Imports System.Web.UI.WebControls
Imports Telerik.Web.UI
Imports System.Web.UI
Imports System.Web.UI.HtmlControls

Namespace CORE
    Public Class cls_controles
        Public Property moduloID As Integer = 0
        Public Property code_mod As String = ""
        Public Property controlesList As List(Of String)
        Public Property idiomaControl As List(Of vw_ctrl_language)

        Public Property idiomaID As Integer = 0

        Public db As New dbRMS_JIEntities

        Public class_user As cls_user

        Public Function checkControls(ByVal ctrl As Control, ByVal id_idioma As Integer, Optional cl_user As cls_user = Nothing)
            idiomaID = id_idioma
            class_user = cl_user
            Using dbEntities As New dbRMS_JIEntities
                controlesList = dbEntities.t_control.Where(Function(p) p.t_mod.mod_code = code_mod) _
                    .Select(Function(p) p.ctrl_code).ToList()
                idiomaControl = dbEntities.vw_ctrl_language.Where(Function(p) p.mod_code = code_mod And p.id_idioma = id_idioma).ToList()
                moduloID = dbEntities.t_mod.FirstOrDefault(Function(p) p.mod_code = code_mod).id_mod
                FindControlLanguage(ctrl)
            End Using
        End Function

        Public Function checkControlsMaster(ByVal ctrl As Control, ByVal id_idioma As Integer)
            idiomaID = id_idioma
            Using dbEntities As New dbRMS_JIEntities
                controlesList = dbEntities.t_control.Where(Function(p) p.t_mod.mod_code = code_mod) _
                    .Select(Function(p) p.ctrl_code).ToList()
                idiomaControl = dbEntities.vw_ctrl_language.Where(Function(p) p.mod_code = code_mod And p.id_idioma = id_idioma).ToList()
                moduloID = dbEntities.t_mod.FirstOrDefault(Function(p) p.mod_code = code_mod).id_mod
                FindControlLanguageMaster(ctrl)
            End Using
        End Function

        Sub guardar(ByVal code As String, ByVal tipo As Integer, ByVal valor As String)

            If Not controlesList.Contains(code) Then
                Dim control As New t_control
                control.ctrl_code = code
                control.ctrl_name = code
                control.ctrl_type = tipo
                control.id_mod = moduloID
                control.ctrl_obs = ""
                control.requiere_acceso = False

                Dim idiomacontrol As New t_control_idiomas
                idiomacontrol.id_idioma = 2
                idiomacontrol.valor = valor

                control.t_control_idiomas.Add(idiomacontrol)
                db.t_control.Add(control)
                db.SaveChanges()
            Else
                Dim control = db.t_control.FirstOrDefault(Function(p) p.ctrl_code = code And p.id_mod = moduloID)
                If control.t_control_idiomas.Where(Function(p) p.id_idioma = 2).Count() = 0 Then
                    Dim idiomacontrol As New t_control_idiomas
                    idiomacontrol.id_idioma = 2
                    idiomacontrol.valor = valor

                    control.t_control_idiomas.Add(idiomacontrol)
                    db.t_control.Add(control)
                    db.Entry(control).State = Entity.EntityState.Modified
                    db.SaveChanges()
                    'Else
                    '    Dim control_idioma = control.t_control_idiomas.FirstOrDefault(Function(p) p.id_idioma = 2)
                    '    control_idioma.valor = valor
                    '    db.Entry(control_idioma).State = Entity.EntityState.Modified
                    '    db.SaveChanges()
                End If
            End If
        End Sub

        Sub cambiarIdiomaCtrl(ByVal ctrl As Control, ByVal ctrl_type As Integer)

            Select Case ctrl_type
                Case ctrl_type = 1
                Case ctrl_type = 2
                    Dim cont = CType(ctrl, Label)
                    If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID).Count() > 0 Then
                        cont.Text = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                    End If
                Case ctrl_type = 3
                    Dim cont = CType(ctrl, RadTextBox)
                    If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                        cont.EmptyMessage = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                    End If
                Case ctrl_type = 4
                    Dim cont = CType(ctrl, RadButton)
                    If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                        cont.Text = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                    End If
                Case ctrl_type = 5
                    Dim cont = CType(ctrl, RadButton)
                    If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                        cont.Text = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                    End If
                Case ctrl_type = 6

            End Select
        End Sub

        Public Function FindControlLanguageMaster(ByVal ctrl As Control) As Object
            Try
                If Not String.IsNullOrEmpty(ctrl.ID) Then

                    Select Case True
                        Case ctrl.ID.StartsWith("lblm_")
                            Dim cont = CType(ctrl, Label)
                            guardar(ctrl.ID, 12, cont.Text)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.Text = valor
                                End If
                            End If
                    End Select
                Else
                    For Each child As System.Web.UI.Control In ctrl.Controls
                        Dim lookFor As System.Web.UI.Control = FindControlLanguageMaster(child)

                        If lookFor IsNot Nothing Then
                            Return lookFor
                        End If
                    Next
                    Return Nothing
                End If
            Catch ex As Exception
                Dim exception = ex
            End Try

        End Function

        Public Function FindControlLanguage(ByVal ctrl As Control) As Object
            Try
                If Not String.IsNullOrEmpty(ctrl.ID) Then

                    Select Case True
                        Case ctrl.ID.StartsWith("grd_")
                            FindColumn(ctrl)
                            guardar(ctrl.ID, 7, "")
                        Case ctrl.ID.StartsWith("lblt_")
                            Dim cont = CType(ctrl, Label)
                            guardar(ctrl.ID, 1, cont.Text)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.Text = valor
                                End If
                            End If
                        Case ctrl.ID.StartsWith("txt_")
                            Dim cont = CType(ctrl, RadTextBox)
                            guardar(ctrl.ID, 3, cont.EmptyMessage)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.EmptyMessage = valor
                                End If
                            End If
                        Case ctrl.ID.StartsWith("lnk_")
                            Dim cont = CType(ctrl, LinkButton)
                            guardar(ctrl.ID, 5, cont.Text)
                        Case ctrl.ID.StartsWith("hlk_")
                            Dim cont = CType(ctrl, HyperLink)
                            guardar(ctrl.ID, 6, cont.Text)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.Text = valor
                                End If
                            End If
                        Case ctrl.ID.StartsWith("btn_")
                            Dim cont = CType(ctrl, RadButton)
                            guardar(ctrl.ID, 4, cont.Text)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.Text = valor
                                End If
                            End If
                            'cambiarIdiomaCtrl(ctrl, 4)
                        Case ctrl.ID.StartsWith("cmb_")
                            Dim cont = CType(ctrl, RadComboBox)
                            guardar(ctrl.ID, 8, cont.EmptyMessage)

                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.EmptyMessage = valor
                                End If
                            End If
                        Case ctrl.ID.StartsWith("alink_")
                            Dim cont = CType(ctrl, HtmlAnchor)
                            guardar(ctrl.ID, 9, cont.InnerText)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.InnerText = valor
                                End If
                            End If
                        Case ctrl.ID.StartsWith("rbn_")
                            Dim cont = CType(ctrl, RadioButton)
                            guardar(ctrl.ID, 10, cont.Text)
                        Case ctrl.ID.StartsWith("chk_")
                            Dim cont = CType(ctrl, CheckBox)
                            guardar(ctrl.ID, 11, cont.Text)
                            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.ID And p.valor.Length > 0).Count() > 0 Then
                                Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.ID).valor
                                If Not String.IsNullOrWhiteSpace(valor) Then
                                    cont.Text = valor
                                End If
                            End If
                        Case ctrl.ID.StartsWith("esp_ctrl_")
                            control_otros_idioma(ctrl, ctrl.ID, class_user)
                        Case ctrl.ID.StartsWith("txtr_")
                            Dim cont = CType(ctrl, RadNumericTextBox)
                            guardar(ctrl.ID, 15, cont.EmptyMessage)
                        Case Else
                            For Each child As System.Web.UI.Control In ctrl.Controls
                                Dim lookFor As System.Web.UI.Control = FindControlLanguage(child)

                                If lookFor IsNot Nothing Then
                                    Return lookFor
                                End If
                            Next
                            Return Nothing
                    End Select
                Else
                    For Each child As System.Web.UI.Control In ctrl.Controls
                        Dim lookFor As System.Web.UI.Control = FindControlLanguage(child)

                        If lookFor IsNot Nothing Then
                            Return lookFor
                        End If
                    Next
                    Return Nothing
                End If
            Catch ex As Exception
                Dim exception = ex
            End Try

        End Function

        Sub FindColumn(ByRef grdGRID As Telerik.Web.UI.RadGrid)

            For Each grdColumn As GridColumn In grdGRID.MasterTableView.RenderColumns
                If grdColumn.UniqueName.StartsWith("colm_") Then
                    guardar(grdColumn.UniqueName, 2, grdColumn.HeaderText)
                    If idiomaControl.Where(Function(p) p.ctrl_code = grdColumn.UniqueName And p.valor.Length > 0).Count() > 0 Then
                        Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = grdColumn.UniqueName).valor
                        If Not String.IsNullOrWhiteSpace(valor) Then
                            grdColumn.HeaderText = valor
                        End If
                    End If
                    'cambiarIdiomaColumna(grdColumn, "colm_")
                End If
            Next
        End Sub


        Sub cambiarIdiomaColumna(ByVal ctrl As GridColumn, ByVal prefijo As String)
            Select Case prefijo
                Case prefijo = "colm_"
                    If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.UniqueName And p.valor.Length > 0).Count() > 0 Then
                        Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.UniqueName).valor
                        If Not String.IsNullOrWhiteSpace(valor) Then
                            ctrl.HeaderText = valor
                        End If
                    End If
                Case prefijo = "colma_"
                    If idiomaControl.Where(Function(p) p.ctrl_code = ctrl.UniqueName And p.valor.Length > 0).Count() > 0 Then
                        Dim valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl.UniqueName).valor
                        If Not String.IsNullOrWhiteSpace(valor) Then
                            ctrl.HeaderText = valor
                        End If
                    End If
            End Select
        End Sub



        Sub control_otros_idioma(ByVal control As Object, ByVal codigo As String, ByVal cls_user As cls_user)
            Dim codigoCtrl As String = codigo.Replace("esp_ctrl_", "")
            If codigoCtrl.StartsWith("btnh_") Then
                control.InnerText = cls_user.controles_otros.FirstOrDefault(Function(p) p.control_code = codigoCtrl).texto
            ElseIf codigoCtrl.StartsWith("txt_") Then
                control.Text = cls_user.controles_otros.FirstOrDefault(Function(p) p.control_code = codigoCtrl).texto
            ElseIf codigoCtrl.StartsWith("btn_") Then
                control.Text = cls_user.controles_otros.FirstOrDefault(Function(p) p.control_code = codigoCtrl).texto
            ElseIf codigoCtrl.StartsWith("lbl_") Then
                control.Text = cls_user.controles_otros.FirstOrDefault(Function(p) p.control_code = codigoCtrl).texto
            ElseIf codigoCtrl.StartsWith("h4_") Then
                control.InnerText = cls_user.controles_otros.FirstOrDefault(Function(p) p.control_code = codigoCtrl).texto
            End If
        End Sub

        Public Function iconosGrid(ByVal ctrl_code As String) As String
            Dim valor = ""
            If idiomaControl.Where(Function(p) p.ctrl_code = ctrl_code).Count() > 0 Then
                valor = idiomaControl.FirstOrDefault(Function(p) p.ctrl_code = ctrl_code).valor
            End If
            Return valor
        End Function

    End Class
End Namespace